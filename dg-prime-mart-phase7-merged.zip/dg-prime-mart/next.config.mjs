/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    // Product images will come from a storage/CDN provider (S3, Supabase, or
    // the CJ Dropshipping product feed) once one is connected. Add the real
    // hostname(s) here at that point, e.g.:
    // remotePatterns: [{ protocol: "https", hostname: "cdn.dgprimemart.com" }],
    remotePatterns: [],
  },
};

export default nextConfig;
