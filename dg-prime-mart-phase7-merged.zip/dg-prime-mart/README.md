# DG PRIME MART — Storefront + Database/Auth + Checkout + Admin + CJ Dropshipping + QA + Hardening (Phase 1–7)

Premium, independent ecommerce platform for DG PRIME MART. No Shopify
anywhere in this codebase.

## Stack

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS with a custom design-token palette (see `tailwind.config.ts`)
- PostgreSQL + Prisma
- Auth.js (next-auth v5) — Credentials provider, JWT sessions
- Zod for input validation, bcryptjs for password hashing
- PayPal Orders v2 REST API (server-side only, no PayPal npm SDK — the
  browser button is loaded via PayPal's hosted JS SDK `<script>` tag)

## Getting started

```bash
npm install
cp .env.example .env.local   # fill in DATABASE_URL, AUTH_SECRET, PayPal vars
npm run db:migrate           # creates tables from prisma/schema.prisma
npm run db:seed              # seeds 6 categories + DG10 coupon (+ optional admin)
npm run dev
```

```bash
npm run build       # production build
npm run typecheck   # TypeScript check
npm run lint         # ESLint
npm run db:studio    # browse the database visually
```

> This project was authored in a sandboxed environment with no network
> access. `npm install` itself was directly tested and confirmed to fail
> here (registry 403). Nothing downstream — Prisma generate/migrate,
> TypeScript, lint, `next build`, or any actual PayPal API call — could be
> executed. Every phase's code was written carefully against documented
> APIs, but you are the first person to actually run it. See "Known risk"
> at the bottom.

## PayPal setup

1. Create a PayPal developer app at https://developer.paypal.com/dashboard/applications
   to get a **Client ID** and **Client Secret**.
2. **Sandbox first.** Set:
   ```
   PAYPAL_CLIENT_ID=<sandbox client id>
   PAYPAL_CLIENT_SECRET=<sandbox client secret>
   PAYPAL_ENVIRONMENT=sandbox
   NEXT_PUBLIC_PAYPAL_CLIENT_ID=<same sandbox client id>
   ```
   Test with PayPal's sandbox buyer accounts (generated automatically in
   the developer dashboard under Sandbox → Accounts).
3. **Webhook:** in the same app's settings, add a webhook subscribed to at
   least `PAYMENT.CAPTURE.COMPLETED` and `CHECKOUT.ORDER.APPROVED`, pointed
   at `https://<your-domain>/api/webhooks/paypal`. Copy the generated
   **Webhook ID** into `PAYPAL_WEBHOOK_ID`. Until this is set, the webhook
   route safely rejects all events (see `lib/paypal.ts`
   `verifyWebhookSignature` — no webhook ID means "cannot verify," which
   is treated the same as "invalid," not "trust it anyway"). The
   browser-driven capture call still works without the webhook configured;
   the webhook is a reliability backstop for when the browser doesn't make
   it back (closed tab, network drop), not a requirement for basic
   checkout to function.
4. **Going to production:** switch `PAYPAL_ENVIRONMENT=production` and use
   your live app's credentials + a webhook registered against the live
   app. Do this only after testing the full sandbox flow end to end.

### ⚠️ Currency — read before launch

PayPal accounts based in India can only *receive* domestic payments in
INR under RBI/PayPal's own restrictions, and cross-border receipts
typically settle in a currency like USD depending on your account setup.
This codebase does not silently work around that — `NEXT_PUBLIC_SITE_URL`'s
sibling setting, the store's `currency` on each `Product` row, is what
actually gets sent to PayPal (see `calculateCheckout` in
`lib/checkout-server.ts`). If your PayPal business account can't receive
the currency your products are priced in, PayPal's API will reject the
order creation call and the customer will see a checkout error — which is
the "fail safely" behavior item 17 of the brief asked for, not a bug. Confirm
with your PayPal account's supported receiving currencies before setting
product prices/currency.

## What's built — Phase 1 (storefront UI)

Pages: Home, Shop, Category, Product, Search, Cart, Wishlist, About,
Contact, FAQ, Shipping/Return/Privacy/Terms. Full responsive nav,
add-to-cart/wishlist, DG10 popup, draggable WhatsApp button, SEO,
accessibility basics.

## What's built — Phase 2 (database + auth)

Prisma schema (17 models), Auth.js Credentials login/register, server-side
route protection (`middleware.ts`), real account pages (`/account`,
`/profile`, `/addresses`, `/orders`, `/wishlist`), cart/wishlist DB
persistence architecture (functionally inert until real products exist —
see below).

## What's built — Phase 3 (checkout + PayPal)

### Checkout flow

`Cart → /checkout → shipping details (guest or saved address) → coupon →
server-calculated summary → PayPal Buttons → capture → /order/confirmation/[id]`.
Guest and logged-in customers both supported; logged-in customers see
saved addresses and their DB cart is the source of truth for line items.

### Server-authoritative pricing (never trusts the browser)

`lib/checkout-server.ts` → `calculateCheckout()` is the single source of
truth. For every line, it re-fetches the `Product` row fresh and uses
**its** price, ignoring any price the browser might send. It checks
`isActive` and `inventory` and drops/reports anything that fails. Discount
comes from `lib/coupon-server.ts` → `validateCoupon()`, run server-side
against the real subtotal. Shipping comes from `shippingConfig` (one
configurable value, `NEXT_PUBLIC_STANDARD_SHIPPING_CHARGE` /
`NEXT_PUBLIC_FREE_SHIPPING_THRESHOLD`), read from a single place, not
duplicated. The PayPal order is created for exactly this server-computed
total (`createPendingOrder`) — the browser only ever receives a PayPal
order id to render a button against; it has no path to alter the amount.

### DG10 — functional, not just seeded

Validated server-side on every checkout attempt: active flag, date window,
minimum order amount, usage limit, per-customer limit (via
`CouponRedemption` count), **and** first-order-only (checked by counting
the customer's/email's prior non-cancelled orders). Critically: **typing
the code does not redeem it.** `CouponRedemption` is only ever created
inside `capturePaymentAndFinalizeOrder`, after PayPal actually reports a
completed capture — never at order-creation time, never from a client
callback alone.

### Idempotency

`Payment.providerPaymentId` (the PayPal order id) is a unique DB column.
`capturePaymentAndFinalizeOrder()` looks up by that column first; if the
row is already `CAPTURED`, it returns the existing result instead of
re-processing. Both the browser's capture call (`/api/checkout/capture`)
and the PayPal webhook (`/api/webhooks/paypal`) call this exact same
function — whichever arrives first does the work, the other is a no-op.
Inventory decrement is separately guarded by `Order.inventoryDecremented`
so a re-run can't double-deduct stock. **Documented, not eliminated, race
window:** the guard is an application-level status check inside a
transaction, not a `SELECT ... FOR UPDATE` row lock — two truly
simultaneous capture calls could theoretically both pass the check before
either writes. Noted directly in `lib/checkout-server.ts` as a hardening
item (Postgres advisory lock or `FOR UPDATE`) before high traffic.

### PayPal integration

`lib/paypal.ts` — real REST calls only, nothing fabricated: OAuth2 client
credentials token (cached until near-expiry), `createPayPalOrder`,
`capturePayPalOrder`, `getPayPalOrder`, `verifyWebhookSignature`. No mock
success path exists anywhere in this codebase — order creation calls
PayPal's `/v2/checkout/orders`, capture calls PayPal's `/capture` endpoint,
and an order is only marked `PAID` when PayPal's own response says the
capture `status` is `COMPLETED`.

### Order status lifecycle

`PENDING_PAYMENT` (created, PayPal order started) → `PAID` (PayPal capture
completed) → *(all later transitions — `PROCESSING` through `DELIVERED`
— are for the supplier-approval phase, not built here)*. **A successful
customer payment never automatically submits to CJ Dropshipping or any
supplier.** Nothing in this codebase calls a supplier API — `Fulfillment`
rows aren't even created yet; that's explicitly the next phase.

### Inventory

Checked (not reserved) at calculation time; decremented only after a real
completed capture, guarded against double-decrement by
`Order.inventoryDecremented`. Never decremented on checkout-page load, cart
add, or a failed/cancelled payment.

### Cart after purchase

For logged-in customers, purchased line items are deleted from their DB
`CartItem` rows inside the same transaction that marks the order paid. For
guests, there's no server-side cart to clear (Phase 1's guest cart is
`localStorage`-only) — the confirmation page doesn't touch it; clearing
the local cart client-side after a successful redirect would be a
reasonable follow-up if you want that specific UX polish.

### Confirmation & order access

`/order/confirmation/[orderId]` — authorized by **either** session
ownership **or** an unguessable `Order.guestToken` (24 random bytes) as a
query param, generated only for guest orders. No account-holder can view
another account-holder's order and no guest token grants access beyond its
one order. `/account/orders` and `/account/orders/[id]` are real,
owner-scoped queries. **Not built:** a general "look up my order" page for
guests who lose their confirmation link (deliberately deferred — an
email+order-number lookup form is easy to add but needs rate-limiting to
avoid enabling order-number enumeration, which felt like more than this
phase's scope; guests should save/bookmark their confirmation link for
now).

### Error handling

Empty cart, inactive/deleted/out-of-stock products (per-line messages,
not a blanket failure), invalid/expired/duplicate/minimum-not-met coupon,
PayPal creation/capture failure, cancelled PayPal payment, duplicate
capture (idempotent no-op, not an error) — all handled without leaking
raw errors, stack traces, or secrets to the client.

## What's built — Phase 4 (admin dashboard + supplier approval)

### The rule this whole phase exists to enforce

**A paid order never automatically becomes a supplier order.** Nothing in
this codebase calls a supplier API — not CJ Dropshipping, not any other
provider. The *only* way a `Fulfillment` row is ever created or advanced
is a human admin clicking "Approve & Send to Supplier" and confirming a
second time in a dialog. That action (`/api/admin/orders/[id]/approve-fulfillment`)
sets `Fulfillment.status = APPROVED` and stops — it does not, and
currently *cannot*, submit anywhere. Live supplier submission is
explicitly a future phase; this phase builds the approval gate, not the
door past it.

### Admin authorization (two layers, both real)

1. `middleware.ts` (unchanged since Phase 2) redirects non-admins away
   from `/admin/*` at the edge.
2. `app/admin/layout.tsx` re-checks the session server-side before
   rendering any admin page — so even a request that somehow bypassed
   middleware still can't reach admin data.
3. Every single admin **API route** additionally calls `requireAdmin()`
   (`lib/admin-auth.ts`) itself, independent of both of the above. This
   matters because `/api/admin/*` is *not* in the middleware matcher —
   API routes are protected entirely by their own `requireAdmin()` call,
   by design, not by omission. `requireAdmin()` throws rather than
   returning a nullable value, so a route can't accidentally proceed
   without checking.

None of this ever trusts a role, id, or price the client sends — every
admin mutation re-derives the acting user from the server-side session and
re-fetches the target record before acting on it.

### Admin routes built

`/admin` (dashboard), `/admin/orders` (list + filter + search),
`/admin/orders/[id]` (detail + approval panel), `/admin/products` (list +
search + category filter), `/admin/products/new`, `/admin/products/[id]`
(edit), `/admin/customers`, `/admin/inventory`, `/admin/coupons`,
`/admin/suppliers`, `/admin/fulfillment`, `/admin/settings`. All real
database-backed pages — none are placeholder mockups.

### Dashboard metrics

Every number on `/admin` is a live query (`lib/admin-metrics.ts`): total
orders, paid orders, orders awaiting supplier approval, revenue (sum of
`total` across non-pending/non-cancelled orders), customer count, product
count, low-stock product count (against the configurable threshold), and
the 8 most recent orders. Nothing is hardcoded or estimated; an empty
database shows zeros and empty states, not sample data.

### Supplier approval workflow — the core of this phase

For every `PAID` order without a fulfillment row (or still
`PENDING_APPROVAL`), the order detail page shows a **Supplier Fulfillment
Approval** panel: per-item supplier, supplier product ID, supplier cost,
and an **Estimated Gross Margin** (`lib/margin.ts` — always labeled
"estimated," never "profit"; customer revenue minus supplier cost minus
supplier shipping, nothing more sophisticated than that). Clicking
"Approve & Send to Supplier" opens a confirmation dialog restating order
number, customer, items, and estimated total, requiring a second explicit
click ("Yes, Approve & Send to Supplier") before anything happens — a
single click never submits.

**Idempotency:** the approval API re-fetches the `Fulfillment` row inside
a transaction and checks its status before writing. If it's already past
`PENDING_APPROVAL`, the existing state is returned unchanged — a
double-click, a browser retry, or two admin tabs approving the same order
all converge on one `Fulfillment` row, never two. The same
application-level-check-inside-a-transaction caveat noted in Phase 3's
payment capture applies here too: this narrows, but doesn't with
mathematical certainty eliminate, a true simultaneous-request race. Same
recommended hardening (row lock / advisory lock) if this becomes
high-traffic.

**Audit trail:** every approval writes an `AdminAuditLog` row (admin id,
action, entity, metadata) *and* snapshots the approving admin's email,
the supplier, and supplier cost figures directly onto the `Fulfillment`
row itself — so the audit trail survives even if the admin's account or
the supplier's pricing changes later. An admin cannot claim an approval
happened without a corresponding database row; there is no code path that
marks an order approved without writing one.

### Product management

Real create/edit forms (`components/admin/ProductForm.tsx`) covering
every field in the Phase 2 schema plus Phase 4's supplier-cost fields,
images (URL + alt list), and variants (name/SKU/price/inventory). Slug
and SKU uniqueness are checked server-side before writing. **Known
simplification:** editing a product replaces its image set wholesale but
only *adds or updates* variants by SKU — it does not delete a variant
that's been removed from the form, because a variant already referenced
by an existing `CartItem`/`OrderItem` can't be deleted without violating
that foreign key. A dedicated "archive variant" action would be the
correct follow-up rather than a hard delete.

The demo catalog (`lib/demo-data.ts`) is never touched by any admin
route — there is no "import demo products" button anywhere, by design.

### Customers, Inventory, Coupons, Suppliers, Fulfillment, Settings

- **Customers:** name/email/join date/order count/total spent, computed
  from real orders. The query explicitly `select`s only non-sensitive
  `User` fields — `passwordHash` is never fetched here, so there's no
  code path for it to leak even by accident.
- **Inventory:** every product with a status derived from a configurable
  low-stock threshold (Settings), not a hardcoded number.
- **Coupons:** list, create, activate/deactivate. DG10's `code` field is
  intentionally **not editable** via the update API — renaming it in
  place would silently break the Phase 1 popup and any external
  references to it; deactivate and create a new coupon instead.
  Redemption history is never deleted by anything in this phase.
- **Suppliers:** name/provider/active + a live count of mapped products.
  `credentialsRef` is explicitly documented and enforced by convention as
  a *pointer* (e.g. a secrets-manager key name) — this route has no field
  for and never accepts an actual API secret.
- **Fulfillment:** every order grouped by its real fulfillment status,
  including paid orders that haven't even reached `PENDING_APPROVAL` yet
  (no `Fulfillment` row created), so nothing paid is invisible here.
- **Settings:** DB-backed (`Setting` key/value table) and admin-editable.
  **Important scope note, stated directly in the page's own UI copy, not
  hidden in this README:** the live storefront (`lib/config.ts`) still
  reads its defaults from environment variables — changing a value on
  this page updates the database but does **not** yet change what a
  customer sees. Wiring the storefront to read live from this table is
  natural follow-up work, not done here to avoid turning every storefront
  page into an async DB read for what was, until now, a static constant.
  No secret (PayPal keys, supplier credentials) is exposed or editable
  through this page.

## What's built — Phase 5 (CJ Dropshipping submission)

### The rule this phase had to get right

CJ submission is reachable **only** from a `Fulfillment` already at
`status = "APPROVED"` — which itself is reachable only via Phase 4's
separate, audited, two-step-confirmed admin approval action. Phase 5 adds
a **second, independent, also two-step-confirmed** admin action —
"Submit to CJ Dropshipping" — that is the only code path in the entire
codebase allowed to call `createCjOrder()`. Approving an order does not
submit it; submitting requires a further explicit click, on a different
button, with its own confirmation dialog. This keeps "authorize this
order" and "place a real external order" as two separately auditable
moments, and lets an admin approve now and submit later after
double-checking supplier mapping.

### Real idempotency, closing the race window earlier phases documented

Phases 3 and 4 used an application-level "read status, check it, then
write" pattern inside a transaction, and both honestly noted a narrow
unclosed race window. Phase 5 closes that window for submission using a
genuine atomic compare-and-swap:

```ts
const claim = await prisma.fulfillment.updateMany({
  where: { id: fulfillmentId, status: "APPROVED" },
  data: { status: "SUBMITTING" },
});
```

Postgres evaluates and applies that `where` clause atomically. If two
admin requests race, exactly one affects a row (`count === 1`) and
proceeds to call CJ; the other affects zero rows (`count === 0`) and
backs off — re-checking what actually happened instead of guessing, and
returning `already_submitted` or `submission_in_progress` as appropriate.
`SUBMITTING` is a transient claim state (see its comment in
`prisma/schema.prisma`): it always resolves back to `APPROVED` (on
failure, so the admin can retry) or forward to `SUBMITTED` (on success) —
it can never be a stuck end state, and a failed CJ call is never mistaken
for a successful one.

### What gets saved on success

`Fulfillment.supplierOrderId` (CJ's order id, `@unique` at the DB level
so two fulfillments can never point at the same CJ order),
`submissionSnapshot` (the exact payload sent — order number, address,
`{vid, quantity}` lines — never credentials), `submittedById` +
`submittedByEmailSnapshot` (who triggered it, snapshotted the same way
Phase 4 snapshots the approving admin), and `submittedAt`. On failure,
`lastSubmissionError` is set and shown directly in the admin UI, and the
row reverts to `APPROVED` so the admin sees exactly why (usually: missing
supplier variant mapping, or an incomplete shipping address) and can fix
it and retry.

### Server-authoritative payload

`buildCjOrderPayload()` (`lib/fulfillment-server.ts`) is a pure function —
no I/O — built entirely from our own database rows: the order's
`shippingAddressSnapshot` and each `OrderItem`'s `product.supplierVariantId`.
It refuses (returns an error, never sends a partial order) if the address
is incomplete or any item lacks a supplier variant mapping. The API route
takes no input beyond "which order" — there is no field in this flow the
browser could manipulate even if it tried.

### CJ Dropshipping client (`lib/cj-dropshipping.ts`)

Written against CJ's publicly documented Open API v2 shape (get access
token → `CJ-Access-Token` header → `createOrder`). **Read the warning
comment at the top of that file before enabling live mode:** this has not
been exercised against a real CJ account — no credentials or network
access were available while building it, and CJ's API has changed shape
across versions before. It's real code making a real HTTP call, not a
mock — but "real code" and "verified against the live API" are different
claims, and only the first is true right now. `isCjConfigured()` is the
single gate both the UI and the API route check first; with
`CJ_API_EMAIL`/`CJ_API_KEY` unset (the default), "Submit to CJ
Dropshipping" is disabled with an explanatory message, not silently
broken or hidden.

### Tests

`lib/__tests__/cj-payload.test.ts` — pure-function tests for
`buildCjOrderPayload`: valid input, optional-field handling, incomplete
address rejected, unmapped variant rejected, and an explicit assertion
that the built payload never contains anything matching
`/apiKey|password|secret|token/i`. No mocks, no network.

`lib/__tests__/fulfillment-idempotency.test.ts` — the state machine, with
Prisma and the CJ client both mocked (`vi.mock`), so **no database and no
CJ credentials are required to run these**: not-configured refuses before
touching the DB; `PENDING_APPROVAL`/`CANCELLED` are refused; an
already-`SUBMITTED` fulfillment short-circuits without a second CJ call;
`SUBMITTING` reports "in progress" instead of racing; a successful
`APPROVED → SUBMITTED` path calls CJ exactly once (asserted against the
exact claim-query shape); losing the atomic-claim race resolves to
`already_submitted` without ever calling CJ; a CJ API failure reverts the
row to `APPROVED` with `lastSubmissionError` set rather than leaving it
stuck or falsely marking it submitted; an incomplete supplier mapping is
rejected before any CJ call, with the claim released.

Added `vitest` as a dev dependency and an `npm run test` script
specifically so these could be written to run without live CJ
credentials, per the brief — see "Testing status" below for the honest
limit on "written" versus "actually run."

## What's built — Phase 6 (QA audit + hardening + tracking)

### Scope of this audit — read before trusting any PASS below

This phase's brief asked for a full production QA pass, including live
build verification, browser-based responsive/accessibility testing, a
live Cloudflare deployment check, and live PayPal/CJ verification. **None
of that was possible in this sandbox** — no network access (confirmed by
re-testing `npm install`, which still 403s), no browser, no Cloudflare or
GitHub access, no live payment/supplier credentials. What Phase 6 actually
delivered is a **static code audit**: `grep`/`find`-based checks and
manual tracing of the actual source files against the invariants the
brief cares about (single source of truth for shipping, no leftover
Electronics/Fashion categories, no secrets in client code, complete
`requireAdmin()` coverage, a single gated call site for `createCjOrder`,
error-message leak paths, and a systematic scan for one specific bug
class after finding an instance of it). Every "PASS" below is a **PASS
(static)** — verified by reading the code, not by running it. Every item
that genuinely requires a running app, a browser, or live infrastructure
is marked `NOT VERIFIED` with the specific reason, per the brief's own
"no false completion" rule.

### Real bugs found and fixed this phase

The most important thing this phase produced wasn't a report — it was
catching a genuine, build-breaking bug before it ever shipped:
`components/admin/SupplierApprovalPanel.tsx` referenced a
`<SubmittedStatusPanel>` component that had never actually been defined,
left over from an edit interrupted mid-way in an earlier turn. Every
order whose fulfillment had progressed past `APPROVED` (i.e. every
order actually submitted to CJ) would have crashed the admin order
detail page — the single most important page for the supplier-approval
workflow this whole project is built around. Caught by static review,
not a test, because there is no working test runner in this environment.
See the full bug table in this phase's chat report for the other five
issues found and fixed alongside it (unguarded error paths in checkout
capture and fulfillment sync that could leak raw errors or produce
unhandled 500s, and — a genuinely important functional gap — the
customer-facing order pages never surfacing real shipment/tracking
progress at all, because `Order.status` intentionally never advances
past `PAID` and nothing had wired the customer views to `Fulfillment.status`
instead).

### Tracking, added as part of closing that last gap

`Fulfillment` gained `trackingNumber`, `carrier`, `shippedAt`,
`deliveredAt`, `lastSyncedAt`, and `lastSyncSnapshot`. `lib/fulfillment-sync.ts`
pulls CJ's order status forward (`SUBMITTED → PROCESSING → SHIPPED →
DELIVERED`, monotonically — a stale/out-of-order response can never move
a Fulfillment backwards) via a manual admin "Refresh Status" button
(`/api/admin/orders/[id]/sync-fulfillment`) or an optional webhook
(`/api/webhooks/cj`, shared-secret authenticated — see the honesty note
in that file about how this differs from PayPal's real signature
verification). Both customer-facing order views
(`/account/orders/[id]`, `/order/confirmation/[orderId]`) now show this
progress and any tracking number, instead of showing "Paid" forever.

### Test matrix (Phase 6, section 33 of the brief)

| Area | Test | Expected | Result |
|---|---|---|---|
| Homepage | Load | 200/working | NOT VERIFIED — no running app |
| Navigation | Category links | Correct | PASS (static) — 6 approved categories only, confirmed via grep |
| Search | Product search | Correct results | NOT VERIFIED — no running app |
| Product | Open product | Works | NOT VERIFIED — no running app |
| Cart | Add item | Correct | PASS (static) — client state logic reviewed |
| Cart | Quantity | Correct | PASS (static) |
| Cart | Remove | Correct | PASS (static) |
| Shipping | ₹4,999 | Paid shipping | PASS (static) — `calculateCheckout` logic reviewed; not executed |
| Shipping | ₹5,000 | Free shipping | PASS (static) |
| Shipping | ₹5,001 | Free shipping | PASS (static) |
| DG10 | Valid | Correct discount | PASS (static) — server-side validation traced |
| DG10 | Invalid | Rejected | PASS (static) |
| Checkout | Validation | Correct | PASS (static), 2 bugs fixed this phase |
| PayPal | Payment flow | Verified | NOT VERIFIED — no live credentials/network |
| Order | Creation | Correct | PASS (static) — server-authoritative, traced |
| Account | Login | Works | NOT VERIFIED — no running app |
| Account | Order history | Authorized | PASS (static) — ownership check confirmed present |
| Admin | Auth | Protected | PASS (static) — 100% `requireAdmin()` coverage confirmed by grep |
| Admin | Orders | Works | FAIL → FIXED (static) — the `SubmittedStatusPanel` bug above |
| CJ | Integration | Verified | NOT VERIFIED — no live account/network |
| Supplier | Confirmation gate | Enforced | PASS (static) — `createCjOrder` has exactly one caller, gated on `status === "APPROVED"`, confirmed by grep across the entire codebase |
| Tracking | Order tracking | Correct | FAIL → FIXED (static) — customer pages never showed it; now wired |
| Mobile | 390px | Good | NOT VERIFIED — no browser |
| Tablet | 768px | Good | NOT VERIFIED — no browser |
| Desktop | 1440px | Good | NOT VERIFIED — no browser |
| SEO | Metadata | Correct | PASS (static) — `robots.ts`/`sitemap.ts` present, no raw `<img>` bypassing alt text |
| Security | Protected APIs | Secure | PASS (static), 3 error-handling bugs fixed |
| Build | Production build | Pass | FAIL — `npm install` 403s, nothing downstream can run |
| Cloudflare | Deployment | Pass | **NOT PASS — see below, this is a real finding, not just an access gap** |

### D. Security (Phase 6 audit)

- **Authentication:** unchanged from Phase 2 (bcrypt, JWT sessions) — PASS (static)
- **Authorization:** every `/api/admin/*` route confirmed to call `requireAdmin()` (grep-verified, zero exceptions) — PASS (static)
- **Payment security:** server-authoritative pricing confirmed in `calculateCheckout`; PayPal secret confirmed server-side-only — PASS (static)
- **Supplier credentials:** `CJ_API_KEY` confirmed server-side-only; the only client-side mentions of the variable *names* are informational `<code>` text in the admin UI, not values — PASS (static)
- **Admin security:** two-step confirmation on both approval and submission, atomic-claim idempotency on submission — PASS (static)
- **Secret exposure:** grepped for `NEXT_PUBLIC_` + secret-like variable names (none), grepped for literal committed secret values (none), confirmed `.env`/`.env.local` are gitignored — PASS (static)

### Known limitation this phase deliberately did not fix: Cloudflare

This codebase has **no Cloudflare deployment configuration at all**
(no `wrangler.toml`, no `next-on-pages`), and — more importantly — uses
`bcryptjs`, a standard TCP Postgres Prisma client, and `node:crypto`
(`lib/order-number.ts`, `auth.ts`, `lib/prisma.ts`, `lib/coupon-server.ts`),
none of which run natively on Cloudflare Workers' edge runtime without
real adaptation (Prisma Accelerate/Data Proxy or an HTTP Postgres driver,
Web-Crypto-based password hashing, etc.). I did not bolt on a
`wrangler.toml` to make this look addressed — a config file that doesn't
actually run would be exactly the "fake success" this phase's brief
explicitly forbids. If Cloudflare is a hard requirement, this needs a
dedicated migration phase. If it isn't, this codebase runs as a standard
Next.js Node app on Vercel, Render, Railway, or a VPS with no changes,
once `npm install` succeeds somewhere with real network access.

## What's built — Phase 7 (production-readiness hardening)

Three targeted checkout/payment hardening fixes, verified by direct code
diff against the Phase 6 baseline before being accepted (two files
changed, nothing else):

1. **No more silent partial orders.** Previously, if some cart lines were
   invalid (out of stock, deleted, inactive) at checkout time, the valid
   lines would proceed and the invalid ones were just reported as
   warnings — a customer could end up paying for less than they thought
   they were buying without a hard stop. `POST /api/checkout/create` now
   rejects the entire checkout attempt if *any* line fails validation,
   surfacing the specific reason so the customer can fix their cart and
   retry. This is a deliberate policy tightening, not a bug fix — the
   previous behavior (let valid items through) is also a legitimate,
   common pattern; this one is the more conservative choice.
2. **Currency consistency enforced before checkout math runs.** A product
   whose `currency` doesn't match the store's configured default is now
   rejected from checkout rather than silently entering a
   subtotal/shipping/total calculation that assumes one currency.
   **Known limitation to revisit:** this compares against a single global
   default rather than "everything in this cart shares one currency" —
   correct for today's single-currency catalog, but will need loosening
   once the multi-currency support described in Phase 1 (USD/GBP/CAD/AUD/EUR/INR)
   is actually built, since a cart could then validly be all-USD or
   all-EUR without matching a single hardcoded default.
3. **PayPal capture is now verified on amount and currency, not just
   status.** Previously, a capture response reporting `status: "COMPLETED"`
   was trusted outright. Now, the capture response's actual `amount` and
   `currency` must match the server-calculated order total exactly before
   the payment/order are marked paid — a mismatch is treated as a failed
   payment, not a successful one with a discrepancy nobody checks.

## Known limitation, carried from Phase 2: demo catalog vs. real checkout

**This is the most important caveat in this phase.** `lib/demo-data.ts`
products are still not real `Product` rows — they can't be, since the
catalog must stay empty until real products are approved. This means:

- The full checkout flow (pricing, coupon, PayPal order creation, capture,
  inventory, confirmation) is **real, complete, and correct code** — but it
  has **never processed an actual transaction**, because there is nothing
  purchasable in the database yet.
- Attempting checkout with the current storefront's demo products will
  correctly return "Your cart doesn't contain any purchasable items yet"
  from `/api/checkout/create` — that's the calculation function doing its
  job (rejecting non-existent product ids), not a bug.
- **To actually test checkout or the admin approval flow:** create at
  least one real `Product` via `/admin/products/new` (this phase finally
  makes that possible without touching Prisma Studio directly), add it to
  a cart, run checkout against PayPal sandbox, then go approve the
  resulting order from `/admin/orders`.

## Environment variables

See `.env.example` for the full annotated list. New in Phase 6:
`CJ_WEBHOOK_SECRET` (optional — leaving it unset disables the CJ webhook
route safely). Phase 5's `CJ_API_EMAIL`/`CJ_API_KEY`, Phase 3's PayPal
variables, and Phase 4's DB-backed settings are all unchanged.

## Database migration

**Not run** — no live PostgreSQL and no network access to fetch Prisma's
engine binaries in this sandbox (confirmed, not assumed — see "Known
risk"). Phase 6 adds tracking/sync fields to `Fulfillment`
(`trackingNumber`, `carrier`, `shippedAt`, `deliveredAt`, `lastSyncedAt`,
`lastSyncSnapshot`) on top of Phases 1–5's schema. All additive, no
destructive changes — but **no migration file has been generated**;
`npm run db:migrate` against a real database is your first step, and will
generate one migration covering the full accumulated schema across all
six phases at once (none of the earlier phases' migrations have been run
either, for the same reason).

## Testing status

**Could not run:** `npm install` (confirmed 403 from npm registry in an
earlier phase — no network egress in this sandbox), and therefore
everything downstream, including `npm run test` itself. This is worth
stating plainly since this phase's brief specifically asked for tests:
**the test files are written, reviewed by hand, and — by design — require
no database and no live CJ credentials to run (see "Tests" above), but
they have not actually been executed even once in this environment,**
because `vitest` itself could never be installed here. Same honest gap as
every other phase's `npm install`-dependent tooling — not a smaller
version of it.

**What I did instead:** manual trace of every test's mock setup against
`lib/fulfillment-server.ts`'s actual logic line-by-line — confirming, for
example, that the exact `updateMany` `where`/`data` shape asserted in the
"submits successfully" test matches what the source file actually sends,
and that every one of the eleven test cases corresponds to a real branch
in `submitFulfillmentToSupplier`'s control flow (not just a name that
sounds like it tests something). This is the same level of scrutiny as
previous phases' manual reviews, applied to test code instead of
application code — genuinely useful, but not a substitute for the tests
having actually run and passed.

**You should run, in order, once you have a database:**
```bash
npm install
npm run test          # can run before a database exists — fully mocked
npm run db:migrate
npm run db:seed
npm run typecheck
npm run lint
npm run build
# then, with the app running, an ADMIN user, and (optionally) real CJ
# sandbox credentials in CJ_API_EMAIL/CJ_API_KEY, manually verify:
#  - with CJ_API_* unset: "Submit to CJ Dropshipping" is visibly disabled
#  - approve an order, then submit it — Fulfillment.status becomes
#    SUBMITTED and supplierOrderId is populated
#  - clicking "Submit to CJ Dropshipping" twice (or two tabs) only ever
#    results in one CJ order / one SUBMITTED fulfillment
#  - a product with no supplierVariantId is rejected before any CJ call
```

## Known risk: unverified build (unchanged since Phase 2, still true)

Nothing in this phase has been executed — not the application code, and
notably not even the test suite written specifically to not need live
credentials, because the test *runner* itself needs `npm install` first.
The code follows Next.js 14, Prisma, and Vitest conventions carefully,
and reuses/improves on patterns already established in Phases 2–4 (the
atomic-claim idempotency here is strictly stronger than the
application-level check used in Phases 3–4), but you are the first to
run any of it — treat whatever surfaces on first `npm install`/`test`/
`build` as normal first-pass issues, not a sign the architecture is wrong.

## Next recommended phase

**Get a real environment running, in this order — nothing else matters until this happens:** (1) `npm install` somewhere with network access, (2) a real PostgreSQL database + `npm run db:migrate`, (3) `npm run typecheck && npm run lint && npm run build`, all for the first time ever across six phases of code. Phase 6's static audit is a real, evidence-based pass, but it is structurally incapable of catching what only a compiler, linter, or running app can — the `SubmittedStatusPanel` bug it did catch is proof this kind of review has value, not proof it's a substitute for actually running the code.

**Alongside or immediately after that:** resolve the Cloudflare question one way or the other (migrate the stack, or deploy elsewhere), then do a real pass through this phase's test matrix with a live app: browser-based responsive/accessibility checks, a real PayPal sandbox transaction, and — carefully, deliberately, only when ready — a real CJ Dropshipping sandbox submission. The two items called out at the end of Phase 4 (wiring `lib/config.ts` to read live from `Setting`; hardening Phase 3/4's payment-capture and approval idempotency to a real row lock the way Phase 5 did for submission) remain open and are still good candidates for a future pass.
