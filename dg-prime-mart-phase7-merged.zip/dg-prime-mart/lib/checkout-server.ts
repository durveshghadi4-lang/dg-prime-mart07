import { prisma } from "@/lib/prisma";
import { shippingConfig, siteConfig } from "@/lib/config";
import { validateCoupon } from "@/lib/coupon-server";
import { generateOrderNumber, generateGuestToken } from "@/lib/order-number";
import {
  createPayPalOrder,
  capturePayPalOrder,
  PayPalConfigError,
} from "@/lib/paypal";

export interface CheckoutLineInput {
  productId: string;
  quantity: number;
}

export interface CalculatedLine {
  productId: string;
  name: string;
  sku: string;
  price: number;
  quantity: number;
  lineTotal: number;
}

export interface CheckoutCalculation {
  lines: CalculatedLine[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  currency: string;
  couponId: string | null;
  /** Human-readable problems with individual requested lines (out of stock,
   * inactive, deleted) — shown to the customer, never silently dropped. */
  lineErrors: string[];
  /** Set if the coupon code supplied was invalid for any reason. */
  couponError: string | null;
}

/**
 * Recalculates an order from scratch against the database. This is the
 * single source of truth for price/discount/shipping/total — nothing here
 * is ever taken from the request body except product ids, quantities, and
 * the coupon code the customer typed. Every number that ends up on the
 * PayPal order comes out of this function.
 */
export async function calculateCheckout(params: {
  lines: CheckoutLineInput[];
  couponCode?: string | null;
  userId: string | null;
  email: string;
}): Promise<CheckoutCalculation> {
  const lineErrors: string[] = [];
  const calculatedLines: CalculatedLine[] = [];
  let currency: string = siteConfig.defaultCurrency;

  for (const requested of params.lines) {
    if (requested.quantity < 1 || requested.quantity > 99) {
      lineErrors.push("Invalid quantity requested for one item.");
      continue;
    }

    const product = await prisma.product.findUnique({
      where: { id: requested.productId },
    });

    if (!product) {
      lineErrors.push(
        "One item in your cart is no longer available and was removed."
      );
      continue;
    }
    if (!product.isActive) {
      lineErrors.push(`"${product.name}" is no longer available.`);
      continue;
    }
    if (product.inventory < requested.quantity) {
      lineErrors.push(
        product.inventory === 0
          ? `"${product.name}" is out of stock.`
          : `Only ${product.inventory} of "${product.name}" left in stock.`
      );
      continue;
    }

    // The storefront currently settles in one currency (INR). Never build
    // a checkout from mixed-currency product rows because the shipping
    // threshold and PayPal amount would otherwise be ambiguous.
    if (product.currency !== siteConfig.defaultCurrency) {
      lineErrors.push(`"${product.name}" cannot be purchased in the current store currency.`);
      continue;
    }

    const price = Number(product.price);
    currency = product.currency;
    calculatedLines.push({
      productId: product.id,
      name: product.name,
      sku: product.sku,
      price,
      quantity: requested.quantity,
      lineTotal: Math.round(price * requested.quantity * 100) / 100,
    });
  }

  const subtotal =
    Math.round(
      calculatedLines.reduce((sum, l) => sum + l.lineTotal, 0) * 100
    ) / 100;

  let discount = 0;
  let couponId: string | null = null;
  let couponError: string | null = null;

  if (params.couponCode && params.couponCode.trim() && calculatedLines.length > 0) {
    const result = await validateCoupon({
      code: params.couponCode,
      subtotal,
      userId: params.userId,
      email: params.email,
    });
    if (result.valid) {
      discount = result.discount;
      couponId = result.couponId;
    } else {
      couponError = result.reason;
    }
  }

  const afterDiscount = Math.max(subtotal - discount, 0);
  const shipping =
    calculatedLines.length === 0
      ? 0
      : afterDiscount >= shippingConfig.freeShippingThreshold
      ? 0
      : shippingConfig.standardShippingCharge;

  const total = Math.round((afterDiscount + shipping) * 100) / 100;

  return {
    lines: calculatedLines,
    subtotal,
    discount,
    shipping,
    total,
    currency,
    couponId,
    lineErrors,
    couponError,
  };
}

export interface CreateOrderResult {
  orderId: string;
  orderNumber: string;
  paypalOrderId: string;
  guestToken: string | null;
  total: number;
  currency: string;
}

/**
 * Creates the internal Order (+ OrderItems + Payment) in PENDING_PAYMENT,
 * then creates the matching PayPal order for the exact server-calculated
 * total. The browser receives only the PayPal order id to render the
 * button against — it never gets a chance to supply or alter an amount.
 */
export async function createPendingOrder(params: {
  calculation: CheckoutCalculation;
  userId: string | null;
  email: string;
  shippingAddress: Record<string, unknown>;
  billingAddress: Record<string, unknown>;
}): Promise<CreateOrderResult> {
  if (params.calculation.lines.length === 0) {
    throw new Error("Cannot create an order with no purchasable items.");
  }

  const orderNumber = generateOrderNumber();
  const guestToken = params.userId ? null : generateGuestToken();

  let order;
  try {
    order = await prisma.order.create({
      data: {
        orderNumber,
        userId: params.userId ?? undefined,
        email: params.email,
        guestToken: guestToken ?? undefined,
        status: "PENDING_PAYMENT",
        subtotal: params.calculation.subtotal,
        shipping: params.calculation.shipping,
        discount: params.calculation.discount,
        total: params.calculation.total,
        currency: params.calculation.currency,
        couponId: params.calculation.couponId ?? undefined,
        shippingAddressSnapshot: params.shippingAddress as object,
        billingAddressSnapshot: params.billingAddress as object,
        items: {
          create: params.calculation.lines.map((line) => ({
            productId: line.productId,
            nameSnapshot: line.name,
            skuSnapshot: line.sku,
            priceSnapshot: line.price,
            quantity: line.quantity,
          })),
        },
      },
    });
  } catch {
    // QA FIX (Phase 6, P2): previously this call was unguarded, so a raw
    // Prisma/DB error (constraint names, column names, connection details)
    // could propagate uncaught through this function and out to the
    // client via the API route's catch block, which surfaces
    // `err.message` directly. Never let a database-level failure produce
    // client-visible detail beyond "something went wrong."
    throw new Error(
      "Could not create your order right now. Please try again in a moment."
    );
  }

  let paypalOrderId: string;
  try {
    const paypalOrder = await createPayPalOrder({
      internalOrderId: order.id,
      amount: params.calculation.total.toFixed(2),
      currency: params.calculation.currency,
    });
    paypalOrderId = paypalOrder.paypalOrderId;
  } catch (err) {
    // Roll the order back to CANCELLED rather than leaving an orphaned
    // PENDING_PAYMENT row if PayPal itself couldn't be reached/configured.
    await prisma.order.update({
      where: { id: order.id },
      data: { status: "CANCELLED" },
    });
    if (err instanceof PayPalConfigError) {
      throw new Error(
        "Payments are not configured yet. Please contact support."
      );
    }
    throw new Error("Could not start payment with PayPal. Please try again.");
  }

  await prisma.payment.create({
    data: {
      orderId: order.id,
      provider: "paypal",
      providerPaymentId: paypalOrderId,
      status: "CREATED",
      amount: params.calculation.total,
      currency: params.calculation.currency,
    },
  });

  return {
    orderId: order.id,
    orderNumber,
    paypalOrderId,
    guestToken,
    total: params.calculation.total,
    currency: params.calculation.currency,
  };
}

export interface FinalizeCaptureResult {
  status: "already_captured" | "captured" | "not_completed" | "not_found" | "provider_error";
  orderId?: string;
  orderNumber?: string;
  guestToken?: string | null;
}

/**
 * Captures a PayPal order and — only on a real COMPLETED capture status —
 * marks the internal Order PAID, records the coupon redemption, decrements
 * inventory, and clears the purchased items from the customer's DB cart.
 *
 * Idempotent by construction: Payment.providerPaymentId is unique, so this
 * always resolves to the same Payment row, and every write is guarded by
 * checking the row's current status first. Called from both the capture
 * API route (browser return) and the webhook handler — neither is treated
 * as the sole source of truth; whichever runs first wins, the other is a
 * safe no-op that returns the existing result.
 *
 * Known limitation: guarded by an application-level status check rather
 * than a DB row lock (`SELECT ... FOR UPDATE`). Two truly simultaneous
 * calls could both pass the check before either writes. Recommended
 * hardening before high traffic: wrap the read+write in
 * `prisma.$transaction` using `queryRawUnsafe` with `FOR UPDATE`, or a
 * Postgres advisory lock keyed on the PayPal order id.
 */
export async function capturePaymentAndFinalizeOrder(
  paypalOrderId: string
): Promise<FinalizeCaptureResult> {
  const payment = await prisma.payment.findUnique({
    where: { providerPaymentId: paypalOrderId },
    include: { order: { include: { items: true } } },
  });

  if (!payment) {
    return { status: "not_found" };
  }

  if (payment.status === "CAPTURED") {
    return {
      status: "already_captured",
      orderId: payment.order.id,
      orderNumber: payment.order.orderNumber,
      guestToken: payment.order.guestToken,
    };
  }

  let captureResult;
  try {
    captureResult = await capturePayPalOrder(paypalOrderId);
  } catch {
    // Previously unguarded: a PayPal network failure or misconfiguration
    // here would throw uncaught out of this function, through a capture
    // route that (before this QA pass) also had no try/catch, resulting
    // in an unhandled 500. Fail into a clean, typed result instead —
    // Payment status is left as-is (not FAILED) since we don't actually
    // know PayPal's side of this attempt; it can be retried safely.
    return { status: "provider_error" };
  }

  if (captureResult.captureStatus !== "COMPLETED") {
    await prisma.payment.update({
      where: { id: payment.id },
      data: { status: "FAILED" },
    });
    return { status: "not_completed" };
  }

  const order = payment.order;

  // Verify the provider-reported capture matches the exact server-side
  // order before changing any local payment/order state. This prevents a
  // mismatched provider response from ever being recorded as a successful
  // payment.
  const capturedAmount = captureResult.amount;
  const capturedCurrency = captureResult.currency;
  if (
    capturedAmount == null ||
    capturedCurrency !== order.currency ||
    Number(capturedAmount).toFixed(2) !== Number(order.total).toFixed(2)
  ) {
    await prisma.payment.update({
      where: { id: payment.id },
      data: { status: "FAILED" },
    });
    return { status: "not_completed" };
  }

  await prisma.$transaction(async (tx) => {
    // Re-check inside the transaction — narrows (does not eliminate) the
    // race window described above.
    const freshPayment = await tx.payment.findUnique({
      where: { id: payment.id },
    });
    if (freshPayment?.status === "CAPTURED") return;

    await tx.payment.update({
      where: { id: payment.id },
      data: { status: "CAPTURED" },
    });

    await tx.order.update({
      where: { id: order.id },
      data: { status: "PAID" },
    });

    if (order.couponId) {
      await tx.couponRedemption
        .create({
          data: {
            couponId: order.couponId,
            userId: order.userId ?? undefined,
            email: order.email,
            orderId: order.id,
          },
        })
        .catch(() => {
          // orderId is unique — a duplicate create means this was already
          // redeemed (e.g. a concurrent webhook + browser return). Safe to
          // ignore, this is exactly the idempotency this guards against.
        });
    }

    if (!order.inventoryDecremented) {
      for (const item of order.items) {
        if (!item.productId) continue;
        await tx.product.update({
          where: { id: item.productId },
          data: { inventory: { decrement: item.quantity } },
        });
      }
      await tx.order.update({
        where: { id: order.id },
        data: { inventoryDecremented: true },
      });
    }

    if (order.userId) {
      const purchasedProductIds = order.items
        .map((i) => i.productId)
        .filter((id): id is string => !!id);
      const cart = await tx.cart.findUnique({ where: { userId: order.userId } });
      if (cart && purchasedProductIds.length > 0) {
        await tx.cartItem.deleteMany({
          where: { cartId: cart.id, productId: { in: purchasedProductIds } },
        });
      }
    }
  });

  return {
    status: "captured",
    orderId: order.id,
    orderNumber: order.orderNumber,
    guestToken: order.guestToken,
  };
}
