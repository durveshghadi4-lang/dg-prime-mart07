/**
 * Central storefront configuration.
 *
 * These values are read from environment variables so they can be changed
 * per environment (and eventually from an admin settings screen backed by
 * the `settings` table) without touching UI code. Sensible defaults are
 * provided for local development only.
 */

export const siteConfig = {
  name: "DG PRIME MART",
  tagline: "Everyday Elegance, Effortless Living.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  defaultCurrency: "INR" as const,
  supportedCurrencies: ["INR", "USD", "GBP", "CAD", "AUD", "EUR"] as const,
};

export const shippingConfig = {
  /**
   * Free-shipping threshold, in the store's default currency (minor unit
   * agnostic — treat as a whole-currency amount, e.g. 5000 = ₹5,000).
   * TODO(backend): move this to the `settings` table and read it via an
   * admin-configurable API once the database exists. Every UI surface
   * should import this constant rather than hardcoding the number.
   */
  freeShippingThreshold: Number(
    process.env.NEXT_PUBLIC_FREE_SHIPPING_THRESHOLD ?? 5000
  ),
  freeShippingCurrency: "INR" as const,
  /**
   * Flat shipping charge applied when the order subtotal is below the free
   * threshold. Intentionally simple — not a real shipping-rate engine.
   * Read from lib/checkout-server.ts for the server-side total; swap for a
   * real provider call (weight/destination-based) later without changing
   * where it's read from.
   */
  standardShippingCharge: Number(
    process.env.NEXT_PUBLIC_STANDARD_SHIPPING_CHARGE ?? 99
  ),
};

export const whatsappConfig = {
  /**
   * E.164 format, no leading "+", e.g. "919876543210".
   * Must be set via environment variable — intentionally left blank so a
   * placeholder number is never shipped to production by accident.
   */
  number: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "",
  welcomeMessage:
    process.env.NEXT_PUBLIC_WHATSAPP_MESSAGE ??
    "Hi DG PRIME MART! I have a question about your products.",
};

export function formatPrice(
  amount: number,
  currency: string = siteConfig.defaultCurrency
): string {
  try {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency,
      maximumFractionDigits: 0,
    }).format(amount);
  } catch {
    return `${currency} ${amount.toFixed(0)}`;
  }
}
