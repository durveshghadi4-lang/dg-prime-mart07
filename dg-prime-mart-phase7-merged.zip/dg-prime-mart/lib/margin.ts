/**
 * Estimated Gross Margin = customer revenue for the line − supplier product
 * cost − supplier shipping cost. This is an ESTIMATE for admin
 * decision-making at approval time, not a real profit/accounting figure —
 * it ignores payment processing fees, returns, taxes, etc. Always label it
 * "Estimated Gross Margin" in the UI, never "Profit".
 */
export interface MarginInput {
  customerRevenue: number;
  supplierCost: number | null;
  supplierShippingCost: number | null;
  quantity: number;
}

export interface MarginResult {
  estimable: boolean;
  estimatedGrossMargin: number | null;
  supplierTotal: number | null;
}

export function estimateGrossMargin(input: MarginInput): MarginResult {
  if (input.supplierCost == null) {
    return { estimable: false, estimatedGrossMargin: null, supplierTotal: null };
  }

  const supplierTotal =
    input.supplierCost * input.quantity + (input.supplierShippingCost ?? 0);
  const estimatedGrossMargin =
    Math.round((input.customerRevenue - supplierTotal) * 100) / 100;

  return { estimable: true, estimatedGrossMargin, supplierTotal };
}
