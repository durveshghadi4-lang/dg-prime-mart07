import { describe, it, expect } from "vitest";
import { buildCjOrderPayload } from "@/lib/fulfillment-server";

const completeAddress = {
  firstName: "Asha",
  lastName: "Rao",
  addressLine1: "12 MG Road",
  addressLine2: "Apt 4B",
  city: "Bengaluru",
  state: "Karnataka",
  postalCode: "560001",
  country: "IN",
  phone: "9876543210",
};

describe("buildCjOrderPayload", () => {
  it("builds a valid payload when the address and every item are mapped", () => {
    const result = buildCjOrderPayload({
      orderNumber: "DGPM-TEST-0001",
      shippingAddress: completeAddress,
      items: [{ supplierVariantId: "cj-variant-1", quantity: 2 }],
    });

    expect("error" in result).toBe(false);
    if ("error" in result) return;
    expect(result.orderNumber).toBe("DGPM-TEST-0001");
    expect(result.shippingCustomerName).toBe("Asha Rao");
    expect(result.shippingAddress).toBe("12 MG Road, Apt 4B");
    expect(result.shippingCity).toBe("Bengaluru");
    expect(result.shippingProvince).toBe("Karnataka");
    expect(result.shippingZip).toBe("560001");
    expect(result.shippingCountryCode).toBe("IN");
    expect(result.products).toEqual([{ vid: "cj-variant-1", quantity: 2 }]);
  });

  it("omits the optional address line 2 cleanly when absent", () => {
    const result = buildCjOrderPayload({
      orderNumber: "DGPM-TEST-0002",
      shippingAddress: { ...completeAddress, addressLine2: undefined },
      items: [{ supplierVariantId: "cj-variant-1", quantity: 1 }],
    });
    expect("error" in result).toBe(false);
    if ("error" in result) return;
    expect(result.shippingAddress).toBe("12 MG Road");
  });

  it("rejects an incomplete shipping address rather than sending a partial one", () => {
    const result = buildCjOrderPayload({
      orderNumber: "DGPM-TEST-0003",
      shippingAddress: { ...completeAddress, postalCode: undefined },
      items: [{ supplierVariantId: "cj-variant-1", quantity: 1 }],
    });
    expect("error" in result).toBe(true);
  });

  it("rejects when any item has no supplier variant mapping", () => {
    const result = buildCjOrderPayload({
      orderNumber: "DGPM-TEST-0004",
      shippingAddress: completeAddress,
      items: [
        { supplierVariantId: "cj-variant-1", quantity: 1 },
        { supplierVariantId: null, quantity: 1 },
      ],
    });
    expect("error" in result).toBe(true);
    if (!("error" in result)) return;
    expect(result.error).toMatch(/supplier variant mapping/i);
  });

  it("never includes anything resembling a credential in the payload", () => {
    const result = buildCjOrderPayload({
      orderNumber: "DGPM-TEST-0005",
      shippingAddress: completeAddress,
      items: [{ supplierVariantId: "cj-variant-1", quantity: 1 }],
    });
    const serialized = JSON.stringify(result);
    expect(serialized).not.toMatch(/apiKey|password|secret|token/i);
  });
});
