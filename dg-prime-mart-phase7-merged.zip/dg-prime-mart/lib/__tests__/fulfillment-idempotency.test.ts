import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock every external dependency before importing the module under test,
// so no real database or CJ call can ever happen from this test file.
vi.mock("@/lib/prisma", () => ({
  prisma: {
    fulfillment: {
      findUnique: vi.fn(),
      updateMany: vi.fn(),
      update: vi.fn(),
    },
  },
}));

vi.mock("@/lib/audit", () => ({
  writeAuditLog: vi.fn(),
}));

vi.mock("@/lib/cj-dropshipping", () => ({
  isCjConfigured: vi.fn(),
  createCjOrder: vi.fn(),
}));

import { prisma } from "@/lib/prisma";
import { writeAuditLog } from "@/lib/audit";
import { isCjConfigured, createCjOrder } from "@/lib/cj-dropshipping";
import { submitFulfillmentToSupplier } from "@/lib/fulfillment-server";

const admin = { id: "admin-1", email: "admin@dgprimemart.test" };

const baseOrder = {
  orderNumber: "DGPM-TEST-0001",
  shippingAddressSnapshot: {
    firstName: "Asha",
    lastName: "Rao",
    addressLine1: "12 MG Road",
    city: "Bengaluru",
    state: "Karnataka",
    postalCode: "560001",
    country: "IN",
  },
  items: [
    {
      quantity: 1,
      product: { supplierVariantId: "cj-variant-1" },
    },
  ],
};

function fulfillmentFixture(status: string, overrides: Record<string, unknown> = {}) {
  return {
    id: "fulfillment-1",
    status,
    supplierOrderId: null,
    order: baseOrder,
    ...overrides,
  };
}

beforeEach(() => {
  vi.mocked(isCjConfigured).mockReset().mockReturnValue(true);
  vi.mocked(createCjOrder).mockReset();
  vi.mocked(prisma.fulfillment.findUnique).mockReset();
  vi.mocked(prisma.fulfillment.updateMany).mockReset();
  vi.mocked(prisma.fulfillment.update).mockReset();
  vi.mocked(writeAuditLog).mockReset();
});

describe("submitFulfillmentToSupplier", () => {
  it("refuses to run at all when CJ is not configured — never touches the database", async () => {
    vi.mocked(isCjConfigured).mockReturnValue(false);

    const result = await submitFulfillmentToSupplier("fulfillment-1", admin);

    expect(result).toEqual({ status: "not_configured" });
    expect(prisma.fulfillment.findUnique).not.toHaveBeenCalled();
  });

  it("returns not_found for a nonexistent fulfillment", async () => {
    vi.mocked(prisma.fulfillment.findUnique).mockResolvedValue(null as never);

    const result = await submitFulfillmentToSupplier("missing", admin);

    expect(result).toEqual({ status: "not_found" });
  });

  it("refuses to submit a PENDING_APPROVAL fulfillment — the core safety rule", async () => {
    vi.mocked(prisma.fulfillment.findUnique).mockResolvedValue(
      fulfillmentFixture("PENDING_APPROVAL") as never
    );

    const result = await submitFulfillmentToSupplier("fulfillment-1", admin);

    expect(result).toEqual({ status: "not_approved", currentStatus: "PENDING_APPROVAL" });
    expect(createCjOrder).not.toHaveBeenCalled();
    expect(prisma.fulfillment.updateMany).not.toHaveBeenCalled();
  });

  it("refuses to submit a CANCELLED fulfillment", async () => {
    vi.mocked(prisma.fulfillment.findUnique).mockResolvedValue(
      fulfillmentFixture("CANCELLED") as never
    );

    const result = await submitFulfillmentToSupplier("fulfillment-1", admin);

    expect(result.status).toBe("not_approved");
    expect(createCjOrder).not.toHaveBeenCalled();
  });

  it("is idempotent: an already-SUBMITTED fulfillment short-circuits without calling CJ again", async () => {
    vi.mocked(prisma.fulfillment.findUnique).mockResolvedValue(
      fulfillmentFixture("SUBMITTED", { supplierOrderId: "cj-order-123" }) as never
    );

    const result = await submitFulfillmentToSupplier("fulfillment-1", admin);

    expect(result).toEqual({
      status: "already_submitted",
      supplierOrderId: "cj-order-123",
      fulfillmentStatus: "SUBMITTED",
    });
    expect(createCjOrder).not.toHaveBeenCalled();
    expect(prisma.fulfillment.updateMany).not.toHaveBeenCalled();
  });

  it("reports an in-progress submission instead of racing a second CJ call", async () => {
    vi.mocked(prisma.fulfillment.findUnique).mockResolvedValue(
      fulfillmentFixture("SUBMITTING") as never
    );

    const result = await submitFulfillmentToSupplier("fulfillment-1", admin);

    expect(result).toEqual({ status: "submission_in_progress" });
    expect(createCjOrder).not.toHaveBeenCalled();
  });

  it("submits successfully when APPROVED, claims the row, and records the CJ order id", async () => {
    vi.mocked(prisma.fulfillment.findUnique).mockResolvedValue(
      fulfillmentFixture("APPROVED") as never
    );
    vi.mocked(prisma.fulfillment.updateMany).mockResolvedValue({ count: 1 } as never);
    vi.mocked(createCjOrder).mockResolvedValue({
      cjOrderId: "cj-order-999",
      raw: {},
    });

    const result = await submitFulfillmentToSupplier("fulfillment-1", admin);

    expect(result).toEqual({ status: "submitted", supplierOrderId: "cj-order-999" });
    // The atomic claim must be conditioned on status still being APPROVED.
    expect(prisma.fulfillment.updateMany).toHaveBeenCalledWith({
      where: { id: "fulfillment-1", status: "APPROVED" },
      data: { status: "SUBMITTING" },
    });
    expect(createCjOrder).toHaveBeenCalledTimes(1);
    expect(prisma.fulfillment.update).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { id: "fulfillment-1" },
        data: expect.objectContaining({
          status: "SUBMITTED",
          supplierOrderId: "cj-order-999",
          submittedById: admin.id,
          submittedByEmailSnapshot: admin.email,
        }),
      })
    );
    expect(writeAuditLog).toHaveBeenCalledWith(
      expect.objectContaining({ action: "fulfillment.submit" })
    );
  });

  it("loses the claim race gracefully: if another request already advanced it, no second CJ call happens", async () => {
    vi.mocked(prisma.fulfillment.findUnique)
      .mockResolvedValueOnce(fulfillmentFixture("APPROVED") as never)
      // Re-fetch after losing the race sees the other request's result.
      .mockResolvedValueOnce(
        fulfillmentFixture("SUBMITTED", { supplierOrderId: "cj-order-777" }) as never
      );
    vi.mocked(prisma.fulfillment.updateMany).mockResolvedValue({ count: 0 } as never);

    const result = await submitFulfillmentToSupplier("fulfillment-1", admin);

    expect(result).toEqual({
      status: "already_submitted",
      supplierOrderId: "cj-order-777",
      fulfillmentStatus: "SUBMITTED",
    });
    expect(createCjOrder).not.toHaveBeenCalled();
  });

  it("releases the claim back to APPROVED (not stuck, not falsely SUBMITTED) when CJ's API call fails", async () => {
    vi.mocked(prisma.fulfillment.findUnique).mockResolvedValue(
      fulfillmentFixture("APPROVED") as never
    );
    vi.mocked(prisma.fulfillment.updateMany).mockResolvedValue({ count: 1 } as never);
    vi.mocked(createCjOrder).mockRejectedValue(new Error("CJ sandbox: variant not found"));

    const result = await submitFulfillmentToSupplier("fulfillment-1", admin);

    expect(result).toEqual({
      status: "supplier_error",
      error: "CJ sandbox: variant not found",
    });
    expect(prisma.fulfillment.update).toHaveBeenCalledWith({
      where: { id: "fulfillment-1" },
      data: { status: "APPROVED", lastSubmissionError: "CJ sandbox: variant not found" },
    });
    expect(writeAuditLog).toHaveBeenCalledWith(
      expect.objectContaining({ action: "fulfillment.submit_failed" })
    );
  });

  it("rejects and reverts the claim when supplier mapping is incomplete, without calling CJ", async () => {
    vi.mocked(prisma.fulfillment.findUnique).mockResolvedValue(
      fulfillmentFixture("APPROVED", {
        order: {
          ...baseOrder,
          items: [{ quantity: 1, product: { supplierVariantId: null } }],
        },
      }) as never
    );
    vi.mocked(prisma.fulfillment.updateMany).mockResolvedValue({ count: 1 } as never);

    const result = await submitFulfillmentToSupplier("fulfillment-1", admin);

    expect(result.status).toBe("invalid_payload");
    expect(createCjOrder).not.toHaveBeenCalled();
    expect(prisma.fulfillment.update).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ status: "APPROVED" }) })
    );
  });
});
