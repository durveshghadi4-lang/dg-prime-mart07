import { prisma } from "@/lib/prisma";
import { getLowStockThreshold } from "@/lib/settings";

export async function getDashboardMetrics() {
  const lowStockThreshold = await getLowStockThreshold();

  const [
    totalOrders,
    paidOrders,
    awaitingApproval,
    customers,
    products,
    lowStockProducts,
    revenueAgg,
    recentOrders,
  ] = await Promise.all([
    prisma.order.count(),
    prisma.order.count({ where: { status: "PAID" } }),
    prisma.fulfillment.count({ where: { status: "PENDING_APPROVAL" } }),
    prisma.user.count({ where: { role: "CUSTOMER" } }),
    prisma.product.count(),
    prisma.product.count({
      where: { inventory: { lte: lowStockThreshold }, isActive: true },
    }),
    // Revenue = sum of `total` across orders that have actually been paid
    // or progressed further — never PENDING_PAYMENT/CANCELLED.
    prisma.order.aggregate({
      _sum: { total: true },
      where: {
        status: {
          notIn: ["PENDING_PAYMENT", "CANCELLED"],
        },
      },
    }),
    prisma.order.findMany({
      orderBy: { createdAt: "desc" },
      take: 8,
      select: {
        id: true,
        orderNumber: true,
        email: true,
        status: true,
        total: true,
        currency: true,
        createdAt: true,
      },
    }),
  ]);

  return {
    totalOrders,
    paidOrders,
    awaitingApproval,
    customers,
    products,
    lowStockProducts,
    lowStockThreshold,
    revenue: Number(revenueAgg._sum.total ?? 0),
    recentOrders,
  };
}
