import { auth } from "@/auth";

export class UnauthorizedError extends Error {}
export class ForbiddenError extends Error {}

/**
 * Verifies a real session exists AND its role is ADMIN, straight from the
 * database-backed JWT session — never from anything the client claims.
 * Throws rather than returning a nullable value so callers can't
 * accidentally proceed on a falsy-but-unchecked result.
 *
 * Use this in every admin API route and every admin page/server action.
 * middleware.ts is the first line of defense (redirects at the edge); this
 * is the second, authoritative one that actually gates the database call.
 */
export async function requireAdmin() {
  const session = await auth();
  if (!session?.user) {
    throw new UnauthorizedError("Not authenticated.");
  }
  if (session.user.role !== "ADMIN") {
    throw new ForbiddenError("Admin access required.");
  }
  return session.user;
}
