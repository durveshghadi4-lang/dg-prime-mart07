import { prisma } from "@/lib/prisma";
import { writeAuditLog } from "@/lib/audit";
import {
  createCjOrder,
  isCjConfigured,
  type CreateCjOrderParams,
  type CjOrderProductLine,
} from "@/lib/cj-dropshipping";

export interface ShippingAddressSnapshot {
  firstName?: string;
  lastName?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country?: string;
  phone?: string;
}

/**
 * Pure function — builds the exact payload that will be sent to CJ from
 * our own order/item/address data. Exported and kept side-effect-free
 * specifically so it can be unit tested without a database or network
 * call (see lib/__tests__/cj-payload.test.ts).
 */
export function buildCjOrderPayload(params: {
  orderNumber: string;
  shippingAddress: ShippingAddressSnapshot;
  items: { supplierVariantId: string | null; quantity: number }[];
}): CreateCjOrderParams | { error: string } {
  const address = params.shippingAddress;
  if (
    !address?.firstName ||
    !address?.addressLine1 ||
    !address?.city ||
    !address?.state ||
    !address?.postalCode ||
    !address?.country
  ) {
    return { error: "Shipping address is incomplete for supplier submission." };
  }

  const unmapped = params.items.filter((i) => !i.supplierVariantId);
  if (unmapped.length > 0) {
    return {
      error:
        "One or more items are missing a supplier variant mapping (set Product.supplierVariantId under Products before submitting).",
    };
  }

  const products: CjOrderProductLine[] = params.items.map((i) => ({
    vid: i.supplierVariantId as string,
    quantity: i.quantity,
  }));

  return {
    orderNumber: params.orderNumber,
    shippingCustomerName: `${address.firstName} ${address.lastName ?? ""}`.trim(),
    shippingCountryCode: address.country,
    shippingProvince: address.state,
    shippingCity: address.city,
    shippingAddress: `${address.addressLine1}${
      address.addressLine2 ? `, ${address.addressLine2}` : ""
    }`,
    shippingZip: address.postalCode,
    shippingPhone: address.phone ?? "",
    products,
  };
}

export type SubmitToSupplierResult =
  | { status: "not_found" }
  | { status: "not_approved"; currentStatus: string }
  | { status: "submission_in_progress" }
  | { status: "already_submitted"; supplierOrderId: string | null; fulfillmentStatus: string }
  | { status: "not_configured" }
  | { status: "invalid_payload"; error: string }
  | { status: "supplier_error"; error: string }
  | { status: "submitted"; supplierOrderId: string };

/**
 * Submits an APPROVED fulfillment to CJ Dropshipping. Safe to call
 * multiple times (double-click, retry, two admin tabs) — see the
 * SUBMITTING claim pattern below for how concurrent calls are resolved
 * without a duplicate supplier order.
 *
 * This function assumes the caller (the API route) has already verified
 * the requester is an authenticated ADMIN — it does not check
 * authorization itself, matching the pattern of the rest of Phase 5's
 * server-only modules. It DOES independently re-verify the Fulfillment's
 * own state before doing anything supplier-facing — never trusts that the
 * caller already checked that part correctly.
 */
export async function submitFulfillmentToSupplier(
  fulfillmentId: string,
  submittedBy: { id: string; email: string }
): Promise<SubmitToSupplierResult> {
  if (!isCjConfigured()) {
    // Fail before ever touching the Fulfillment row — "not configured" is
    // not a state change.
    return { status: "not_configured" };
  }

  const fulfillment = await prisma.fulfillment.findUnique({
    where: { id: fulfillmentId },
    include: {
      order: { include: { items: { include: { product: true } } } },
    },
  });

  if (!fulfillment) {
    return { status: "not_found" };
  }

  // Idempotent short-circuit: already past submission, nothing to do.
  if (
    fulfillment.status === "SUBMITTED" ||
    fulfillment.status === "PROCESSING" ||
    fulfillment.status === "SHIPPED" ||
    fulfillment.status === "DELIVERED"
  ) {
    return {
      status: "already_submitted",
      supplierOrderId: fulfillment.supplierOrderId,
      fulfillmentStatus: fulfillment.status,
    };
  }

  if (fulfillment.status === "SUBMITTING") {
    // Another request currently holds the claim — do not attempt a second
    // concurrent CJ call for the same order.
    return { status: "submission_in_progress" };
  }

  if (fulfillment.status !== "APPROVED") {
    // Covers PENDING_APPROVAL and CANCELLED — the whole point of this
    // phase is that this path is unreachable without prior explicit
    // admin approval.
    return { status: "not_approved", currentStatus: fulfillment.status };
  }

  // Atomic claim: only succeeds if the row is still exactly APPROVED at
  // the moment of the write. This is the real concurrency guard — two
  // simultaneous requests both reading "APPROVED" above will race here,
  // and exactly one `updateMany` call will affect a row (count 1); the
  // other affects zero rows and backs off instead of also calling CJ.
  const claim = await prisma.fulfillment.updateMany({
    where: { id: fulfillmentId, status: "APPROVED" },
    data: { status: "SUBMITTING" },
  });

  if (claim.count === 0) {
    // Lost the race (or status changed between the read above and here).
    // Re-check what actually happened rather than guessing.
    const current = await prisma.fulfillment.findUnique({ where: { id: fulfillmentId } });
    if (!current) return { status: "not_found" };
    if (current.status === "SUBMITTING") return { status: "submission_in_progress" };
    if (["SUBMITTED", "PROCESSING", "SHIPPED", "DELIVERED"].includes(current.status)) {
      return {
        status: "already_submitted",
        supplierOrderId: current.supplierOrderId,
        fulfillmentStatus: current.status,
      };
    }
    return { status: "not_approved", currentStatus: current.status };
  }

  // We now exclusively hold the claim. Build and validate the payload
  // before calling out to CJ.
  const address = fulfillment.order.shippingAddressSnapshot as ShippingAddressSnapshot;
  const payload = buildCjOrderPayload({
    orderNumber: fulfillment.order.orderNumber,
    shippingAddress: address,
    items: fulfillment.order.items.map((item) => ({
      supplierVariantId: item.product?.supplierVariantId ?? null,
      quantity: item.quantity,
    })),
  });

  if ("error" in payload) {
    await prisma.fulfillment.update({
      where: { id: fulfillmentId },
      data: { status: "APPROVED", lastSubmissionError: payload.error },
    });
    return { status: "invalid_payload", error: payload.error };
  }

  try {
    const result = await createCjOrder(payload);

    await prisma.fulfillment.update({
      where: { id: fulfillmentId },
      data: {
        status: "SUBMITTED",
        supplierOrderId: result.cjOrderId,
        submissionSnapshot: payload as object,
        submittedById: submittedBy.id,
        submittedByEmailSnapshot: submittedBy.email,
        submittedAt: new Date(),
        lastSubmissionError: null,
      },
    });

    await writeAuditLog({
      adminId: submittedBy.id,
      action: "fulfillment.submit",
      entityType: "Fulfillment",
      entityId: fulfillmentId,
      metadata: {
        orderNumber: fulfillment.order.orderNumber,
        supplierOrderId: result.cjOrderId,
      },
    });

    return { status: "submitted", supplierOrderId: result.cjOrderId };
  } catch (err) {
    // Release the claim back to APPROVED so this can be retried — a
    // failed CJ call must never leave the row stuck in SUBMITTING, and
    // must never be silently treated as submitted.
    const message = err instanceof Error ? err.message : "CJ submission failed.";
    await prisma.fulfillment.update({
      where: { id: fulfillmentId },
      data: { status: "APPROVED", lastSubmissionError: message },
    });

    await writeAuditLog({
      adminId: submittedBy.id,
      action: "fulfillment.submit_failed",
      entityType: "Fulfillment",
      entityId: fulfillmentId,
      metadata: { orderNumber: fulfillment.order.orderNumber, error: message },
    });

    return { status: "supplier_error", error: message };
  }
}
