import type { Product } from "./types";

/**
 * ⚠️ DEVELOPMENT DEMO DATA — NOT A REAL CATALOG ⚠️
 *
 * The live product catalog starts empty (see PROJECT brief: "Start with an
 * empty catalog"). Everything in this file exists only so the storefront UI
 * has something to render while there is no database and no supplier
 * connection yet.
 *
 * Every entry is flagged `isDemoData: true`, and any component that renders
 * it should visually badge it (see `ProductBadge` "Demo" variant) so it is
 * never mistaken for real inventory. Delete this file's contents (not the
 * file itself — keep the exported empty array so imports don't break) the
 * moment real products exist, or better: swap `getHomepageProducts()` etc.
 * below for real Prisma queries and stop importing from here at all.
 */

const demoProducts: Product[] = [
  {
    id: "demo-1",
    slug: "rose-quartz-facial-roller",
    name: "Rose Quartz Facial Roller",
    shortDescription: "Cooling daily ritual for de-puffing and glow.",
    description:
      "A hand-polished rose quartz roller designed for a slow, five-minute morning ritual. Sample copy — replace once real product content is written.",
    price: 899,
    compareAtPrice: 1199,
    currency: "INR",
    categorySlug: "beauty-personal-care",
    images: [],
    badges: ["sale", "featured"],
    inStock: true,
    isActive: true,
    isDemoData: true,
  },
  {
    id: "demo-2",
    slug: "layered-gold-chain-set",
    name: "Layered Chain Set",
    shortDescription: "Three-piece stackable necklace set.",
    description:
      "A set of three fine chains designed to be worn layered or alone. Sample copy — replace once real product content is written.",
    price: 1499,
    currency: "INR",
    categorySlug: "jewellery-accessories",
    images: [],
    badges: ["new"],
    inStock: true,
    isActive: true,
    isDemoData: true,
  },
  {
    id: "demo-3",
    slug: "linen-table-runner",
    name: "Washed Linen Table Runner",
    shortDescription: "Stonewashed linen in a soft sage tone.",
    description:
      "A relaxed-weight linen runner that softens with every wash. Sample copy — replace once real product content is written.",
    price: 1299,
    currency: "INR",
    categorySlug: "home-living",
    images: [],
    badges: ["featured"],
    inStock: true,
    isActive: true,
    isDemoData: true,
  },
  {
    id: "demo-4",
    slug: "ceramic-pour-over-set",
    name: "Ceramic Pour-Over Set",
    shortDescription: "Hand-glazed dripper with matching mug.",
    description:
      "A two-piece pour-over set glazed in a warm speckled finish. Sample copy — replace once real product content is written.",
    price: 1899,
    currency: "INR",
    categorySlug: "kitchen",
    images: [],
    badges: ["new", "featured"],
    inStock: true,
    isActive: true,
    isDemoData: true,
  },
  {
    id: "demo-5",
    slug: "travel-jewellery-case",
    name: "Travel Jewellery Case",
    shortDescription: "Compact case with velvet-lined compartments.",
    description:
      "A pocket-sized case built to keep rings, studs and chains untangled on the move. Sample copy — replace once real product content is written.",
    price: 799,
    currency: "INR",
    categorySlug: "lifestyle",
    images: [],
    badges: [],
    inStock: false,
    isActive: true,
    isDemoData: true,
  },
  {
    id: "demo-6",
    slug: "soft-knit-comfort-blanket",
    name: "Soft Knit Comfort Blanket",
    shortDescription: "Gentle waffle-knit blanket for little ones.",
    description:
      "A breathable waffle-knit blanket sized for stroller or crib. Sample copy — replace once real product content is written.",
    price: 999,
    compareAtPrice: 1299,
    currency: "INR",
    categorySlug: "kids",
    images: [],
    badges: ["sale"],
    inStock: true,
    isActive: true,
    isDemoData: true,
  },
  {
    id: "demo-7",
    slug: "silk-hair-scrunchie-trio",
    name: "Silk Scrunchie Trio",
    shortDescription: "Mulberry silk scrunchies, set of three.",
    description:
      "Gentle on strands, kind to second-day hair. Sample copy — replace once real product content is written.",
    price: 599,
    currency: "INR",
    categorySlug: "beauty-personal-care",
    images: [],
    badges: ["new"],
    inStock: true,
    isActive: true,
    isDemoData: true,
  },
  {
    id: "demo-8",
    slug: "hammered-brass-earrings",
    name: "Hammered Brass Hoops",
    shortDescription: "Lightweight everyday hoops.",
    description:
      "Hand-hammered brass hoops finished with a tarnish-resistant coat. Sample copy — replace once real product content is written.",
    price: 649,
    currency: "INR",
    categorySlug: "jewellery-accessories",
    images: [],
    badges: [],
    inStock: true,
    isActive: true,
    isDemoData: true,
  },
];

/** All demo products. Prefer the scoped helpers below where possible. */
export function getAllDemoProducts(): Product[] {
  return demoProducts;
}

export function getFeaturedDemoProducts(): Product[] {
  return demoProducts.filter((p) => p.badges.includes("featured"));
}

export function getNewArrivalDemoProducts(): Product[] {
  return demoProducts.filter((p) => p.badges.includes("new"));
}

export function getBestSellerDemoProducts(): Product[] {
  // No real order data exists yet, so "best sellers" is a curated subset of
  // demo data for layout purposes only — not a ranked/computed list.
  return demoProducts.slice(0, 4);
}

export function getDemoProductBySlug(slug: string): Product | undefined {
  return demoProducts.find((p) => p.slug === slug);
}

export function getDemoProductsByCategory(categorySlug: string): Product[] {
  return demoProducts.filter((p) => p.categorySlug === categorySlug);
}
