import { prisma } from "@/lib/prisma";
import { shippingConfig, whatsappConfig, siteConfig } from "@/lib/config";

/**
 * Admin-editable settings, backed by the `Setting` key/value table.
 *
 * IMPORTANT SCOPE NOTE: as of Phase 4, the storefront itself
 * (lib/config.ts) still reads its values from environment variables at
 * build/runtime — it does NOT yet read from this table. This module lets
 * an admin view and persist intended values in the database (useful for
 * the settings page, and for a future phase to switch the storefront over
 * to reading live from here), but changing a value here will not yet
 * change what a customer sees until that wiring is done. This is called
 * out explicitly in the README rather than silently left ambiguous.
 */

export const SETTINGS_KEYS = {
  freeShippingThreshold: "free_shipping_threshold",
  standardShippingCharge: "standard_shipping_charge",
  lowStockThreshold: "low_stock_threshold",
  whatsappNumber: "whatsapp_number",
  whatsappMessage: "whatsapp_message",
  storeName: "store_name",
  storeContactEmail: "store_contact_email",
  defaultCurrency: "default_currency",
} as const;

export type SettingKey = (typeof SETTINGS_KEYS)[keyof typeof SETTINGS_KEYS];

export function getSettingDefaults(): Record<SettingKey, string> {
  return {
    [SETTINGS_KEYS.freeShippingThreshold]: String(
      shippingConfig.freeShippingThreshold
    ),
    [SETTINGS_KEYS.standardShippingCharge]: String(
      shippingConfig.standardShippingCharge
    ),
    [SETTINGS_KEYS.lowStockThreshold]: "5",
    [SETTINGS_KEYS.whatsappNumber]: whatsappConfig.number,
    [SETTINGS_KEYS.whatsappMessage]: whatsappConfig.welcomeMessage,
    [SETTINGS_KEYS.storeName]: siteConfig.name,
    [SETTINGS_KEYS.storeContactEmail]: "",
    [SETTINGS_KEYS.defaultCurrency]: siteConfig.defaultCurrency,
  };
}

/** Merges DB-stored overrides on top of env-derived defaults. */
export async function getAllSettings(): Promise<Record<SettingKey, string>> {
  const defaults = getSettingDefaults();
  const rows = await prisma.setting.findMany();
  const overrides = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return { ...defaults, ...overrides } as Record<SettingKey, string>;
}

export async function updateSetting(key: SettingKey, value: string) {
  await prisma.setting.upsert({
    where: { key },
    update: { value },
    create: { key, value },
  });
}

/** Reads the low-stock threshold as a number, for the inventory page. */
export async function getLowStockThreshold(): Promise<number> {
  const settings = await getAllSettings();
  const parsed = Number(settings[SETTINGS_KEYS.lowStockThreshold]);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : 5;
}
