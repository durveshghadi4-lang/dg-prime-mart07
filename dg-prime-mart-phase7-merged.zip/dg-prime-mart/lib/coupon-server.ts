import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";

export interface CouponValidationInput {
  code: string;
  subtotal: number;
  userId: string | null;
  email: string;
}

export type CouponValidationResult =
  | { valid: true; couponId: string; discount: number }
  | { valid: false; reason: string };

/**
 * Validates a coupon code against every rule in the Phase 3 brief: active,
 * within its date window, minimum order amount, usage limit, per-customer
 * limit, and (for DG10 specifically) first-order-only. This is called at
 * order-creation time (to show the discount) AND re-checked at capture time
 * (to actually record the redemption) — never trust a discount the browser
 * says it already validated.
 */
export async function validateCoupon(
  input: CouponValidationInput
): Promise<CouponValidationResult> {
  const coupon = await prisma.coupon.findUnique({
    where: { code: input.code.trim().toUpperCase() },
  });

  if (!coupon || !coupon.active) {
    return { valid: false, reason: "This coupon code is not valid." };
  }

  const now = new Date();
  if (coupon.startsAt && now < coupon.startsAt) {
    return { valid: false, reason: "This coupon is not active yet." };
  }
  if (coupon.endsAt && now > coupon.endsAt) {
    return { valid: false, reason: "This coupon has expired." };
  }

  if (
    coupon.minimumOrderAmount &&
    input.subtotal < Number(coupon.minimumOrderAmount)
  ) {
    return {
      valid: false,
      reason: `This coupon requires a minimum order of ${coupon.minimumOrderAmount}.`,
    };
  }

  if (coupon.usageLimit != null) {
    const totalRedemptions = await prisma.couponRedemption.count({
      where: { couponId: coupon.id },
    });
    if (totalRedemptions >= coupon.usageLimit) {
      return { valid: false, reason: "This coupon has reached its usage limit." };
    }
  }

  if (coupon.perCustomerLimit != null) {
    const customerRedemptions = await prisma.couponRedemption.count({
      where: {
        couponId: coupon.id,
        OR: [
          input.userId ? { userId: input.userId } : undefined,
          { email: input.email },
        ].filter(Boolean) as Prisma.CouponRedemptionWhereInput[],
      },
    });
    if (customerRedemptions >= coupon.perCustomerLimit) {
      return {
        valid: false,
        reason: "You've already used this coupon.",
      };
    }
  }

  if (coupon.firstOrderOnly) {
    const priorOrders = await prisma.order.count({
      where: {
        status: { notIn: ["PENDING_PAYMENT", "CANCELLED"] },
        OR: [
          input.userId ? { userId: input.userId } : undefined,
          { email: input.email },
        ].filter(Boolean) as Prisma.OrderWhereInput[],
      },
    });
    if (priorOrders > 0) {
      return {
        valid: false,
        reason: "This coupon is only valid on your first order.",
      };
    }
  }

  const discount =
    coupon.discountType === "PERCENTAGE"
      ? Math.round(((input.subtotal * Number(coupon.discountValue)) / 100) * 100) / 100
      : Math.min(Number(coupon.discountValue), input.subtotal);

  return { valid: true, couponId: coupon.id, discount };
}
