import type { Category } from "./types";

/**
 * The six approved storefront categories. Electronics and Fashion are
 * intentionally excluded per the brand brief — do not add them here.
 */
export const categories: Category[] = [
  {
    slug: "beauty-personal-care",
    name: "Beauty & Personal Care",
    description: "Skincare, haircare and self-care essentials.",
  },
  {
    slug: "jewellery-accessories",
    name: "Jewellery & Accessories",
    description: "Everyday pieces that finish a look.",
  },
  {
    slug: "home-living",
    name: "Home & Living",
    description: "Considered pieces for a calmer home.",
  },
  {
    slug: "kitchen",
    name: "Kitchen",
    description: "Tools and tableware for everyday cooking.",
  },
  {
    slug: "lifestyle",
    name: "Lifestyle",
    description: "Small indulgences for daily life.",
  },
  {
    slug: "kids",
    name: "Kids",
    description: "Gentle, thoughtful picks for little ones.",
  },
];

export function getCategoryBySlug(slug: string): Category | undefined {
  return categories.find((c) => c.slug === slug);
}
