import { prisma } from "@/lib/prisma";
import { writeAuditLog } from "@/lib/audit";
import { getCjOrderDetail, isCjConfigured } from "@/lib/cj-dropshipping";

/**
 * Ordering used to make sync monotonic — a stale/out-of-order CJ response
 * must never move a Fulfillment backwards (e.g. reporting DELIVERED, then
 * a later poll returning a cached PROCESSING response must not un-deliver
 * it). CANCELLED is treated as reachable from any pre-DELIVERED state.
 */
const PROGRESSION: Record<string, number> = {
  SUBMITTED: 0,
  PROCESSING: 1,
  SHIPPED: 2,
  DELIVERED: 3,
};

/**
 * Maps CJ's own status vocabulary to ours. Exported and pure so it can be
 * unit tested without any network call. Returns null for anything
 * unrecognized rather than guessing, so an unmapped CJ status is visibly
 * ignored (surfaced via lastSyncSnapshot for a human to check) instead of
 * silently misclassified.
 *
 * ⚠️ Same caveat as the rest of the CJ integration: these exact CJ status
 * strings are unverified against a live account. Adjust this mapping once
 * you see real responses.
 */
export function mapCjStatusToFulfillmentStatus(cjStatus: string | null): string | null {
  if (!cjStatus) return null;
  const normalized = cjStatus.toUpperCase();

  if (["CREATED", "IN_PROCESS", "PAID", "PENDING"].includes(normalized)) return "PROCESSING";
  if (["SHIPPED", "IN_TRANSIT"].includes(normalized)) return "SHIPPED";
  if (["DELIVERED", "COMPLETED"].includes(normalized)) return "DELIVERED";
  if (["CANCELLED", "CANCELED"].includes(normalized)) return "CANCELLED";

  return null;
}

export type SyncResult =
  | { status: "not_found" }
  | { status: "not_submitted"; currentStatus: string }
  | { status: "not_configured" }
  | { status: "provider_error" }
  | { status: "unrecognized_cj_status"; cjStatus: string | null }
  | { status: "no_change"; fulfillmentStatus: string }
  | { status: "updated"; fulfillmentStatus: string };

/**
 * Refreshes one Fulfillment's status/tracking from CJ. Only operates on a
 * Fulfillment already at SUBMITTED, PROCESSING, or SHIPPED — sync is
 * strictly a forward-progress check on an order that was already,
 * separately, explicitly approved and submitted in Phases 4–5. It never
 * creates a Fulfillment, never approves one, and never re-attempts a
 * failed submission — those remain admin actions.
 */
export async function syncFulfillmentStatus(
  fulfillmentId: string,
  actor?: { id: string; email: string }
): Promise<SyncResult> {
  if (!isCjConfigured()) {
    return { status: "not_configured" };
  }

  const fulfillment = await prisma.fulfillment.findUnique({
    where: { id: fulfillmentId },
  });

  if (!fulfillment) {
    return { status: "not_found" };
  }

  if (!["SUBMITTED", "PROCESSING", "SHIPPED"].includes(fulfillment.status)) {
    return { status: "not_submitted", currentStatus: fulfillment.status };
  }

  if (!fulfillment.supplierOrderId) {
    return { status: "not_submitted", currentStatus: fulfillment.status };
  }

  let detail;
  try {
    detail = await getCjOrderDetail(fulfillment.supplierOrderId);
  } catch {
    // QA FIX (Phase 6): consistent with the PayPal capture hardening —
    // a CJ network/config failure during sync must not throw uncaught
    // through the manual-refresh API route or the CJ webhook route.
    // Nothing about the Fulfillment row changes; this is a no-op that can
    // simply be retried (manual refresh, or the next webhook delivery).
    return { status: "provider_error" };
  }
  const mappedStatus = mapCjStatusToFulfillmentStatus(detail.status);

  if (!mappedStatus) {
    await prisma.fulfillment.update({
      where: { id: fulfillmentId },
      data: { lastSyncedAt: new Date(), lastSyncSnapshot: detail.raw as object },
    });
    return { status: "unrecognized_cj_status", cjStatus: detail.status };
  }

  const currentRank = PROGRESSION[fulfillment.status] ?? -1;
  const newRank = PROGRESSION[mappedStatus] ?? -1;
  const isForwardProgress = mappedStatus === "CANCELLED" || newRank > currentRank;

  if (!isForwardProgress) {
    await prisma.fulfillment.update({
      where: { id: fulfillmentId },
      data: { lastSyncedAt: new Date(), lastSyncSnapshot: detail.raw as object },
    });
    return { status: "no_change", fulfillmentStatus: fulfillment.status };
  }

  await prisma.fulfillment.update({
    where: { id: fulfillmentId },
    data: {
      status: mappedStatus,
      trackingNumber: detail.trackingNumber ?? fulfillment.trackingNumber ?? undefined,
      carrier: detail.carrier ?? fulfillment.carrier ?? undefined,
      shippedAt: mappedStatus === "SHIPPED" && !fulfillment.shippedAt ? new Date() : undefined,
      deliveredAt:
        mappedStatus === "DELIVERED" && !fulfillment.deliveredAt ? new Date() : undefined,
      lastSyncedAt: new Date(),
      lastSyncSnapshot: detail.raw as object,
    },
  });

  // Sync can run unattended (webhook or a future cron), in which case
  // there is no real admin actor to attribute this to — AdminAuditLog.adminId
  // is a required FK to a real User, so we only write an entry when a real
  // actor was passed in, rather than faking one or crashing the sync (which
  // has already committed its actual database update above) over a
  // logging failure.
  if (actor) {
    await writeAuditLog({
      adminId: actor.id,
      action: "fulfillment.sync",
      entityType: "Fulfillment",
      entityId: fulfillmentId,
      metadata: { from: fulfillment.status, to: mappedStatus, cjStatus: detail.status },
    });
  }

  return { status: "updated", fulfillmentStatus: mappedStatus };
}
