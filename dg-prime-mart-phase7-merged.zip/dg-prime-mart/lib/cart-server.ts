import { prisma } from "@/lib/prisma";

export interface MergeLine {
  productId: string;
  quantity: number;
}

export interface MergeResult {
  synced: string[];
  /** productIds that don't exist as real DB products yet (e.g. demo data). */
  skipped: string[];
}

/**
 * Merges a guest's local cart lines into that user's DB-backed cart. Any
 * line whose productId doesn't correspond to a real, active Product row is
 * skipped rather than failing the whole request — this is expected while
 * the catalog is still demo-data-only (see lib/demo-data.ts on the
 * frontend). Once real products exist, their ids will resolve and sync
 * normally.
 */
export async function mergeCartForUser(
  userId: string,
  lines: MergeLine[]
): Promise<MergeResult> {
  const cart = await prisma.cart.upsert({
    where: { userId },
    update: {},
    create: { userId },
  });

  const synced: string[] = [];
  const skipped: string[] = [];

  for (const line of lines) {
    const product = await prisma.product.findUnique({
      where: { id: line.productId },
    });

    if (!product || !product.isActive) {
      skipped.push(line.productId);
      continue;
    }

    const existingItem = await prisma.cartItem.findFirst({
      where: { cartId: cart.id, productId: product.id, variantId: null },
    });

    if (existingItem) {
      await prisma.cartItem.update({
        where: { id: existingItem.id },
        data: { quantity: existingItem.quantity + line.quantity },
      });
    } else {
      await prisma.cartItem.create({
        data: {
          cartId: cart.id,
          productId: product.id,
          quantity: line.quantity,
          priceSnapshot: product.price,
        },
      });
    }

    synced.push(line.productId);
  }

  return { synced, skipped };
}

export async function getCartForUser(userId: string) {
  return prisma.cart.findUnique({
    where: { userId },
    include: { items: { include: { product: true, variant: true } } },
  });
}

export async function mergeWishlistForUser(
  userId: string,
  productIds: string[]
): Promise<MergeResult> {
  const wishlist = await prisma.wishlist.upsert({
    where: { userId },
    update: {},
    create: { userId },
  });

  const synced: string[] = [];
  const skipped: string[] = [];

  for (const productId of productIds) {
    const product = await prisma.product.findUnique({
      where: { id: productId },
    });

    if (!product || !product.isActive) {
      skipped.push(productId);
      continue;
    }

    await prisma.wishlistItem.upsert({
      where: {
        wishlistId_productId: { wishlistId: wishlist.id, productId },
      },
      update: {},
      create: { wishlistId: wishlist.id, productId },
    });

    synced.push(productId);
  }

  return { synced, skipped };
}

export async function getWishlistForUser(userId: string) {
  return prisma.wishlist.findUnique({
    where: { userId },
    include: { items: { include: { product: true } } },
  });
}
