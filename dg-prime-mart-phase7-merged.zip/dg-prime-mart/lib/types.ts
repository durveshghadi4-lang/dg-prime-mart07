export type CategorySlug =
  | "beauty-personal-care"
  | "jewellery-accessories"
  | "home-living"
  | "kitchen"
  | "lifestyle"
  | "kids";

export interface Category {
  slug: CategorySlug;
  name: string;
  description: string;
  /** Populated once category imagery exists; falls back to a placeholder swatch. */
  imageUrl?: string;
}

export type ProductBadgeKind = "new" | "sale" | "featured" | "out-of-stock";

export interface Product {
  id: string;
  slug: string;
  name: string;
  shortDescription: string;
  description: string;
  price: number;
  compareAtPrice?: number;
  currency: string;
  categorySlug: CategorySlug;
  images: string[];
  badges: ProductBadgeKind[];
  inStock: boolean;
  isActive: boolean;
  isDemoData?: boolean;
}

export type ProductCardState = "loaded" | "loading" | "unavailable";
