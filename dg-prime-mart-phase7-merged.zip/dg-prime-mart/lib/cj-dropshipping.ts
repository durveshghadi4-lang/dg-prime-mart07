/**
 * Server-side CJ Dropshipping (Open API v2) client.
 *
 * ⚠️ IMPORTANT HONESTY NOTE, read before enabling live mode:
 * This is written against CJ Dropshipping's publicly documented Open API
 * v2 request/response shape (auth → access token → createOrder), but it
 * has NOT been exercised against a live CJ account or sandbox in this
 * environment — there is no network access here, and no CJ credentials
 * were provided. CJ's API has changed shape across versions before.
 * VERIFY every endpoint path and field name against
 * https://developers.cjdropshipping.com/en/api/introduction.html (or
 * whatever the current docs URL is) before flipping CJ_ENVIRONMENT to a
 * real account. Treat this module the way you'd treat any third-party
 * integration written from documentation alone: correct in structure and
 * intent, unverified in exact wire detail until tested against the real
 * API.
 *
 * CJ_API_KEY / CJ_API_SECRET (or CJ_API_EMAIL / CJ_API_PASSWORD,
 * depending on which auth flow your CJ account uses) are read only here,
 * server-side — never referenced from a "use client" file.
 */

export class CjConfigError extends Error {}
export class CjApiError extends Error {
  status: number;
  details: unknown;
  constructor(message: string, status: number, details: unknown) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

function getBaseUrl(): string {
  // CJ does not have a distinct sandbox host publicly documented the way
  // PayPal does — CJ_ENVIRONMENT is kept for forward-compatibility and to
  // make the "not configured for live" gate explicit (see
  // isCjLiveModeEnabled below), not because this URL itself changes today.
  return "https://developers.cjdropshipping.com/api2.0";
}

function requireCredentials(): { email: string; apiKey: string } {
  const email = process.env.CJ_API_EMAIL;
  const apiKey = process.env.CJ_API_KEY;
  if (!email || !apiKey) {
    throw new CjConfigError("CJ_API_EMAIL / CJ_API_KEY are not configured.");
  }
  return { email, apiKey };
}

/**
 * Whether this deployment is configured to actually call CJ. Distinct from
 * having *any* CJ_ vars set — this is the single gate the admin UI and the
 * submission route both check before offering/allowing a real API call,
 * so "not configured" fails safely and visibly instead of throwing deep
 * inside a request.
 */
export function isCjConfigured(): boolean {
  return !!(process.env.CJ_API_EMAIL && process.env.CJ_API_KEY);
}

let cachedToken: { value: string; expiresAt: number } | null = null;

async function getAccessToken(): Promise<string> {
  if (cachedToken && cachedToken.expiresAt > Date.now() + 60_000) {
    return cachedToken.value;
  }

  const { email, apiKey } = requireCredentials();

  const response = await fetch(`${getBaseUrl()}/v1/authentication/getAccessToken`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password: apiKey }),
    cache: "no-store",
  });

  const body = await response.json().catch(() => undefined);

  if (!response.ok || body?.result === false) {
    throw new CjApiError("Failed to authenticate with CJ Dropshipping.", response.status, body);
  }

  const accessToken: string | undefined = body?.data?.accessToken;
  const expiryDate: string | undefined = body?.data?.accessTokenExpiryDate;
  if (!accessToken) {
    throw new CjApiError("CJ auth response did not include an access token.", response.status, body);
  }

  cachedToken = {
    value: accessToken,
    expiresAt: expiryDate ? new Date(expiryDate).getTime() : Date.now() + 3_600_000,
  };

  return accessToken;
}

async function cjFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = await getAccessToken();

  const response = await fetch(`${getBaseUrl()}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      "CJ-Access-Token": token,
      ...init.headers,
    },
    cache: "no-store",
  });

  const body = await response.json().catch(() => undefined);

  if (!response.ok || body?.result === false) {
    throw new CjApiError(`CJ API error on ${path}`, response.status, body);
  }

  return body as T;
}

export interface CjOrderProductLine {
  /** CJ's variant id (Product.supplierVariantId), not our own SKU. */
  vid: string;
  quantity: number;
}

export interface CreateCjOrderParams {
  /** Our own order number, sent as CJ's client-side order reference. */
  orderNumber: string;
  shippingCustomerName: string;
  shippingCountryCode: string;
  shippingProvince: string;
  shippingCity: string;
  shippingAddress: string;
  shippingZip: string;
  shippingPhone: string;
  products: CjOrderProductLine[];
}

export interface CreateCjOrderResult {
  cjOrderId: string;
  raw: unknown;
}

/**
 * Submits an order to CJ. This is the ONLY function in this codebase that
 * makes a real outbound call to CJ Dropshipping — and it is only ever
 * invoked from lib/fulfillment-server.ts, which itself only runs after
 * confirming Fulfillment.status === "APPROVED". There is no other caller.
 */
export async function createCjOrder(
  params: CreateCjOrderParams
): Promise<CreateCjOrderResult> {
  const body = await cjFetch<{ data?: { orderId?: string } }>(
    "/v1/shopping/order/createOrder",
    {
      method: "POST",
      body: JSON.stringify({
        orderNumber: params.orderNumber,
        shippingCustomerName: params.shippingCustomerName,
        shippingCountryCode: params.shippingCountryCode,
        shippingProvince: params.shippingProvince,
        shippingCity: params.shippingCity,
        shippingAddress: params.shippingAddress,
        shippingZip: params.shippingZip,
        shippingPhone: params.shippingPhone,
        fromCountryCode: "CN",
        products: params.products,
      }),
    }
  );

  const cjOrderId = body?.data?.orderId;
  if (!cjOrderId) {
    throw new CjApiError("CJ did not return an order id.", 502, body);
  }

  return { cjOrderId, raw: body };
}

/**
 * CJ's own order status strings, as documented (again: unverified against
 * a live account — see the file-level warning above). Mapped to our
 * FulfillmentStatus by lib/fulfillment-sync.ts rather than stored as-is,
 * so the rest of the app never has to know CJ's specific vocabulary.
 */
export interface CjOrderDetail {
  cjOrderId: string;
  /** CJ's raw status string, e.g. "CREATED" | "IN_PROCESS" | "SHIPPED" | "DELIVERED" | "CANCELLED" — exact values unverified. */
  status: string | null;
  trackingNumber: string | null;
  carrier: string | null;
  raw: unknown;
}

export async function getCjOrderDetail(cjOrderId: string): Promise<CjOrderDetail> {
  const body = await cjFetch<{
    data?: {
      orderId?: string;
      status?: string;
      logisticInfo?: { trackingNumber?: string; logisticName?: string };
    };
  }>("/v1/shopping/order/getOrderDetail", {
    method: "POST",
    body: JSON.stringify({ orderId: cjOrderId }),
  });

  return {
    cjOrderId,
    status: body?.data?.status ?? null,
    trackingNumber: body?.data?.logisticInfo?.trackingNumber ?? null,
    carrier: body?.data?.logisticInfo?.logisticName ?? null,
    raw: body,
  };
}
