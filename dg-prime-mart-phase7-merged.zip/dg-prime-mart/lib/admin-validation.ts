import { z } from "zod";

export const productSchema = z.object({
  name: z.string().trim().min(1).max(200),
  slug: z
    .string()
    .trim()
    .min(1)
    .max(200)
    .regex(/^[a-z0-9-]+$/, "Slug must be lowercase letters, numbers, and hyphens only"),
  description: z.string().trim().min(1),
  shortDescription: z.string().trim().min(1).max(300),
  price: z.number().min(0),
  compareAtPrice: z.number().min(0).nullable().optional(),
  currency: z.string().trim().min(1).max(10),
  sku: z.string().trim().min(1).max(100),
  inventory: z.number().int().min(0),
  categoryId: z.string().min(1),
  supplierId: z.string().min(1).nullable().optional(),
  supplierProductId: z.string().trim().max(200).optional().or(z.literal("")),
  supplierVariantId: z.string().trim().max(200).optional().or(z.literal("")),
  supplierCost: z.number().min(0).nullable().optional(),
  supplierShippingCost: z.number().min(0).nullable().optional(),
  isActive: z.boolean(),
  isFeatured: z.boolean(),
  isNew: z.boolean(),
  seoTitle: z.string().trim().max(200).optional().or(z.literal("")),
  seoDescription: z.string().trim().max(300).optional().or(z.literal("")),
  images: z
    .array(z.object({ url: z.string().trim().min(1), alt: z.string().trim() }))
    .default([]),
  variants: z
    .array(
      z.object({
        name: z.string().trim().min(1),
        sku: z.string().trim().min(1),
        price: z.number().min(0),
        inventory: z.number().int().min(0),
      })
    )
    .default([]),
});

export const couponSchema = z.object({
  code: z.string().trim().min(1).max(50),
  discountType: z.enum(["PERCENTAGE", "FIXED_AMOUNT"]),
  discountValue: z.number().min(0),
  minimumOrderAmount: z.number().min(0).nullable().optional(),
  usageLimit: z.number().int().min(1).nullable().optional(),
  perCustomerLimit: z.number().int().min(1).nullable().optional(),
  firstOrderOnly: z.boolean(),
  active: z.boolean(),
  startsAt: z.string().nullable().optional(),
  endsAt: z.string().nullable().optional(),
});

export const supplierSchema = z.object({
  name: z.string().trim().min(1).max(200),
  provider: z.string().trim().min(1).max(100),
  credentialsRef: z.string().trim().max(200).optional().or(z.literal("")),
  active: z.boolean(),
});
