import { randomBytes } from "crypto";

/**
 * Generates a human-readable, sufficiently-unique order number for display
 * (receipts, confirmation pages, PayPal reference). Uniqueness is enforced
 * at the database level by Order.orderNumber being @unique — this is not
 * itself a guarantee, just a low-collision generator.
 */
export function generateOrderNumber(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `DGPM-${timestamp}-${random}`;
}

/** Opaque, hard-to-guess token for guest order confirmation/tracking links. */
export function generateGuestToken(): string {
  return randomBytes(24).toString("hex");
}
