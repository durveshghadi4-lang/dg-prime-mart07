/**
 * Server-side PayPal REST API client (Orders v2).
 *
 * Every function here makes a real HTTP call to PayPal's sandbox or
 * production API — nothing in this file fabricates a success response.
 * PAYPAL_CLIENT_SECRET is only ever read here (server-side); it must never
 * be referenced from a "use client" file or a NEXT_PUBLIC_ variable.
 */

type PayPalEnvironment = "sandbox" | "production";

function getEnvironment(): PayPalEnvironment {
  const env = process.env.PAYPAL_ENVIRONMENT;
  if (env === "production") return "production";
  return "sandbox";
}

function getBaseUrl(): string {
  return getEnvironment() === "production"
    ? "https://api-m.paypal.com"
    : "https://api-m.sandbox.paypal.com";
}

export class PayPalConfigError extends Error {}
export class PayPalApiError extends Error {
  status: number;
  details: unknown;
  constructor(message: string, status: number, details: unknown) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

function requireCredentials(): { clientId: string; clientSecret: string } {
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    throw new PayPalConfigError(
      "PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET are not configured."
    );
  }
  return { clientId, clientSecret };
}

let cachedToken: { value: string; expiresAt: number } | null = null;

async function getAccessToken(): Promise<string> {
  if (cachedToken && cachedToken.expiresAt > Date.now() + 30_000) {
    return cachedToken.value;
  }

  const { clientId, clientSecret } = requireCredentials();
  const basicAuth = Buffer.from(`${clientId}:${clientSecret}`).toString(
    "base64"
  );

  const response = await fetch(`${getBaseUrl()}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${basicAuth}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
    cache: "no-store",
  });

  if (!response.ok) {
    const details = await response.json().catch(() => undefined);
    throw new PayPalApiError(
      "Failed to authenticate with PayPal.",
      response.status,
      details
    );
  }

  const data = (await response.json()) as {
    access_token: string;
    expires_in: number;
  };

  cachedToken = {
    value: data.access_token,
    expiresAt: Date.now() + data.expires_in * 1000,
  };

  return data.access_token;
}

async function paypalFetch<T>(
  path: string,
  init: RequestInit & { idempotencyKey?: string } = {}
): Promise<T> {
  const token = await getAccessToken();
  const { idempotencyKey, ...rest } = init;

  const response = await fetch(`${getBaseUrl()}${path}`, {
    ...rest,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(idempotencyKey ? { "PayPal-Request-Id": idempotencyKey } : {}),
      ...rest.headers,
    },
    cache: "no-store",
  });

  const body = await response.json().catch(() => undefined);

  if (!response.ok) {
    throw new PayPalApiError(
      `PayPal API error on ${path}`,
      response.status,
      body
    );
  }

  return body as T;
}

export interface CreatePayPalOrderResult {
  paypalOrderId: string;
  status: string;
}

/**
 * Creates a PayPal order for a server-calculated amount. `internalOrderId`
 * is passed as `custom_id` / `reference_id` so a webhook or capture
 * response can always be tied back to our own Order row.
 *
 * `idempotencyKey` should be our internal Order.id — if PayPal receives the
 * same PayPal-Request-Id twice, it returns the original order instead of
 * creating a second one, which is the PayPal-side half of idempotent order
 * creation (the DB-level half is Payment.providerPaymentId being unique).
 */
export async function createPayPalOrder(params: {
  internalOrderId: string;
  amount: string; // decimal string, e.g. "1499.00" — never a float
  currency: string;
}): Promise<CreatePayPalOrderResult> {
  const data = await paypalFetch<{ id: string; status: string }>(
    "/v2/checkout/orders",
    {
      method: "POST",
      idempotencyKey: params.internalOrderId,
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [
          {
            reference_id: params.internalOrderId,
            custom_id: params.internalOrderId,
            amount: {
              currency_code: params.currency,
              value: params.amount,
            },
          },
        ],
      }),
    }
  );

  return { paypalOrderId: data.id, status: data.status };
}

export interface CapturePayPalOrderResult {
  paypalOrderId: string;
  status: string;
  captureId?: string;
  captureStatus?: string;
  amount?: string;
  currency?: string;
}

/**
 * Captures a previously-created PayPal order. This is the ONLY place a
 * payment is confirmed successful — never infer success from a browser
 * redirect alone. Returns whatever PayPal actually reports; callers must
 * check `captureStatus === "COMPLETED"` before treating the order as paid.
 */
export async function capturePayPalOrder(
  paypalOrderId: string
): Promise<CapturePayPalOrderResult> {
  const data = await paypalFetch<{
    id: string;
    status: string;
    purchase_units?: Array<{
      payments?: {
        captures?: Array<{
          id: string;
          status: string;
          amount?: { value: string; currency_code: string };
        }>;
      };
    }>;
  }>(`/v2/checkout/orders/${paypalOrderId}/capture`, {
    method: "POST",
    idempotencyKey: `capture:${paypalOrderId}`,
  });

  const capture = data.purchase_units?.[0]?.payments?.captures?.[0];

  return {
    paypalOrderId: data.id,
    status: data.status,
    captureId: capture?.id,
    captureStatus: capture?.status,
    amount: capture?.amount?.value,
    currency: capture?.amount?.currency_code,
  };
}

export async function getPayPalOrder(paypalOrderId: string) {
  return paypalFetch<{ id: string; status: string }>(
    `/v2/checkout/orders/${paypalOrderId}`,
    { method: "GET" }
  );
}

/**
 * Verifies a webhook's authenticity via PayPal's verify-webhook-signature
 * API. Requires PAYPAL_WEBHOOK_ID (from the webhook's configuration in the
 * PayPal developer dashboard). Returns false (rather than throwing) on a
 * config gap so the caller can respond safely instead of crashing.
 */
export async function verifyWebhookSignature(params: {
  headers: {
    transmissionId: string;
    transmissionTime: string;
    certUrl: string;
    authAlgo: string;
    transmissionSig: string;
  };
  webhookEvent: unknown;
}): Promise<boolean> {
  const webhookId = process.env.PAYPAL_WEBHOOK_ID;
  if (!webhookId) return false;

  try {
    const result = await paypalFetch<{ verification_status: string }>(
      "/v1/notifications/verify-webhook-signature",
      {
        method: "POST",
        body: JSON.stringify({
          transmission_id: params.headers.transmissionId,
          transmission_time: params.headers.transmissionTime,
          cert_url: params.headers.certUrl,
          auth_algo: params.headers.authAlgo,
          transmission_sig: params.headers.transmissionSig,
          webhook_id: webhookId,
          webhook_event: params.webhookEvent,
        }),
      }
    );
    return result.verification_status === "SUCCESS";
  } catch {
    return false;
  }
}
