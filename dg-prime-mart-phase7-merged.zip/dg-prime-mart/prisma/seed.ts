import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

// ⚠️ This seed intentionally does NOT create any Product rows. The catalog
// starts empty until real products are approved/imported — see README.

const categories = [
  { name: "Beauty & Personal Care", slug: "beauty-personal-care", sortOrder: 1 },
  { name: "Jewellery & Accessories", slug: "jewellery-accessories", sortOrder: 2 },
  { name: "Home & Living", slug: "home-living", sortOrder: 3 },
  { name: "Kitchen", slug: "kitchen", sortOrder: 4 },
  { name: "Lifestyle", slug: "lifestyle", sortOrder: 5 },
  { name: "Kids", slug: "kids", sortOrder: 6 },
];

async function main() {
  for (const category of categories) {
    await prisma.category.upsert({
      where: { slug: category.slug },
      update: { name: category.name, sortOrder: category.sortOrder },
      create: category,
    });
  }
  console.log(`Seeded ${categories.length} categories.`);

  await prisma.coupon.upsert({
    where: { code: "DG10" },
    update: { firstOrderOnly: true },
    create: {
      code: "DG10",
      discountType: "PERCENTAGE",
      discountValue: 10,
      perCustomerLimit: 1,
      firstOrderOnly: true,
      active: true,
    },
  });
  console.log("Seeded DG10 coupon (10% off, first order only, once per customer).");

  // Optional development admin account — only created if both env vars are
  // set. Never hard-code a password here.
  const adminEmail = process.env.SEED_ADMIN_EMAIL;
  const adminPassword = process.env.SEED_ADMIN_PASSWORD;

  if (adminEmail && adminPassword) {
    const passwordHash = await bcrypt.hash(adminPassword, 12);
    await prisma.user.upsert({
      where: { email: adminEmail },
      update: { role: "ADMIN" },
      create: {
        email: adminEmail,
        name: "Admin",
        passwordHash,
        role: "ADMIN",
      },
    });
    console.log(`Seeded admin account for ${adminEmail}.`);
  } else {
    console.log(
      "SEED_ADMIN_EMAIL / SEED_ADMIN_PASSWORD not set — skipping admin account seed."
    );
  }
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
