export function PageHeader({
  title,
  description,
}: {
  title: string;
  description?: string;
}) {
  return (
    <div className="border-b border-line bg-parchment">
      <div className="mx-auto max-w-container px-4 py-10 sm:px-6 lg:px-8">
        <h1 className="font-display text-3xl text-ink sm:text-4xl">{title}</h1>
        {description && (
          <p className="mt-2 max-w-xl text-sm text-stone">{description}</p>
        )}
      </div>
    </div>
  );
}
