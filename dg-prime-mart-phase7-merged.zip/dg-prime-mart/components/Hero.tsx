import Link from "next/link";
import { PlaceholderArt } from "./PlaceholderArt";

export function Hero() {
  return (
    <section className="border-b border-line bg-parchment">
      <div className="mx-auto grid max-w-container items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16 lg:px-8 lg:py-20">
        <div className="max-w-xl">
          <p className="eyebrow mb-4">DG PRIME MART</p>
          <h1 className="font-display text-4xl leading-[1.08] text-ink sm:text-5xl lg:text-[3.4rem]">
            Everything she loves. Beautifully curated.
          </h1>
          <p className="mt-5 max-w-md text-base text-ink/70 sm:text-lg">
            Considered pieces for beauty, home, and everyday life — chosen
            for women who want elegance without excess.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Link
              href="/shop"
              className="inline-flex items-center justify-center rounded-full bg-ink px-7 py-3 text-sm font-medium text-ivory transition-colors hover:bg-bottle"
            >
              Shop Collection
            </Link>
            <Link
              href="/shop"
              className="inline-flex items-center justify-center rounded-full border border-ink/20 px-7 py-3 text-sm font-medium text-ink transition-colors hover:border-ink"
            >
              Explore Categories
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <PlaceholderArt
            seed="hero-1"
            categorySlug="jewellery-accessories"
            className="aspect-[3/4] rounded-3xl"
          />
          <div className="mt-8 flex flex-col gap-4">
            <PlaceholderArt
              seed="hero-2"
              categorySlug="beauty-personal-care"
              className="aspect-square rounded-3xl"
            />
            <PlaceholderArt
              seed="hero-3"
              categorySlug="home-living"
              className="aspect-[4/3] rounded-3xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
