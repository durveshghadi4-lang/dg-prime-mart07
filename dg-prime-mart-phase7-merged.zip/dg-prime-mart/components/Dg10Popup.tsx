"use client";

import { useEffect, useState } from "react";

const STORAGE_KEY = "dgpm:dg10-popup-status";
type StoredStatus = "subscribed" | "dismissed";

/**
 * Coupon application is UI/state-only here — it stores that the visitor
 * "claimed" DG10 locally so the popup doesn't repeat itself. Actual coupon
 * validation and redemption should go through the real coupon system
 * (`coupons` / `coupon_redemptions` tables) once the backend exists; this
 * component should then just call that API on submit.
 */
export function Dg10Popup() {
  const [visible, setVisible] = useState(false);
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "submitting" | "success">(
    "idle"
  );

  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY) as
      | StoredStatus
      | null;
    if (stored) return;

    const timer = window.setTimeout(() => setVisible(true), 2500);
    return () => window.clearTimeout(timer);
  }, []);

  function close(remember: StoredStatus) {
    window.localStorage.setItem(STORAGE_KEY, remember);
    setVisible(false);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.includes("@")) return;
    setStatus("submitting");
    await new Promise((resolve) => setTimeout(resolve, 500));
    // TODO(backend): POST to /api/newsletter + issue/validate DG10 via the
    // real coupon system instead of only remembering this locally.
    setStatus("success");
    window.setTimeout(() => close("subscribed"), 1400);
  }

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-ink/40 p-4 sm:items-center">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="dg10-heading"
        className="relative w-full max-w-sm animate-pop-in rounded-3xl bg-ivory p-7 shadow-card sm:p-8"
      >
        <button
          type="button"
          onClick={() => close("dismissed")}
          aria-label="Close"
          className="absolute right-4 top-4 inline-flex h-8 w-8 items-center justify-center rounded-full text-stone hover:bg-parchment hover:text-ink"
        >
          <svg
            viewBox="0 0 24 24"
            className="h-4 w-4"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            aria-hidden="true"
          >
            <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
          </svg>
        </button>

        {status === "success" ? (
          <div className="py-4 text-center">
            <p className="font-display text-xl text-ink">You're in.</p>
            <p className="mt-2 text-sm text-stone">
              Use code <span className="font-medium text-ink">DG10</span> at
              checkout for 10% off your first order.
            </p>
          </div>
        ) : (
          <>
            <p className="eyebrow mb-2">First order</p>
            <h2 id="dg10-heading" className="font-display text-2xl text-ink">
              Get 10% off with DG10
            </h2>
            <p className="mt-2 text-sm text-stone">
              Join our list for early access and 10% off your first order.
            </p>
            <form onSubmit={handleSubmit} className="mt-5 flex flex-col gap-3">
              <label htmlFor="dg10-email" className="sr-only">
                Email address
              </label>
              <input
                id="dg10-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email"
                className="w-full rounded-full border border-line px-4 py-3 text-sm text-ink outline-none focus:border-brass"
              />
              <button
                type="submit"
                disabled={status === "submitting"}
                className="w-full rounded-full bg-ink px-4 py-3 text-sm font-medium text-ivory transition-colors hover:bg-bottle"
              >
                {status === "submitting" ? "Submitting…" : "Claim 10% off"}
              </button>
            </form>
            <button
              type="button"
              onClick={() => close("dismissed")}
              className="mt-3 w-full text-center text-xs text-stone hover:text-ink"
            >
              No thanks
            </button>
          </>
        )}
      </div>
    </div>
  );
}
