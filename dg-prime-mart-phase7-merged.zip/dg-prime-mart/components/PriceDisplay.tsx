import { formatPrice } from "@/lib/config";

interface PriceDisplayProps {
  price: number;
  compareAtPrice?: number;
  currency: string;
  size?: "sm" | "md" | "lg";
}

const SIZE_CLASSES: Record<NonNullable<PriceDisplayProps["size"]>, string> = {
  sm: "text-sm",
  md: "text-base",
  lg: "text-2xl",
};

export function PriceDisplay({
  price,
  compareAtPrice,
  currency,
  size = "md",
}: PriceDisplayProps) {
  const onSale = typeof compareAtPrice === "number" && compareAtPrice > price;

  return (
    <div className={`flex items-baseline gap-2 ${SIZE_CLASSES[size]}`}>
      <span className="font-display text-ink">
        {formatPrice(price, currency)}
      </span>
      {onSale && (
        <span className="text-stone line-through decoration-1">
          {formatPrice(compareAtPrice, currency)}
        </span>
      )}
    </div>
  );
}
