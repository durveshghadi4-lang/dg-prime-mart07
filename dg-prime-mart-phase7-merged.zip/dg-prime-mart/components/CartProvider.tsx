"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useSession } from "next-auth/react";
import type { Product } from "@/lib/types";

export interface CartLine {
  productId: string;
  slug: string;
  name: string;
  price: number;
  currency: string;
  quantity: number;
}

interface CartContextValue {
  lines: CartLine[];
  wishlist: string[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  setQuantity: (productId: string, quantity: number) => void;
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  subtotal: number;
  itemCount: number;
}

const CartContext = createContext<CartContextValue | null>(null);

const CART_STORAGE_KEY = "dgpm:cart";
const WISHLIST_STORAGE_KEY = "dgpm:wishlist";

/**
 * NOTE: cart/wishlist state is kept in localStorage for now so the UI is
 * fully interactive before a database exists. Once `carts`/`cart_items` and
 * `wishlists`/`wishlist_items` tables are live, replace the read/write calls
 * in this provider with API calls — the consuming components (AddToCartButton,
 * WishlistButton, /cart page) should not need to change.
 */
export function CartProvider({ children }: { children: React.ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const { status } = useSession();
  const hasMergedRef = useRef(false);

  useEffect(() => {
    try {
      const storedCart = window.localStorage.getItem(CART_STORAGE_KEY);
      const storedWishlist = window.localStorage.getItem(WISHLIST_STORAGE_KEY);
      if (storedCart) setLines(JSON.parse(storedCart));
      if (storedWishlist) setWishlist(JSON.parse(storedWishlist));
    } catch {
      // Ignore corrupted local storage — start from an empty cart.
    } finally {
      setHydrated(true);
    }
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(lines));
  }, [lines, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(
      WISHLIST_STORAGE_KEY,
      JSON.stringify(wishlist)
    );
  }, [wishlist, hydrated]);

  // Best-effort DB sync on login. Any line whose product isn't a real DB
  // row yet (all current demo products) comes back in `skipped` and simply
  // stays in local state — see lib/cart-server.ts for why. This never
  // deletes anything from local state, so logging out afterwards leaves the
  // existing local cart/wishlist untouched, per the "guest cart behavior
  // remains safe" requirement.
  useEffect(() => {
    if (!hydrated) return;

    if (status === "authenticated" && !hasMergedRef.current) {
      hasMergedRef.current = true;
      if (lines.length > 0) {
        fetch("/api/cart/merge", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            lines: lines.map((l) => ({
              productId: l.productId,
              quantity: l.quantity,
            })),
          }),
        }).catch(() => {
          // Non-fatal — local cart remains the source of truth for now.
        });
      }
      if (wishlist.length > 0) {
        fetch("/api/wishlist/merge", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ productIds: wishlist }),
        }).catch(() => {
          // Non-fatal — local wishlist remains the source of truth for now.
        });
      }
    }

    if (status === "unauthenticated") {
      // Allow a future login (possibly a different user, same browser) to
      // trigger another merge.
      hasMergedRef.current = false;
    }
  }, [status, hydrated, lines, wishlist]);

  const addToCart = useCallback((product: Product, quantity = 1) => {
    setLines((prev) => {
      const existing = prev.find((l) => l.productId === product.id);
      if (existing) {
        return prev.map((l) =>
          l.productId === product.id
            ? { ...l, quantity: l.quantity + quantity }
            : l
        );
      }
      return [
        ...prev,
        {
          productId: product.id,
          slug: product.slug,
          name: product.name,
          price: product.price,
          currency: product.currency,
          quantity,
        },
      ];
    });
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setLines((prev) => prev.filter((l) => l.productId !== productId));
  }, []);

  const setQuantity = useCallback((productId: string, quantity: number) => {
    setLines((prev) =>
      quantity <= 0
        ? prev.filter((l) => l.productId !== productId)
        : prev.map((l) =>
            l.productId === productId ? { ...l, quantity } : l
          )
    );
  }, []);

  const toggleWishlist = useCallback((productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  }, []);

  const isWishlisted = useCallback(
    (productId: string) => wishlist.includes(productId),
    [wishlist]
  );

  const subtotal = useMemo(
    () => lines.reduce((sum, l) => sum + l.price * l.quantity, 0),
    [lines]
  );

  const itemCount = useMemo(
    () => lines.reduce((sum, l) => sum + l.quantity, 0),
    [lines]
  );

  const value: CartContextValue = {
    lines,
    wishlist,
    addToCart,
    removeFromCart,
    setQuantity,
    toggleWishlist,
    isWishlisted,
    subtotal,
    itemCount,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return ctx;
}
