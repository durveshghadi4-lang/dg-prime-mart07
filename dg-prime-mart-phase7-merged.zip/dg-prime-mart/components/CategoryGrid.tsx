import Link from "next/link";
import { categories } from "@/lib/categories";
import { PlaceholderArt } from "./PlaceholderArt";

export function CategoryGrid() {
  return (
    <section className="mx-auto max-w-container px-4 py-14 sm:px-6 lg:px-8">
      <div className="mb-8 flex items-end justify-between">
        <h2 className="font-display text-2xl text-ink sm:text-3xl">
          Shop by Category
        </h2>
      </div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {categories.map((category) => (
          <Link
            key={category.slug}
            href={`/category/${category.slug}`}
            className="group flex flex-col gap-3"
          >
            <PlaceholderArt
              seed={category.slug}
              categorySlug={category.slug}
              className="aspect-square rounded-2xl transition-transform duration-500 group-hover:scale-[1.03]"
            />
            <span className="text-sm font-medium text-ink">
              {category.name}
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}
