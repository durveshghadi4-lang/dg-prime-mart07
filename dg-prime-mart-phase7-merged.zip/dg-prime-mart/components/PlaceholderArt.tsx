const PALETTES: Record<string, [string, string]> = {
  "beauty-personal-care": ["#E3BCBF", "#C98B90"],
  "jewellery-accessories": ["#C7A876", "#A8854F"],
  "home-living": ["#B9C4B4", "#3B4F42"],
  kitchen: ["#E7D9C2", "#A8854F"],
  lifestyle: ["#D9C6CC", "#A96066"],
  kids: ["#C9D7CE", "#3B4F42"],
  default: ["#E4DCCE", "#8A8078"],
};

interface PlaceholderArtProps {
  seed?: string;
  categorySlug?: string;
  className?: string;
}

/**
 * A soft, on-brand gradient swatch standing in for real product photography.
 * Deliberately abstract (never a fake stock photo) so it can never be
 * mistaken for an actual product image. Swap `ProductImage` to render a real
 * `<img>`/`next/image` once product photos exist.
 */
export function PlaceholderArt({
  seed = "default",
  categorySlug,
  className = "",
}: PlaceholderArtProps) {
  const [from, to] = PALETTES[categorySlug ?? "default"] ?? PALETTES.default!;
  const angle = (hashString(seed) % 60) + 100;

  return (
    <div
      role="img"
      aria-label="Product image placeholder"
      className={`relative overflow-hidden ${className}`}
      style={{
        background: `linear-gradient(${angle}deg, ${from} 0%, ${to} 100%)`,
      }}
    >
      <svg
        className="absolute inset-0 h-full w-full opacity-[0.15]"
        preserveAspectRatio="none"
        viewBox="0 0 100 100"
        aria-hidden="true"
      >
        <circle cx="20" cy="80" r="38" fill="white" />
        <circle cx="85" cy="15" r="26" fill="white" />
      </svg>
    </div>
  );
}

function hashString(input: string): number {
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    hash = (hash << 5) - hash + input.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}
