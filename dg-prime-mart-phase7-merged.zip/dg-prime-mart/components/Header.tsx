"use client";

import { useState } from "react";
import Link from "next/link";
import { categories } from "@/lib/categories";
import { useCart } from "./CartProvider";

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/shop", label: "Shop" },
  ...categories.map((c) => ({ href: `/category/${c.slug}`, label: c.name })),
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { itemCount, wishlist } = useCart();

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-ivory/95 backdrop-blur">
      <div className="mx-auto flex max-w-container items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
        {/* Mobile: hamburger */}
        <button
          type="button"
          onClick={() => setMobileOpen(true)}
          className="-ml-2 inline-flex h-10 w-10 items-center justify-center rounded-full lg:hidden"
          aria-label="Open menu"
        >
          <svg
            viewBox="0 0 24 24"
            className="h-5 w-5"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.6"
            aria-hidden="true"
          >
            <path d="M4 7h16M4 12h16M4 17h16" strokeLinecap="round" />
          </svg>
        </button>

        <Link
          href="/"
          className="font-display text-xl tracking-tight text-ink lg:text-2xl"
        >
          DG PRIME MART
        </Link>

        {/* Desktop nav */}
        <nav
          className="hidden items-center gap-6 lg:flex"
          aria-label="Main navigation"
        >
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm text-ink/80 transition-colors hover:text-ink"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Icons */}
        <div className="flex items-center gap-1 sm:gap-2">
          <IconLink href="/search" label="Search">
            <path d="M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16zM21 21l-4.3-4.3" />
          </IconLink>
          <IconLink href="/account" label="Account" className="hidden lg:inline-flex">
            <path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 20c1.8-3.6 5-5.5 8-5.5s6.2 1.9 8 5.5" />
          </IconLink>
          <IconLink
            href="/wishlist"
            label={`Wishlist${wishlist.length ? `, ${wishlist.length} items` : ""}`}
            badge={wishlist.length}
            className="hidden lg:inline-flex"
          >
            <path d="M12 20.5s-7.5-4.9-10-9.5C0.3 7.5 2 4 5.5 4c2 0 3.5 1 4.5 2.5C11 5 12.5 4 14.5 4 18 4 19.7 7.5 18 11c-2.5 4.6-10 9.5-10 9.5z" />
          </IconLink>
          <IconLink
            href="/cart"
            label={`Cart${itemCount ? `, ${itemCount} items` : ""}`}
            badge={itemCount}
          >
            <path d="M6 8h12l-1 12H7L6 8zM9 8V6a3 3 0 0 1 6 0v2" />
          </IconLink>
        </div>
      </div>

      {mobileOpen && (
        <MobileNav onClose={() => setMobileOpen(false)} />
      )}
    </header>
  );
}

function IconLink({
  href,
  label,
  badge,
  className = "",
  children,
}: {
  href: string;
  label: string;
  badge?: number;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      aria-label={label}
      className={`relative inline-flex h-10 w-10 items-center justify-center rounded-full text-ink transition-colors hover:bg-parchment ${className}`}
    >
      <svg
        viewBox="0 0 24 24"
        className="h-5 w-5"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        {children}
      </svg>
      {!!badge && (
        <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose px-1 text-[10px] font-medium text-ivory">
          {badge}
        </span>
      )}
    </Link>
  );
}

function MobileNav({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 lg:hidden">
      <button
        aria-label="Close menu"
        onClick={onClose}
        className="absolute inset-0 bg-ink/40"
      />
      <div className="absolute inset-y-0 left-0 flex w-[85%] max-w-sm animate-[fade-up_0.25s_ease-out] flex-col bg-ivory p-6 shadow-card">
        <div className="mb-6 flex items-center justify-between">
          <span className="font-display text-lg text-ink">DG PRIME MART</span>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close menu"
            className="inline-flex h-9 w-9 items-center justify-center rounded-full hover:bg-parchment"
          >
            <svg
              viewBox="0 0 24 24"
              className="h-5 w-5"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              aria-hidden="true"
            >
              <path d="M6 6l12 12M18 6L6 18" strokeLinecap="round" />
            </svg>
          </button>
        </div>
        <nav className="flex flex-col gap-1" aria-label="Mobile navigation">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={onClose}
              className="rounded-lg px-2 py-3 text-base text-ink hover:bg-parchment"
            >
              {link.label}
            </Link>
          ))}
          <div className="my-3 h-px bg-line" />
          <Link
            href="/account"
            onClick={onClose}
            className="rounded-lg px-2 py-3 text-base text-ink hover:bg-parchment"
          >
            Account
          </Link>
          <Link
            href="/wishlist"
            onClick={onClose}
            className="rounded-lg px-2 py-3 text-base text-ink hover:bg-parchment"
          >
            Wishlist
          </Link>
        </nav>
      </div>
    </div>
  );
}
