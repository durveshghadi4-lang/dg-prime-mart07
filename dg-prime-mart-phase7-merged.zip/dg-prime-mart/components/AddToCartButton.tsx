"use client";

import { useState } from "react";
import type { Product } from "@/lib/types";
import { useCart } from "./CartProvider";

interface AddToCartButtonProps {
  product: Product;
  disabled?: boolean;
  className?: string;
}

export function AddToCartButton({
  product,
  disabled,
  className = "",
}: AddToCartButtonProps) {
  const { addToCart } = useCart();
  const [status, setStatus] = useState<"idle" | "adding" | "added">("idle");

  async function handleClick() {
    if (disabled || status === "adding") return;
    setStatus("adding");
    // Simulated latency placeholder for the future server round-trip
    // (stock check, price re-verification) once a real cart API exists.
    await new Promise((resolve) => setTimeout(resolve, 350));
    addToCart(product);
    setStatus("added");
    window.setTimeout(() => setStatus("idle"), 1600);
  }

  const isOutOfStock = disabled || !product.inStock;

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={isOutOfStock}
      aria-live="polite"
      className={`inline-flex items-center justify-center rounded-full px-5 py-2.5 text-sm font-medium transition-colors ${
        isOutOfStock
          ? "cursor-not-allowed bg-line text-stone"
          : status === "added"
          ? "bg-bottle text-ivory"
          : "bg-ink text-ivory hover:bg-bottle"
      } ${className}`}
    >
      {isOutOfStock
        ? "Out of stock"
        : status === "adding"
        ? "Adding…"
        : status === "added"
        ? "Added ✓"
        : "Add to Cart"}
    </button>
  );
}
