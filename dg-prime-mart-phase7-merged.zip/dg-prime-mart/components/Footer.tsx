import Link from "next/link";
import { categories } from "@/lib/categories";
import { Newsletter } from "./Newsletter";

const customerCare = [
  { href: "/contact", label: "Contact" },
  { href: "/faq", label: "FAQ" },
  { href: "/shipping-policy", label: "Shipping" },
  { href: "/return-policy", label: "Returns" },
  { href: "/account/orders", label: "Order Tracking" },
];

const legal = [
  { href: "/privacy-policy", label: "Privacy" },
  { href: "/terms", label: "Terms" },
];

export function Footer() {
  return (
    <footer className="border-t border-line bg-parchment">
      <div className="mx-auto max-w-container px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <p className="font-display text-xl text-ink">DG PRIME MART</p>
            <p className="mt-2 max-w-xs text-sm text-stone">
              Everyday Elegance, Effortless Living.
            </p>
          </div>

          <FooterColumn
            title="Shop"
            links={categories.map((c) => ({
              href: `/category/${c.slug}`,
              label: c.name,
            }))}
          />
          <FooterColumn title="Customer Care" links={customerCare} />

          <div>
            <p className="eyebrow mb-3">Stay in the loop</p>
            <Newsletter variant="footer" />
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-4 border-t border-line pt-6 text-xs text-stone sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} DG PRIME MART. All rights reserved.</p>
          <div className="flex gap-4">
            {legal.map((link) => (
              <Link key={link.href} href={link.href} className="hover:text-ink">
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({
  title,
  links,
}: {
  title: string;
  links: { href: string; label: string }[];
}) {
  return (
    <div>
      <p className="eyebrow mb-3">{title}</p>
      <ul className="flex flex-col gap-2">
        {links.map((link) => (
          <li key={link.href}>
            <Link href={link.href} className="text-sm text-ink/80 hover:text-ink">
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
