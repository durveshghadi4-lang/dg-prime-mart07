import type { Product } from "@/lib/types";
import { ProductCard } from "./ProductCard";

interface ProductGridProps {
  products: Product[];
  loading?: boolean;
  emptyTitle?: string;
  emptyMessage?: string;
}

export function ProductGrid({
  products,
  loading = false,
  emptyTitle = "No products here yet",
  emptyMessage = "We're curating this collection. Check back soon.",
}: ProductGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <ProductCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed border-line px-6 py-16 text-center">
        <p className="font-display text-xl text-ink">{emptyTitle}</p>
        <p className="max-w-sm text-sm text-stone">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}

function ProductCardSkeleton() {
  return (
    <div className="flex flex-col gap-3" aria-hidden="true">
      <div className="aspect-[4/5] w-full animate-pulse rounded-2xl bg-line" />
      <div className="h-4 w-3/4 animate-pulse rounded bg-line" />
      <div className="h-3 w-1/2 animate-pulse rounded bg-line" />
      <div className="h-6 w-1/3 animate-pulse rounded bg-line" />
    </div>
  );
}
