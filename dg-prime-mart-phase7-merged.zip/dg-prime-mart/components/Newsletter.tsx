"use client";

import { useState } from "react";

interface NewsletterProps {
  variant?: "footer" | "section";
}

type Status = "idle" | "submitting" | "success" | "error";

/**
 * UI + client-side validation only. There is no email provider connected
 * yet — wire this up to a real endpoint (e.g. `/api/newsletter`) once one is
 * chosen, and it should write to a `subscribers` table / ESP list rather
 * than silently succeeding as it does here.
 */
export function Newsletter({ variant = "section" }: NewsletterProps) {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<Status>("idle");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.includes("@")) {
      setStatus("error");
      return;
    }
    setStatus("submitting");
    await new Promise((resolve) => setTimeout(resolve, 500));
    // TODO(backend): POST to /api/newsletter once an email provider exists.
    setStatus("success");
    setEmail("");
  }

  const isFooter = variant === "footer";

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2">
      {status === "success" ? (
        <p className={`text-sm ${isFooter ? "text-ink" : "text-ivory"}`}>
          You're on the list — thank you.
        </p>
      ) : (
        <>
          <div className="flex gap-2">
            <label htmlFor={`newsletter-${variant}`} className="sr-only">
              Email address
            </label>
            <input
              id={`newsletter-${variant}`}
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email"
              className={`w-full rounded-full border px-4 py-2.5 text-sm outline-none transition-colors ${
                isFooter
                  ? "border-line bg-ivory text-ink placeholder:text-stone focus:border-brass"
                  : "border-ivory/30 bg-ivory/10 text-ivory placeholder:text-ivory/60 focus:border-ivory"
              }`}
            />
            <button
              type="submit"
              disabled={status === "submitting"}
              className={`shrink-0 rounded-full px-4 py-2.5 text-sm font-medium transition-colors ${
                isFooter
                  ? "bg-ink text-ivory hover:bg-bottle"
                  : "bg-ivory text-ink hover:bg-parchment"
              }`}
            >
              {status === "submitting" ? "Joining…" : "Join"}
            </button>
          </div>
          {status === "error" && (
            <p className="text-xs text-rose-dark">
              Enter a valid email to subscribe.
            </p>
          )}
        </>
      )}
    </form>
  );
}
