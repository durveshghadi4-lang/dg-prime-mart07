import Link from "next/link";
import type { Product } from "@/lib/types";
import { ProductImage } from "./ProductImage";
import { ProductBadge, DemoDataBadge } from "./ProductBadge";
import { PriceDisplay } from "./PriceDisplay";
import { WishlistButton } from "./WishlistButton";
import { AddToCartButton } from "./AddToCartButton";

export function ProductCard({ product }: { product: Product }) {
  return (
    <article className="group flex flex-col">
      <div className="relative">
        <Link
          href={`/product/${product.slug}`}
          className="block overflow-hidden rounded-2xl"
        >
          <ProductImage
            src={product.images[0]}
            alt={product.name}
            categorySlug={product.categorySlug}
            seed={product.slug}
            className="aspect-[4/5] w-full transition-transform duration-500 group-hover:scale-[1.03]"
          />
        </Link>

        <div className="absolute left-3 top-3 flex flex-wrap gap-1.5">
          {product.isDemoData && <DemoDataBadge />}
          {!product.inStock && <ProductBadge kind="out-of-stock" />}
          {product.inStock &&
            product.badges.map((badge) => (
              <ProductBadge key={badge} kind={badge} />
            ))}
        </div>

        <WishlistButton
          productId={product.id}
          productName={product.name}
          className="absolute right-3 top-3"
        />
      </div>

      <div className="mt-3 flex flex-1 flex-col gap-1">
        <Link href={`/product/${product.slug}`} className="hover:underline">
          <h3 className="font-display text-lg leading-snug text-ink">
            {product.name}
          </h3>
        </Link>
        <p className="text-sm text-stone">{product.shortDescription}</p>
      </div>

      <div className="mt-3 flex items-center justify-between gap-3">
        <PriceDisplay
          price={product.price}
          compareAtPrice={product.compareAtPrice}
          currency={product.currency}
        />
        <AddToCartButton product={product} />
      </div>
    </article>
  );
}
