"use client";

import { useCart } from "./CartProvider";

interface WishlistButtonProps {
  productId: string;
  productName: string;
  className?: string;
}

export function WishlistButton({
  productId,
  productName,
  className = "",
}: WishlistButtonProps) {
  const { isWishlisted, toggleWishlist } = useCart();
  const active = isWishlisted(productId);

  return (
    <button
      type="button"
      onClick={() => toggleWishlist(productId)}
      aria-pressed={active}
      aria-label={
        active ? `Remove ${productName} from wishlist` : `Add ${productName} to wishlist`
      }
      className={`inline-flex h-9 w-9 items-center justify-center rounded-full border transition-colors ${
        active
          ? "border-rose bg-rose/10 text-rose-dark"
          : "border-line bg-ivory/90 text-ink hover:border-rose hover:text-rose-dark"
      } ${className}`}
    >
      <svg
        viewBox="0 0 24 24"
        className="h-4 w-4"
        fill={active ? "currentColor" : "none"}
        stroke="currentColor"
        strokeWidth="1.6"
        aria-hidden="true"
      >
        <path d="M12 20.5s-7.5-4.9-10-9.5C0.3 7.5 2 4 5.5 4c2 0 3.5 1 4.5 2.5C11 5 12.5 4 14.5 4 18 4 19.7 7.5 18 11c-2.5 4.6-10 9.5-10 9.5z" />
      </svg>
    </button>
  );
}
