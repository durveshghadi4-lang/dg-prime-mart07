import Image from "next/image";
import { PlaceholderArt } from "./PlaceholderArt";

interface ProductImageProps {
  src?: string;
  alt: string;
  categorySlug?: string;
  seed?: string;
  className?: string;
}

/**
 * Renders a real product photo when `src` is provided (once the catalog is
 * populated); otherwise falls back to on-brand placeholder art. Consumers
 * never need to branch on "is this a demo product" themselves.
 */
export function ProductImage({
  src,
  alt,
  categorySlug,
  seed,
  className = "aspect-[4/5] w-full",
}: ProductImageProps) {
  if (!src) {
    return (
      <PlaceholderArt
        seed={seed ?? alt}
        categorySlug={categorySlug}
        className={className}
      />
    );
  }

  return (
    <div className={`relative overflow-hidden ${className}`}>
      <Image
        src={src}
        alt={alt}
        fill
        sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
        className="object-cover"
      />
    </div>
  );
}
