import { formatPrice } from "@/lib/config";
import { shippingConfig } from "@/lib/config";

export function AnnouncementBar() {
  return (
    <div className="bg-bottle py-2 text-center text-xs tracking-wide text-ivory/90">
      Free shipping on orders above{" "}
      {formatPrice(
        shippingConfig.freeShippingThreshold,
        shippingConfig.freeShippingCurrency
      )}
    </div>
  );
}
