"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export interface AddressRecord {
  id: string;
  firstName: string;
  lastName: string;
  addressLine1: string;
  addressLine2: string | null;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone: string | null;
  isDefault: boolean;
}

const emptyForm = {
  firstName: "",
  lastName: "",
  addressLine1: "",
  addressLine2: "",
  city: "",
  state: "",
  postalCode: "",
  country: "",
  phone: "",
};

export function AddressManager({
  initialAddresses,
}: {
  initialAddresses: AddressRecord[];
}) {
  const router = useRouter();
  const [addresses, setAddresses] = useState(initialAddresses);
  const [form, setForm] = useState(emptyForm);
  const [showForm, setShowForm] = useState(initialAddresses.length === 0);
  const [status, setStatus] = useState<"idle" | "submitting" | "error">("idle");

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setStatus("submitting");

    const response = await fetch("/api/account/addresses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, isDefault: addresses.length === 0 }),
    });

    if (!response.ok) {
      setStatus("error");
      return;
    }

    const data = await response.json();
    setAddresses((prev) => [data.address, ...prev]);
    setForm(emptyForm);
    setShowForm(false);
    setStatus("idle");
    router.refresh();
  }

  async function handleDelete(id: string) {
    setAddresses((prev) => prev.filter((a) => a.id !== id));
    await fetch(`/api/account/addresses/${id}`, { method: "DELETE" });
    router.refresh();
  }

  return (
    <div className="flex flex-col gap-6">
      {addresses.length === 0 && !showForm && (
        <p className="text-sm text-stone">No addresses saved yet.</p>
      )}

      <div className="flex flex-col gap-4">
        {addresses.map((address) => (
          <div
            key={address.id}
            className="flex items-start justify-between gap-4 rounded-2xl border border-line p-5"
          >
            <div className="text-sm text-ink">
              <p className="font-medium">
                {address.firstName} {address.lastName}
                {address.isDefault && (
                  <span className="ml-2 text-xs text-brass">Default</span>
                )}
              </p>
              <p className="mt-1 text-stone">
                {address.addressLine1}
                {address.addressLine2 ? `, ${address.addressLine2}` : ""}
                <br />
                {address.city}, {address.state} {address.postalCode}
                <br />
                {address.country}
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleDelete(address.id)}
              className="text-xs text-stone hover:text-rose-dark"
            >
              Remove
            </button>
          </div>
        ))}
      </div>

      {showForm ? (
        <form onSubmit={handleAdd} className="flex flex-col gap-3 rounded-2xl border border-line p-5">
          <div className="grid grid-cols-2 gap-3">
            <TextField label="First name" value={form.firstName} onChange={(v) => setForm({ ...form, firstName: v })} required />
            <TextField label="Last name" value={form.lastName} onChange={(v) => setForm({ ...form, lastName: v })} required />
          </div>
          <TextField label="Address line 1" value={form.addressLine1} onChange={(v) => setForm({ ...form, addressLine1: v })} required />
          <TextField label="Address line 2 (optional)" value={form.addressLine2} onChange={(v) => setForm({ ...form, addressLine2: v })} />
          <div className="grid grid-cols-2 gap-3">
            <TextField label="City" value={form.city} onChange={(v) => setForm({ ...form, city: v })} required />
            <TextField label="State" value={form.state} onChange={(v) => setForm({ ...form, state: v })} required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <TextField label="Postal code" value={form.postalCode} onChange={(v) => setForm({ ...form, postalCode: v })} required />
            <TextField label="Country" value={form.country} onChange={(v) => setForm({ ...form, country: v })} required />
          </div>
          <TextField label="Phone (optional)" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} />

          {status === "error" && (
            <p role="alert" className="text-sm text-rose-dark">
              Couldn't save that address. Check the fields and try again.
            </p>
          )}

          <div className="mt-1 flex gap-3">
            <button
              type="submit"
              disabled={status === "submitting"}
              className="inline-flex items-center justify-center rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-ivory hover:bg-bottle disabled:opacity-70"
            >
              {status === "submitting" ? "Saving…" : "Save Address"}
            </button>
            {addresses.length > 0 && (
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="text-sm text-stone hover:text-ink"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      ) : (
        <button
          type="button"
          onClick={() => setShowForm(true)}
          className="w-fit rounded-full border border-line px-5 py-2.5 text-sm font-medium text-ink hover:border-ink"
        >
          Add Address
        </button>
      )}
    </div>
  );
}

function TextField({
  label,
  value,
  onChange,
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <label className="flex flex-col gap-1.5 text-sm text-ink">
      {label}
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        className="rounded-full border border-line px-4 py-2.5 text-sm text-ink outline-none focus:border-brass"
      />
    </label>
  );
}
