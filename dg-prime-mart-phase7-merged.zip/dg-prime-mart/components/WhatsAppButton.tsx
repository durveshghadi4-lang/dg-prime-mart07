"use client";

import { useRef, useState } from "react";
import { whatsappConfig } from "@/lib/config";

const POSITION_KEY = "dgpm:whatsapp-position";

/**
 * Floating WhatsApp launcher. Position is draggable and persisted locally so
 * it can be moved out of the way of checkout/important UI on any given
 * device. Renders nothing if no number is configured, rather than shipping
 * a dead button.
 */
export function WhatsAppButton() {
  const [position, setPosition] = useState<{ x: number; y: number } | null>(
    () => {
      if (typeof window === "undefined") return null;
      try {
        const stored = window.localStorage.getItem(POSITION_KEY);
        return stored ? JSON.parse(stored) : null;
      } catch {
        return null;
      }
    }
  );
  const dragInfo = useRef<{
    dragging: boolean;
    moved: boolean;
    startX: number;
    startY: number;
  }>({ dragging: false, moved: false, startX: 0, startY: 0 });

  if (!whatsappConfig.number) {
    // No number configured — don't render a non-functional button.
    return null;
  }

  const href = `https://wa.me/${whatsappConfig.number}?text=${encodeURIComponent(
    whatsappConfig.welcomeMessage
  )}`;

  function handlePointerDown(e: React.PointerEvent<HTMLDivElement>) {
    dragInfo.current = {
      dragging: true,
      moved: false,
      startX: e.clientX,
      startY: e.clientY,
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  }

  function handlePointerMove(e: React.PointerEvent<HTMLDivElement>) {
    if (!dragInfo.current.dragging) return;
    const dx = e.clientX - dragInfo.current.startX;
    const dy = e.clientY - dragInfo.current.startY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) {
      dragInfo.current.moved = true;
    }
    if (!dragInfo.current.moved) return;

    const margin = 16;
    const maxX = window.innerWidth - 56 - margin;
    const maxY = window.innerHeight - 56 - margin;
    const nextX = Math.min(Math.max(e.clientX - 28, margin), maxX);
    const nextY = Math.min(Math.max(e.clientY - 28, margin), maxY);
    setPosition({ x: nextX, y: nextY });
  }

  function handlePointerUp() {
    if (dragInfo.current.moved && position) {
      window.localStorage.setItem(POSITION_KEY, JSON.stringify(position));
    }
    dragInfo.current.dragging = false;
  }

  const style: React.CSSProperties = position
    ? { position: "fixed", left: position.x, top: position.y, right: "auto", bottom: "auto" }
    : { position: "fixed", right: 16, bottom: 96 };

  return (
    <div
      style={{ ...style, zIndex: 50, touchAction: "none" }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      <a
        href={dragInfo.current.moved ? undefined : href}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with us on WhatsApp"
        onClick={(e) => {
          if (dragInfo.current.moved) e.preventDefault();
        }}
        className="flex h-14 w-14 cursor-grab items-center justify-center rounded-full bg-[#25D366] text-white shadow-card transition-transform hover:scale-105 active:cursor-grabbing"
      >
        <svg viewBox="0 0 24 24" className="h-7 w-7" fill="currentColor" aria-hidden="true">
          <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.39 1.26 4.81L2 22l5.42-1.42a9.87 9.87 0 0 0 4.62 1.18h.01c5.46 0 9.9-4.45 9.9-9.91C21.95 6.45 17.5 2 12.04 2zm5.8 14.03c-.24.68-1.4 1.3-1.93 1.35-.5.05-1 .24-3.32-.7-2.81-1.14-4.6-3.99-4.74-4.18-.14-.19-1.13-1.51-1.13-2.88 0-1.37.72-2.03.97-2.3.25-.28.55-.35.73-.35h.53c.17 0 .4-.06.62.48.24.58.82 2 .89 2.14.07.14.11.31.02.5-.09.19-.14.31-.28.48-.14.17-.29.37-.42.5-.14.14-.28.29-.12.57.16.28.72 1.19 1.55 1.93 1.07.95 1.97 1.25 2.25 1.39.28.14.44.12.6-.07.17-.19.71-.83.9-1.11.19-.28.38-.24.63-.14.26.09 1.65.78 1.93.92.28.14.47.21.53.33.07.12.07.68-.17 1.36z" />
        </svg>
      </a>
    </div>
  );
}
