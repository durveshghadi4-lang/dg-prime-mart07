import type { ProductBadgeKind } from "@/lib/types";

const BADGE_STYLES: Record<
  ProductBadgeKind,
  { label: string; className: string }
> = {
  new: { label: "New", className: "bg-bottle text-ivory" },
  sale: { label: "Sale", className: "bg-rose text-ivory" },
  featured: { label: "Featured", className: "bg-brass text-ivory" },
  "out-of-stock": { label: "Out of stock", className: "bg-stone text-ivory" },
};

export function ProductBadge({ kind }: { kind: ProductBadgeKind }) {
  const style = BADGE_STYLES[kind];
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-medium ${style.className}`}
    >
      {style.label}
    </span>
  );
}

/** Distinct visual flag for development-only demo products. */
export function DemoDataBadge() {
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-dashed border-stone/60 px-2.5 py-1 text-[11px] font-medium text-stone">
      Demo
    </span>
  );
}
