"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function ProfileForm({ initialName }: { initialName: string }) {
  const router = useRouter();
  const [name, setName] = useState(initialName);
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">(
    "idle"
  );

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("submitting");

    const response = await fetch("/api/account/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });

    if (!response.ok) {
      setStatus("error");
      return;
    }

    setStatus("success");
    router.refresh();
    window.setTimeout(() => setStatus("idle"), 1800);
  }

  return (
    <form onSubmit={handleSubmit} className="flex max-w-sm flex-col gap-4">
      <div className="flex flex-col gap-1.5">
        <label htmlFor="name" className="text-sm text-ink">
          Full name
        </label>
        <input
          id="name"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="rounded-full border border-line px-4 py-2.5 text-sm text-ink outline-none focus:border-brass"
        />
      </div>
      {status === "error" && (
        <p role="alert" className="text-sm text-rose-dark">
          Couldn't save changes. Please try again.
        </p>
      )}
      <button
        type="submit"
        disabled={status === "submitting"}
        className="inline-flex w-fit items-center justify-center rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-ivory transition-colors hover:bg-bottle disabled:opacity-70"
      >
        {status === "submitting"
          ? "Saving…"
          : status === "success"
          ? "Saved ✓"
          : "Save Changes"}
      </button>
    </form>
  );
}
