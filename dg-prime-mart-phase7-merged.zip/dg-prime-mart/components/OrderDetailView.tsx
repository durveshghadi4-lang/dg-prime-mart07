import Link from "next/link";
import { formatPrice } from "@/lib/config";

export interface OrderDetailData {
  orderNumber: string;
  status: string;
  email: string;
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  currency: string;
  createdAt: Date;
  shippingAddressSnapshot: unknown;
  items: {
    id: string;
    nameSnapshot: string;
    quantity: number;
    priceSnapshot: number;
  }[];
  /**
   * Real fulfillment progress, when it exists. `Order.status` itself never
   * advances past "PAID" in this codebase (see Phase 4/lib/checkout-server.ts)
   * — Fulfillment.status is where shipped/delivered progress actually
   * lives. Without this, a customer's order page would show "Paid"
   * forever even after the order shipped and was delivered, which is
   * exactly the gap this field closes.
   */
  fulfillment?: {
    status: string;
    trackingNumber: string | null;
    carrier: string | null;
  } | null;
}

const STATUS_LABELS: Record<string, string> = {
  PENDING_PAYMENT: "Payment pending",
  PAID: "Paid",
  PROCESSING: "Processing",
  AWAITING_SUPPLIER_APPROVAL: "Being reviewed",
  SUPPLIER_APPROVED: "Approved for fulfillment",
  SUBMITTED_TO_SUPPLIER: "Submitted for fulfillment",
  SUPPLIER_PROCESSING: "Being prepared",
  SHIPPED: "Shipped",
  IN_TRANSIT: "In transit",
  DELIVERED: "Delivered",
  CANCELLED: "Cancelled",
  REFUNDED: "Refunded",
};

/**
 * Fulfillment's own status vocabulary overlaps but doesn't exactly match
 * Order.status's — map the customer-relevant subset to the same display
 * labels above, so the UI reads consistently regardless of which one
 * actually produced it.
 */
const FULFILLMENT_STATUS_LABELS: Record<string, string> = {
  PENDING_APPROVAL: "Being reviewed",
  APPROVED: "Preparing for shipment",
  SUBMITTING: "Preparing for shipment",
  SUBMITTED: "Preparing for shipment",
  PROCESSING: "Being prepared",
  SHIPPED: "Shipped",
  DELIVERED: "Delivered",
  CANCELLED: "Cancelled",
};

function resolveDisplayStatus(order: OrderDetailData): string {
  // Only let fulfillment override the order status once the order is
  // actually paid — a fulfillment row's own transient states should never
  // make an unpaid order look further along than it is (it can't exist
  // for an unpaid order anyway, but this keeps the function correct even
  // if that invariant ever changes).
  if (order.status === "PAID" && order.fulfillment) {
    return FULFILLMENT_STATUS_LABELS[order.fulfillment.status] ?? STATUS_LABELS.PAID;
  }
  return STATUS_LABELS[order.status] ?? order.status;
}

export function OrderDetailView({
  order,
  showConfirmationChrome = false,
}: {
  order: OrderDetailData;
  showConfirmationChrome?: boolean;
}) {
  const address = order.shippingAddressSnapshot as {
    firstName?: string;
    lastName?: string;
    addressLine1?: string;
    addressLine2?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
  } | null;

  const displayStatus = resolveDisplayStatus(order);

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
      {showConfirmationChrome && (
        <div className="mb-8 text-center">
          <p className="eyebrow mb-2">DG PRIME MART</p>
          <h1 className="font-display text-3xl text-ink">Thank you for your order</h1>
          <p className="mt-2 text-sm text-stone">
            A confirmation has been recorded for {order.email}.
          </p>
        </div>
      )}

      <div className="rounded-3xl border border-line p-6">
        <div className="flex items-center justify-between">
          <p className="font-display text-lg text-ink">{order.orderNumber}</p>
          <span className="rounded-full bg-parchment px-3 py-1 text-xs font-medium text-ink">
            {displayStatus}
          </span>
        </div>

        {order.fulfillment?.trackingNumber && (
          <p className="mt-2 text-sm text-stone">
            Tracking: <span className="font-medium text-ink">{order.fulfillment.trackingNumber}</span>
            {order.fulfillment.carrier ? ` (${order.fulfillment.carrier})` : ""}
          </p>
        )}

        <ul className="mt-5 flex flex-col divide-y divide-line">
          {order.items.map((item) => (
            <li key={item.id} className="flex justify-between py-3 text-sm">
              <span className="text-ink">
                {item.nameSnapshot} × {item.quantity}
              </span>
              <span className="text-stone">
                {formatPrice(item.priceSnapshot * item.quantity, order.currency)}
              </span>
            </li>
          ))}
        </ul>

        <div className="mt-4 flex flex-col gap-1 border-t border-line pt-4 text-sm">
          <div className="flex justify-between text-stone">
            <span>Subtotal</span>
            <span>{formatPrice(order.subtotal, order.currency)}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between text-stone">
              <span>Discount</span>
              <span>-{formatPrice(order.discount, order.currency)}</span>
            </div>
          )}
          <div className="flex justify-between text-stone">
            <span>Shipping</span>
            <span>
              {order.shipping === 0 ? "Free" : formatPrice(order.shipping, order.currency)}
            </span>
          </div>
          <div className="mt-1 flex justify-between font-display text-base text-ink">
            <span>Total</span>
            <span>{formatPrice(order.total, order.currency)}</span>
          </div>
        </div>

        {address && (
          <div className="mt-6 border-t border-line pt-4 text-sm text-stone">
            <p className="mb-1 text-ink">Shipping to</p>
            <p>
              {address.firstName} {address.lastName}
              <br />
              {address.addressLine1}
              {address.addressLine2 ? `, ${address.addressLine2}` : ""}
              <br />
              {address.city}, {address.state} {address.postalCode}
              <br />
              {address.country}
            </p>
          </div>
        )}
      </div>

      {showConfirmationChrome && (
        <div className="mt-8 text-center text-sm text-stone">
          <p>
            Your order has been received and is being reviewed by our team
            before it's sent for fulfillment — you'll be notified as it
            progresses.
          </p>
          <Link href="/shop" className="mt-4 inline-block underline">
            Continue shopping
          </Link>
        </div>
      )}
    </div>
  );
}
