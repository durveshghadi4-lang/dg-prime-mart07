"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export interface CouponRow {
  id: string;
  code: string;
  discountType: "PERCENTAGE" | "FIXED_AMOUNT";
  discountValue: string;
  minimumOrderAmount: string | null;
  usageLimit: number | null;
  perCustomerLimit: number | null;
  firstOrderOnly: boolean;
  active: boolean;
  redemptionCount: number;
}

export function CouponManager({ initialCoupons }: { initialCoupons: CouponRow[] }) {
  const router = useRouter();
  const [showNew, setShowNew] = useState(false);
  const [newCode, setNewCode] = useState("");
  const [newType, setNewType] = useState<"PERCENTAGE" | "FIXED_AMOUNT">("PERCENTAGE");
  const [newValue, setNewValue] = useState("");
  const [error, setError] = useState("");
  const [status, setStatus] = useState<"idle" | "submitting">("idle");

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setStatus("submitting");
    setError("");
    const response = await fetch("/api/admin/coupons", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: newCode,
        discountType: newType,
        discountValue: Number(newValue),
        firstOrderOnly: false,
        active: true,
      }),
    });
    const data = await response.json();
    setStatus("idle");
    if (!response.ok) {
      setError(data.error ?? "Could not create coupon.");
      return;
    }
    setShowNew(false);
    setNewCode("");
    setNewValue("");
    router.refresh();
  }

  async function toggleActive(coupon: CouponRow) {
    await fetch(`/api/admin/coupons/${coupon.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !coupon.active }),
    });
    router.refresh();
  }

  return (
    <div>
      {!showNew ? (
        <button
          type="button"
          onClick={() => setShowNew(true)}
          className="rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-ivory hover:bg-bottle"
        >
          New Coupon
        </button>
      ) : (
        <form onSubmit={handleCreate} className="mb-6 flex flex-wrap items-end gap-3 rounded-2xl border border-line bg-ivory p-5">
          <label className="flex flex-col gap-1.5 text-sm text-ink">
            Code
            <input
              type="text"
              value={newCode}
              onChange={(e) => setNewCode(e.target.value)}
              required
              className="rounded-full border border-line px-4 py-2 text-sm text-ink"
            />
          </label>
          <label className="flex flex-col gap-1.5 text-sm text-ink">
            Type
            <select
              value={newType}
              onChange={(e) => setNewType(e.target.value as "PERCENTAGE" | "FIXED_AMOUNT")}
              className="rounded-full border border-line px-4 py-2 text-sm text-ink"
            >
              <option value="PERCENTAGE">Percentage</option>
              <option value="FIXED_AMOUNT">Fixed amount</option>
            </select>
          </label>
          <label className="flex flex-col gap-1.5 text-sm text-ink">
            Value
            <input
              type="number"
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              required
              className="rounded-full border border-line px-4 py-2 text-sm text-ink"
            />
          </label>
          <button
            type="submit"
            disabled={status === "submitting"}
            className="rounded-full bg-ink px-5 py-2 text-sm font-medium text-ivory hover:bg-bottle"
          >
            {status === "submitting" ? "Saving…" : "Create"}
          </button>
          <button type="button" onClick={() => setShowNew(false)} className="text-sm text-stone hover:text-ink">
            Cancel
          </button>
          {error && <p className="w-full text-sm text-rose-dark">{error}</p>}
        </form>
      )}

      {initialCoupons.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-line px-6 py-16 text-center text-sm text-stone">
          No coupons yet.
        </div>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-ivory">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-xs text-stone">
              <tr>
                <th className="px-4 py-3">Code</th>
                <th className="px-4 py-3">Discount</th>
                <th className="px-4 py-3">Min. order</th>
                <th className="px-4 py-3">Limits</th>
                <th className="px-4 py-3">Redeemed</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {initialCoupons.map((coupon) => (
                <tr key={coupon.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-3 text-ink">
                    {coupon.code}
                    {coupon.firstOrderOnly && (
                      <span className="ml-2 text-xs text-brass">First order only</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-stone">
                    {coupon.discountType === "PERCENTAGE"
                      ? `${coupon.discountValue}%`
                      : coupon.discountValue}
                  </td>
                  <td className="px-4 py-3 text-stone">{coupon.minimumOrderAmount ?? "—"}</td>
                  <td className="px-4 py-3 text-stone">
                    {coupon.usageLimit ?? "∞"} total / {coupon.perCustomerLimit ?? "∞"} per customer
                  </td>
                  <td className="px-4 py-3 text-stone">{coupon.redemptionCount}</td>
                  <td className="px-4 py-3 text-stone">{coupon.active ? "Active" : "Inactive"}</td>
                  <td className="px-4 py-3">
                    <button
                      type="button"
                      onClick={() => toggleActive(coupon)}
                      className="text-xs text-ink underline"
                    >
                      {coupon.active ? "Deactivate" : "Activate"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
