"use client";

import { useState } from "react";

export function SettingsForm({
  fields,
  initialValues,
}: {
  fields: { key: string; label: string; type?: string }[];
  initialValues: Record<string, string>;
}) {
  const [values, setValues] = useState(initialValues);
  const [savedKey, setSavedKey] = useState<string | null>(null);
  const [savingKey, setSavingKey] = useState<string | null>(null);

  async function handleSave(key: string) {
    setSavingKey(key);
    const response = await fetch("/api/admin/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, value: values[key] }),
    });
    setSavingKey(null);
    if (response.ok) {
      setSavedKey(key);
      window.setTimeout(() => setSavedKey((k) => (k === key ? null : k)), 1500);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      {fields.map((field) => (
        <div key={field.key} className="flex items-end gap-3">
          <label className="flex flex-1 flex-col gap-1.5 text-sm text-ink">
            {field.label}
            <input
              type={field.type ?? "text"}
              value={values[field.key] ?? ""}
              onChange={(e) => setValues({ ...values, [field.key]: e.target.value })}
              className="rounded-full border border-line px-4 py-2.5 text-sm text-ink outline-none focus:border-brass"
            />
          </label>
          <button
            type="button"
            onClick={() => handleSave(field.key)}
            disabled={savingKey === field.key}
            className="rounded-full border border-line px-4 py-2.5 text-sm text-ink hover:border-ink disabled:opacity-70"
          >
            {savingKey === field.key ? "Saving…" : savedKey === field.key ? "Saved ✓" : "Save"}
          </button>
        </div>
      ))}
    </div>
  );
}
