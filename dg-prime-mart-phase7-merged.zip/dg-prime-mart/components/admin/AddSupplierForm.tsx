"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function AddSupplierForm() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [provider, setProvider] = useState("");
  const [credentialsRef, setCredentialsRef] = useState("");
  const [active, setActive] = useState(false);
  const [status, setStatus] = useState<"idle" | "submitting" | "error">("idle");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("submitting");
    setError("");

    const response = await fetch("/api/admin/suppliers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, provider, credentialsRef, active }),
    });
    const data = await response.json();

    if (!response.ok) {
      setError(data.error ?? "Could not create supplier.");
      setStatus("error");
      return;
    }

    setName("");
    setProvider("");
    setCredentialsRef("");
    setActive(false);
    setStatus("idle");
    setOpen(false);
    router.refresh();
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-ivory hover:bg-bottle"
      >
        Add Supplier
      </button>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="mt-4 flex flex-col gap-3 rounded-2xl border border-line bg-ivory p-5"
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <input
          type="text"
          placeholder="Name (e.g. CJ Dropshipping)"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="rounded-full border border-line px-4 py-2 text-sm text-ink"
        />
        <input
          type="text"
          placeholder="Provider key (e.g. cj_dropshipping)"
          value={provider}
          onChange={(e) => setProvider(e.target.value)}
          required
          className="rounded-full border border-line px-4 py-2 text-sm text-ink"
        />
      </div>
      <input
        type="text"
        placeholder="Credentials reference (e.g. secrets-manager key name — never a real API key)"
        value={credentialsRef}
        onChange={(e) => setCredentialsRef(e.target.value)}
        className="rounded-full border border-line px-4 py-2 text-sm text-ink"
      />
      <label className="flex items-center gap-2 text-sm text-ink">
        <input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} />
        Active
      </label>
      {error && <p className="text-sm text-rose-dark">{error}</p>}
      <div className="flex gap-3">
        <button
          type="submit"
          disabled={status === "submitting"}
          className="rounded-full bg-ink px-5 py-2 text-sm font-medium text-ivory hover:bg-bottle disabled:opacity-70"
        >
          {status === "submitting" ? "Saving…" : "Save Supplier"}
        </button>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="text-sm text-stone hover:text-ink"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}
