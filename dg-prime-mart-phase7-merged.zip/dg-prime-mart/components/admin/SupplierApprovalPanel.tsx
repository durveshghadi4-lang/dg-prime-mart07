"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { formatPrice } from "@/lib/config";

interface ApprovalItem {
  id: string;
  name: string;
  quantity: number;
  supplierId: string | null;
  supplierName: string | null;
  supplierProductId: string | null;
  supplierCost: number | null;
  supplierShippingCost: number | null;
  customerRevenue: number;
  estimatedGrossMargin: number | null;
}

interface ExistingFulfillment {
  id: string;
  status: string;
  approvedAt: string | null;
  approvedByEmailSnapshot: string | null;
  supplierName: string | null;
  supplierOrderId: string | null;
  submittedAt: string | null;
  submittedByEmailSnapshot: string | null;
  lastSubmissionError: string | null;
  trackingNumber: string | null;
  carrier: string | null;
  lastSyncedAt: string | null;
}

export function SupplierApprovalPanel({
  orderId,
  orderNumber,
  customerEmail,
  currency,
  total,
  items,
  existingFulfillment,
  cjConfigured,
}: {
  orderId: string;
  orderNumber: string;
  customerEmail: string;
  currency: string;
  total: number;
  items: ApprovalItem[];
  existingFulfillment: ExistingFulfillment | null;
  cjConfigured: boolean;
}) {
  const router = useRouter();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [status, setStatus] = useState<"idle" | "submitting" | "error">("idle");
  const [error, setError] = useState("");

  if (existingFulfillment && existingFulfillment.status === "APPROVED") {
    return (
      <SubmitToSupplierPanel
        orderId={orderId}
        orderNumber={orderNumber}
        fulfillment={existingFulfillment}
        cjConfigured={cjConfigured}
      />
    );
  }

  if (
    existingFulfillment &&
    !["PENDING_APPROVAL", "APPROVED"].includes(existingFulfillment.status)
  ) {
    return (
      <SubmittedStatusPanel
        orderId={orderId}
        fulfillment={existingFulfillment}
        cjConfigured={cjConfigured}
      />
    );
  }

  const missingSupplierData = items.some((i) => i.supplierCost == null);

  async function handleConfirm() {
    setStatus("submitting");
    setError("");
    const response = await fetch(`/api/admin/orders/${orderId}/approve-fulfillment`, {
      method: "POST",
    });
    const data = await response.json();
    if (!response.ok) {
      setError(data.error ?? "Could not approve this order.");
      setStatus("error");
      return;
    }
    setConfirmOpen(false);
    router.refresh();
  }

  return (
    <section className="mt-6 rounded-2xl border border-brass/50 bg-ivory p-5">
      <h2 className="font-display text-base text-ink">Supplier Fulfillment Approval</h2>
      <p className="mt-1 text-xs text-stone">
        This order is paid and awaiting your review before any supplier
        involvement. No supplier API is called by this action — it only
        records internal approval.
      </p>

      <div className="mt-4 flex flex-col gap-3">
        {items.map((item) => (
          <div key={item.id} className="rounded-xl border border-line p-3 text-sm">
            <div className="flex justify-between">
              <span className="text-ink">
                {item.name} × {item.quantity}
              </span>
              <span className="text-stone">
                {formatPrice(item.customerRevenue, currency)}
              </span>
            </div>
            <div className="mt-1 grid grid-cols-2 gap-x-4 gap-y-0.5 text-xs text-stone">
              <span>Supplier: {item.supplierName ?? "Not mapped"}</span>
              <span>Supplier product ID: {item.supplierProductId ?? "—"}</span>
              <span>
                Supplier cost:{" "}
                {item.supplierCost != null
                  ? formatPrice(item.supplierCost, currency)
                  : "Not set"}
              </span>
              <span>
                Est. gross margin:{" "}
                {item.estimatedGrossMargin != null
                  ? formatPrice(item.estimatedGrossMargin, currency)
                  : "Not estimable"}
              </span>
            </div>
          </div>
        ))}
      </div>

      {missingSupplierData && (
        <p className="mt-3 text-xs text-brass-dark">
          Some items are missing supplier cost/mapping data — margin can't
          be fully estimated. You can still approve; add supplier mapping
          under Products for a complete picture next time.
        </p>
      )}

      {error && (
        <p role="alert" className="mt-3 text-sm text-rose-dark">
          {error}
        </p>
      )}

      <button
        type="button"
        onClick={() => setConfirmOpen(true)}
        className="mt-4 inline-flex items-center justify-center rounded-full bg-bottle px-6 py-3 text-sm font-medium text-ivory hover:bg-bottle-dark"
      >
        Approve &amp; Send to Supplier
      </button>

      {confirmOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-ink/40 p-4">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="approval-confirm-heading"
            className="w-full max-w-md rounded-3xl bg-ivory p-6 shadow-card"
          >
            <h3 id="approval-confirm-heading" className="font-display text-lg text-ink">
              Confirm supplier approval
            </h3>
            <p className="mt-2 text-sm text-stone">
              This action will authorize this order for supplier fulfillment.
            </p>

            <dl className="mt-4 flex flex-col gap-1 text-sm">
              <Row label="Order number" value={orderNumber} />
              <Row label="Customer" value={customerEmail} />
              <Row
                label="Items"
                value={items.map((i) => `${i.name} ×${i.quantity}`).join(", ")}
              />
              <Row label="Estimated total" value={formatPrice(total, currency)} />
            </dl>

            {error && (
              <p role="alert" className="mt-3 text-sm text-rose-dark">
                {error}
              </p>
            )}

            <div className="mt-6 flex gap-3">
              <button
                type="button"
                onClick={handleConfirm}
                disabled={status === "submitting"}
                className="inline-flex flex-1 items-center justify-center rounded-full bg-bottle px-4 py-2.5 text-sm font-medium text-ivory hover:bg-bottle-dark disabled:opacity-70"
              >
                {status === "submitting"
                  ? "Approving…"
                  : "Yes, Approve & Send to Supplier"}
              </button>
              <button
                type="button"
                onClick={() => setConfirmOpen(false)}
                disabled={status === "submitting"}
                className="inline-flex items-center justify-center rounded-full border border-line px-4 py-2.5 text-sm font-medium text-ink hover:border-ink"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-4">
      <dt className="text-stone">{label}</dt>
      <dd className="text-right text-ink">{value}</dd>
    </div>
  );
}

/**
 * Shown only when Fulfillment.status === "APPROVED" — i.e. only after the
 * separate, prior "Approve & Send to Supplier" action above has already
 * happened. This panel's own action is what actually calls CJ; it has its
 * own independent two-step confirmation so a single click here can never
 * place a live supplier order either.
 */
function SubmitToSupplierPanel({
  orderId,
  orderNumber,
  fulfillment,
  cjConfigured,
}: {
  orderId: string;
  orderNumber: string;
  fulfillment: ExistingFulfillment;
  cjConfigured: boolean;
}) {
  const router = useRouter();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [status, setStatus] = useState<"idle" | "submitting" | "error">("idle");
  const [error, setError] = useState(fulfillment.lastSubmissionError ?? "");

  async function handleConfirm() {
    setStatus("submitting");
    setError("");
    const response = await fetch(`/api/admin/orders/${orderId}/submit-to-supplier`, {
      method: "POST",
    });
    const data = await response.json();
    if (!response.ok) {
      setError(data.error ?? "Could not submit this order to CJ Dropshipping.");
      setStatus("error");
      return;
    }
    setConfirmOpen(false);
    router.refresh();
  }

  return (
    <section className="mt-6 rounded-2xl border border-brass/50 bg-ivory p-5">
      <h2 className="font-display text-base text-ink">Submit to CJ Dropshipping</h2>
      <p className="mt-1 text-sm text-stone">
        This order was approved
        {fulfillment.approvedByEmailSnapshot ? ` by ${fulfillment.approvedByEmailSnapshot}` : ""}
        {fulfillment.approvedAt ? ` on ${new Date(fulfillment.approvedAt).toLocaleString()}` : ""}.
        Submitting places a real order with CJ Dropshipping using the credentials
        configured on this deployment.
      </p>

      {!cjConfigured && (
        <p className="mt-3 rounded-xl border border-dashed border-line px-3 py-2 text-xs text-stone">
          CJ Dropshipping is not configured on this deployment
          (<code>CJ_API_EMAIL</code> / <code>CJ_API_KEY</code> are unset), so
          submission is disabled here. This is a safe default, not an error —
          nothing can be sent to CJ until those are set.
        </p>
      )}

      {error && (
        <p role="alert" className="mt-3 text-sm text-rose-dark">
          {error}
        </p>
      )}

      <button
        type="button"
        onClick={() => setConfirmOpen(true)}
        disabled={!cjConfigured}
        className="mt-4 inline-flex items-center justify-center rounded-full bg-bottle px-6 py-3 text-sm font-medium text-ivory hover:bg-bottle-dark disabled:cursor-not-allowed disabled:opacity-50"
      >
        Submit to CJ Dropshipping
      </button>

      {confirmOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-ink/40 p-4">
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="submit-confirm-heading"
            className="w-full max-w-md rounded-3xl bg-ivory p-6 shadow-card"
          >
            <h3 id="submit-confirm-heading" className="font-display text-lg text-ink">
              Confirm supplier submission
            </h3>
            <p className="mt-2 text-sm text-stone">
              This will place a real order with CJ Dropshipping for{" "}
              <span className="font-medium text-ink">{orderNumber}</span>. This
              cannot be automatically undone from this dashboard.
            </p>

            {error && (
              <p role="alert" className="mt-3 text-sm text-rose-dark">
                {error}
              </p>
            )}

            <div className="mt-6 flex gap-3">
              <button
                type="button"
                onClick={handleConfirm}
                disabled={status === "submitting"}
                className="inline-flex flex-1 items-center justify-center rounded-full bg-bottle px-4 py-2.5 text-sm font-medium text-ivory hover:bg-bottle-dark disabled:opacity-70"
              >
                {status === "submitting" ? "Submitting…" : "Yes, Submit to CJ Dropshipping"}
              </button>
              <button
                type="button"
                onClick={() => setConfirmOpen(false)}
                disabled={status === "submitting"}
                className="inline-flex items-center justify-center rounded-full border border-line px-4 py-2.5 text-sm font-medium text-ink hover:border-ink"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

/**
 * Shown for any Fulfillment status past APPROVED (SUBMITTING, SUBMITTED,
 * PROCESSING, SHIPPED, DELIVERED, CANCELLED). Read-only except for the
 * "Refresh Status" action, which only ever pulls CJ's current status
 * forward (see lib/fulfillment-sync.ts) — it cannot create, approve, or
 * resubmit anything.
 *
 * BUGFIX (Phase 6 QA): this component was referenced above before it was
 * ever defined, from an earlier interrupted edit — every order whose
 * fulfillment had progressed past APPROVED would have hit a hard
 * "SubmittedStatusPanel is not defined" error, breaking the admin order
 * detail page entirely for that order. Caught by static review before
 * ever being run, not by a test — there is no working test runner in this
 * environment (see README) — which is exactly why this phase's static
 * inspection pass mattered.
 */
function SubmittedStatusPanel({
  orderId,
  fulfillment,
  cjConfigured,
}: {
  orderId: string;
  fulfillment: ExistingFulfillment;
  cjConfigured: boolean;
}) {
  const router = useRouter();
  const [status, setStatus] = useState<"idle" | "syncing" | "error">("idle");
  const [message, setMessage] = useState("");

  async function handleRefresh() {
    setStatus("syncing");
    setMessage("");
    const response = await fetch(`/api/admin/orders/${orderId}/sync-fulfillment`, {
      method: "POST",
    });
    const data = await response.json();
    if (!response.ok) {
      setMessage(data.error ?? "Could not refresh status.");
      setStatus("error");
      return;
    }
    setMessage(data.message ?? "Refreshed.");
    setStatus("idle");
    router.refresh();
  }

  const canRefresh =
    cjConfigured && ["SUBMITTED", "PROCESSING", "SHIPPED"].includes(fulfillment.status);

  return (
    <section className="mt-6 rounded-2xl border border-brass/40 bg-ivory p-5">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-base text-ink">Supplier Fulfillment</h2>
        {canRefresh && (
          <button
            type="button"
            onClick={handleRefresh}
            disabled={status === "syncing"}
            className="text-xs text-ink underline disabled:opacity-60"
          >
            {status === "syncing" ? "Refreshing…" : "Refresh Status"}
          </button>
        )}
      </div>

      <p className="mt-1 text-sm text-stone">
        Status: <span className="font-medium text-ink">{fulfillment.status}</span>
      </p>

      {fulfillment.status === "SUBMITTING" && (
        <p className="mt-1 text-sm text-stone">
          A submission to CJ Dropshipping is currently in progress. Refresh the page in a moment.
        </p>
      )}

      {fulfillment.supplierOrderId && (
        <p className="mt-1 text-sm text-stone">
          CJ order ID: <span className="font-medium text-ink">{fulfillment.supplierOrderId}</span>
        </p>
      )}

      {fulfillment.submittedAt && (
        <p className="mt-1 text-sm text-stone">
          Submitted {new Date(fulfillment.submittedAt).toLocaleString()}
          {fulfillment.submittedByEmailSnapshot ? ` by ${fulfillment.submittedByEmailSnapshot}` : ""}
        </p>
      )}

      {fulfillment.trackingNumber && (
        <p className="mt-1 text-sm text-stone">
          Tracking: <span className="font-medium text-ink">{fulfillment.trackingNumber}</span>
          {fulfillment.carrier ? ` (${fulfillment.carrier})` : ""}
        </p>
      )}

      {fulfillment.lastSyncedAt && (
        <p className="mt-2 text-xs text-stone">
          Last checked {new Date(fulfillment.lastSyncedAt).toLocaleString()}
        </p>
      )}

      {!cjConfigured && (
        <p className="mt-3 text-xs text-stone">
          CJ Dropshipping is not configured on this deployment, so status
          can't be refreshed automatically here.
        </p>
      )}

      {message && (
        <p className={`mt-3 text-sm ${status === "error" ? "text-rose-dark" : "text-stone"}`}>
          {message}
        </p>
      )}
    </section>
  );
}
