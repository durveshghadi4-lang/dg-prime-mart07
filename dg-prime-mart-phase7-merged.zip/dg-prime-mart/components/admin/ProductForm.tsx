"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export interface ProductFormCategory {
  id: string;
  name: string;
}
export interface ProductFormSupplier {
  id: string;
  name: string;
}
export interface ProductFormImage {
  url: string;
  alt: string;
}
export interface ProductFormVariant {
  name: string;
  sku: string;
  price: string;
  inventory: string;
}
export interface ProductFormInitial {
  id?: string;
  name: string;
  slug: string;
  description: string;
  shortDescription: string;
  price: string;
  compareAtPrice: string;
  currency: string;
  sku: string;
  inventory: string;
  categoryId: string;
  supplierId: string;
  supplierProductId: string;
  supplierVariantId: string;
  supplierCost: string;
  supplierShippingCost: string;
  isActive: boolean;
  isFeatured: boolean;
  isNew: boolean;
  seoTitle: string;
  seoDescription: string;
  images: ProductFormImage[];
  variants: ProductFormVariant[];
}

const emptyProduct: ProductFormInitial = {
  name: "",
  slug: "",
  description: "",
  shortDescription: "",
  price: "",
  compareAtPrice: "",
  currency: "INR",
  sku: "",
  inventory: "0",
  categoryId: "",
  supplierId: "",
  supplierProductId: "",
  supplierVariantId: "",
  supplierCost: "",
  supplierShippingCost: "",
  isActive: false,
  isFeatured: false,
  isNew: false,
  seoTitle: "",
  seoDescription: "",
  images: [],
  variants: [],
};

export function ProductForm({
  categories,
  suppliers,
  initial,
}: {
  categories: ProductFormCategory[];
  suppliers: ProductFormSupplier[];
  initial?: ProductFormInitial;
}) {
  const router = useRouter();
  const isEdit = !!initial?.id;
  const [form, setForm] = useState<ProductFormInitial>(initial ?? emptyProduct);
  const [status, setStatus] = useState<"idle" | "submitting" | "error">("idle");
  const [error, setError] = useState("");

  function update<K extends keyof ProductFormInitial>(key: K, value: ProductFormInitial[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("submitting");
    setError("");

    const payload = {
      ...form,
      price: Number(form.price),
      compareAtPrice: form.compareAtPrice ? Number(form.compareAtPrice) : null,
      inventory: Number(form.inventory),
      supplierCost: form.supplierCost ? Number(form.supplierCost) : null,
      supplierShippingCost: form.supplierShippingCost
        ? Number(form.supplierShippingCost)
        : null,
      supplierId: form.supplierId || null,
      variants: form.variants.map((v) => ({
        name: v.name,
        sku: v.sku,
        price: Number(v.price),
        inventory: Number(v.inventory),
      })),
    };

    const response = await fetch(
      isEdit ? `/api/admin/products/${initial!.id}` : "/api/admin/products",
      {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }
    );
    const data = await response.json();

    if (!response.ok) {
      setError(data.error ?? "Could not save this product.");
      setStatus("error");
      return;
    }

    router.push(`/admin/products/${data.id}`);
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <TextField label="Name" value={form.name} onChange={(v) => update("name", v)} required />
        <TextField label="Slug" value={form.slug} onChange={(v) => update("slug", v)} required />
      </div>

      <TextArea
        label="Short description"
        value={form.shortDescription}
        onChange={(v) => update("shortDescription", v)}
        required
      />
      <TextArea
        label="Description"
        value={form.description}
        onChange={(v) => update("description", v)}
        required
        rows={5}
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <TextField label="Price" type="number" value={form.price} onChange={(v) => update("price", v)} required />
        <TextField
          label="Compare-at price (optional)"
          type="number"
          value={form.compareAtPrice}
          onChange={(v) => update("compareAtPrice", v)}
        />
        <TextField label="Currency" value={form.currency} onChange={(v) => update("currency", v)} required />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <TextField label="SKU" value={form.sku} onChange={(v) => update("sku", v)} required />
        <TextField
          label="Inventory"
          type="number"
          value={form.inventory}
          onChange={(v) => update("inventory", v)}
          required
        />
      </div>

      <div className="flex flex-col gap-1.5 text-sm text-ink">
        Category
        <select
          value={form.categoryId}
          onChange={(e) => update("categoryId", e.target.value)}
          required
          className="rounded-full border border-line px-4 py-2.5 text-sm text-ink"
        >
          <option value="">Select a category</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-wrap gap-6 text-sm text-ink">
        <Checkbox label="Active" checked={form.isActive} onChange={(v) => update("isActive", v)} />
        <Checkbox label="Featured" checked={form.isFeatured} onChange={(v) => update("isFeatured", v)} />
        <Checkbox label="New" checked={form.isNew} onChange={(v) => update("isNew", v)} />
      </div>

      <fieldset className="rounded-2xl border border-line p-4">
        <legend className="px-1 text-sm text-ink">Supplier mapping</legend>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5 text-sm text-ink">
            Supplier
            <select
              value={form.supplierId}
              onChange={(e) => update("supplierId", e.target.value)}
              className="rounded-full border border-line px-4 py-2.5 text-sm text-ink"
            >
              <option value="">Not mapped</option>
              {suppliers.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <TextField
            label="Supplier product ID"
            value={form.supplierProductId}
            onChange={(v) => update("supplierProductId", v)}
          />
          <TextField
            label="Supplier variant ID (optional)"
            value={form.supplierVariantId}
            onChange={(v) => update("supplierVariantId", v)}
          />
          <TextField
            label="Supplier cost (per unit)"
            type="number"
            value={form.supplierCost}
            onChange={(v) => update("supplierCost", v)}
          />
          <TextField
            label="Supplier shipping cost"
            type="number"
            value={form.supplierShippingCost}
            onChange={(v) => update("supplierShippingCost", v)}
          />
        </div>
        <p className="mt-2 text-xs text-stone">
          Used only to estimate gross margin at approval time — never shown
          to customers.
        </p>
      </fieldset>

      <fieldset className="rounded-2xl border border-line p-4">
        <legend className="px-1 text-sm text-ink">Images</legend>
        {form.images.map((img, i) => (
          <div key={i} className="mb-2 flex gap-2">
            <input
              type="text"
              placeholder="Image URL"
              value={img.url}
              onChange={(e) => {
                const next = [...form.images];
                next[i] = { ...next[i], url: e.target.value };
                update("images", next);
              }}
              className="flex-1 rounded-full border border-line px-4 py-2 text-sm text-ink"
            />
            <input
              type="text"
              placeholder="Alt text"
              value={img.alt}
              onChange={(e) => {
                const next = [...form.images];
                next[i] = { ...next[i], alt: e.target.value };
                update("images", next);
              }}
              className="flex-1 rounded-full border border-line px-4 py-2 text-sm text-ink"
            />
            <button
              type="button"
              onClick={() => update("images", form.images.filter((_, idx) => idx !== i))}
              className="text-xs text-stone hover:text-rose-dark"
            >
              Remove
            </button>
          </div>
        ))}
        <button
          type="button"
          onClick={() => update("images", [...form.images, { url: "", alt: "" }])}
          className="text-xs text-ink underline"
        >
          + Add image
        </button>
      </fieldset>

      <fieldset className="rounded-2xl border border-line p-4">
        <legend className="px-1 text-sm text-ink">Variants (optional)</legend>
        {form.variants.map((variant, i) => (
          <div key={i} className="mb-2 grid grid-cols-4 gap-2">
            <input
              type="text"
              placeholder="Name (e.g. Medium / Rose)"
              value={variant.name}
              onChange={(e) => {
                const next = [...form.variants];
                next[i] = { ...next[i], name: e.target.value };
                update("variants", next);
              }}
              className="rounded-full border border-line px-3 py-2 text-sm text-ink"
            />
            <input
              type="text"
              placeholder="SKU"
              value={variant.sku}
              onChange={(e) => {
                const next = [...form.variants];
                next[i] = { ...next[i], sku: e.target.value };
                update("variants", next);
              }}
              className="rounded-full border border-line px-3 py-2 text-sm text-ink"
            />
            <input
              type="number"
              placeholder="Price"
              value={variant.price}
              onChange={(e) => {
                const next = [...form.variants];
                next[i] = { ...next[i], price: e.target.value };
                update("variants", next);
              }}
              className="rounded-full border border-line px-3 py-2 text-sm text-ink"
            />
            <div className="flex gap-2">
              <input
                type="number"
                placeholder="Inventory"
                value={variant.inventory}
                onChange={(e) => {
                  const next = [...form.variants];
                  next[i] = { ...next[i], inventory: e.target.value };
                  update("variants", next);
                }}
                className="w-full rounded-full border border-line px-3 py-2 text-sm text-ink"
              />
              <button
                type="button"
                onClick={() => update("variants", form.variants.filter((_, idx) => idx !== i))}
                className="text-xs text-stone hover:text-rose-dark"
              >
                ✕
              </button>
            </div>
          </div>
        ))}
        <button
          type="button"
          onClick={() =>
            update("variants", [
              ...form.variants,
              { name: "", sku: "", price: "", inventory: "0" },
            ])
          }
          className="text-xs text-ink underline"
        >
          + Add variant
        </button>
      </fieldset>

      <div className="grid gap-4 sm:grid-cols-2">
        <TextField label="SEO title" value={form.seoTitle} onChange={(v) => update("seoTitle", v)} />
        <TextField
          label="SEO description"
          value={form.seoDescription}
          onChange={(v) => update("seoDescription", v)}
        />
      </div>

      {error && (
        <p role="alert" className="text-sm text-rose-dark">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={status === "submitting"}
        className="w-fit rounded-full bg-ink px-6 py-3 text-sm font-medium text-ivory hover:bg-bottle disabled:opacity-70"
      >
        {status === "submitting" ? "Saving…" : isEdit ? "Save Changes" : "Create Product"}
      </button>
    </form>
  );
}

function TextField({
  label,
  value,
  onChange,
  type = "text",
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <label className="flex flex-col gap-1.5 text-sm text-ink">
      {label}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        step={type === "number" ? "0.01" : undefined}
        className="rounded-full border border-line px-4 py-2.5 text-sm text-ink outline-none focus:border-brass"
      />
    </label>
  );
}

function TextArea({
  label,
  value,
  onChange,
  required,
  rows = 3,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
  rows?: number;
}) {
  return (
    <label className="flex flex-col gap-1.5 text-sm text-ink">
      {label}
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        rows={rows}
        className="rounded-2xl border border-line px-4 py-2.5 text-sm text-ink outline-none focus:border-brass"
      />
    </label>
  );
}

function Checkbox({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex items-center gap-2">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      {label}
    </label>
  );
}
