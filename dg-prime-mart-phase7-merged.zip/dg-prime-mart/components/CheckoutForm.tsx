"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Script from "next/script";
import { useSession } from "next-auth/react";
import { useCart } from "@/components/CartProvider";
import { formatPrice } from "@/lib/config";
import type { AddressRecord } from "@/components/AddressManager";

declare global {
  interface Window {
    paypal?: {
      Buttons: (options: {
        createOrder: () => string;
        onApprove: (data: { orderID: string }) => Promise<void>;
        onError?: (err: unknown) => void;
        onCancel?: () => void;
      }) => { render: (selector: string) => void };
    };
  }
}

const emptyAddress = {
  firstName: "",
  lastName: "",
  addressLine1: "",
  addressLine2: "",
  city: "",
  state: "",
  postalCode: "",
  country: "",
  phone: "",
};

type Stage = "details" | "payment" | "processing";

export function CheckoutForm() {
  const router = useRouter();
  const { lines, subtotal } = useCart();
  const { data: session, status: sessionStatus } = useSession();

  const [savedAddresses, setSavedAddresses] = useState<AddressRecord[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<string | "new">("new");
  const [address, setAddress] = useState(emptyAddress);
  const [guestEmail, setGuestEmail] = useState("");
  const [couponCode, setCouponCode] = useState("");
  const [stage, setStage] = useState<Stage>("details");
  const [error, setError] = useState("");
  const [lineErrors, setLineErrors] = useState<string[]>([]);
  const [checkoutResult, setCheckoutResult] = useState<{
    orderId: string;
    paypalOrderId: string;
    total: number;
    currency: string;
    discount: number;
    shipping: number;
    guestToken: string | null;
  } | null>(null);
  const buttonsRendered = useRef(false);

  const isAuthenticated = sessionStatus === "authenticated";

  useEffect(() => {
    if (!isAuthenticated) return;
    fetch("/api/account/addresses")
      .then((r) => r.json())
      .then((data) => {
        setSavedAddresses(data.addresses ?? []);
        const defaultAddr = (data.addresses ?? []).find(
          (a: AddressRecord) => a.isDefault
        );
        if (defaultAddr) setSelectedAddressId(defaultAddr.id);
      })
      .catch(() => {});
  }, [isAuthenticated]);

  async function handleSubmitDetails(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLineErrors([]);

    const shippingAddress =
      selectedAddressId !== "new"
        ? savedAddresses.find((a) => a.id === selectedAddressId)
        : address;

    if (!shippingAddress) {
      setError("Please provide a shipping address.");
      return;
    }

    if (!isAuthenticated && !guestEmail.includes("@")) {
      setError("Please enter a valid email address.");
      return;
    }

    if (lines.length === 0) {
      setError("Your cart is empty.");
      return;
    }

    setStage("processing");

    const response = await fetch("/api/checkout/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        guestEmail: isAuthenticated ? undefined : guestEmail,
        lines: lines.map((l) => ({ productId: l.productId, quantity: l.quantity })),
        couponCode: couponCode.trim() || undefined,
        shippingAddress: {
          firstName: shippingAddress.firstName,
          lastName: shippingAddress.lastName,
          addressLine1: shippingAddress.addressLine1,
          addressLine2: shippingAddress.addressLine2 || undefined,
          city: shippingAddress.city,
          state: shippingAddress.state,
          postalCode: shippingAddress.postalCode,
          country: shippingAddress.country,
          phone: shippingAddress.phone || undefined,
        },
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      setError(data.error ?? "Could not start checkout.");
      setLineErrors(data.lineErrors ?? []);
      setStage("details");
      return;
    }

    setCheckoutResult({
      orderId: data.orderId,
      paypalOrderId: data.paypalOrderId,
      total: data.total,
      currency: data.currency,
      discount: data.discount,
      shipping: data.shipping,
      guestToken: data.guestToken,
    });
    setLineErrors(data.lineErrors ?? []);
    setStage("payment");
  }

  function renderPayPalButtons() {
    if (buttonsRendered.current || !checkoutResult || !window.paypal) return;
    buttonsRendered.current = true;

    window.paypal.Buttons({
      createOrder: () => checkoutResult.paypalOrderId,
      onApprove: async () => {
        setStage("processing");
        const response = await fetch("/api/checkout/capture", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ paypalOrderId: checkoutResult.paypalOrderId }),
        });
        const data = await response.json();
        if (!response.ok) {
          setError(data.error ?? "Payment could not be completed.");
          setStage("payment");
          return;
        }
        const query = data.guestToken ? `?guestToken=${data.guestToken}` : "";
        router.push(`/order/confirmation/${data.orderId}${query}`);
      },
      onCancel: () => {
        setError("Payment was cancelled. You can try again below.");
      },
      onError: () => {
        setError("PayPal reported an error. Please try again.");
      },
    }).render("#paypal-button-container");
  }

  if (lines.length === 0 && stage === "details") {
    return (
      <p className="text-sm text-stone">
        Your cart is empty.{" "}
        <a href="/shop" className="underline">
          Continue shopping
        </a>
        .
      </p>
    );
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[1fr_380px]">
      <div>
        {stage !== "payment" ? (
          <form onSubmit={handleSubmitDetails} className="flex flex-col gap-6">
            {!isAuthenticated && (
              <Field
                label="Email"
                value={guestEmail}
                onChange={setGuestEmail}
                type="email"
                required
              />
            )}

            {isAuthenticated && savedAddresses.length > 0 && (
              <div className="flex flex-col gap-2">
                <p className="text-sm text-ink">Shipping address</p>
                {savedAddresses.map((a) => (
                  <label
                    key={a.id}
                    className="flex items-start gap-2 rounded-2xl border border-line p-4 text-sm"
                  >
                    <input
                      type="radio"
                      name="address"
                      checked={selectedAddressId === a.id}
                      onChange={() => setSelectedAddressId(a.id)}
                      className="mt-1"
                    />
                    <span>
                      {a.firstName} {a.lastName}, {a.addressLine1},{" "}
                      {a.city}, {a.state} {a.postalCode}, {a.country}
                    </span>
                  </label>
                ))}
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="radio"
                    name="address"
                    checked={selectedAddressId === "new"}
                    onChange={() => setSelectedAddressId("new")}
                  />
                  Use a new address
                </label>
              </div>
            )}

            {(selectedAddressId === "new" || savedAddresses.length === 0) && (
              <div className="grid gap-4">
                <div className="grid grid-cols-2 gap-3">
                  <Field label="First name" value={address.firstName} onChange={(v) => setAddress({ ...address, firstName: v })} required />
                  <Field label="Last name" value={address.lastName} onChange={(v) => setAddress({ ...address, lastName: v })} required />
                </div>
                <Field label="Address line 1" value={address.addressLine1} onChange={(v) => setAddress({ ...address, addressLine1: v })} required />
                <Field label="Address line 2 (optional)" value={address.addressLine2} onChange={(v) => setAddress({ ...address, addressLine2: v })} />
                <div className="grid grid-cols-2 gap-3">
                  <Field label="City" value={address.city} onChange={(v) => setAddress({ ...address, city: v })} required />
                  <Field label="State" value={address.state} onChange={(v) => setAddress({ ...address, state: v })} required />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Postal code" value={address.postalCode} onChange={(v) => setAddress({ ...address, postalCode: v })} required />
                  <Field label="Country" value={address.country} onChange={(v) => setAddress({ ...address, country: v })} required />
                </div>
                <Field label="Phone (optional)" value={address.phone} onChange={(v) => setAddress({ ...address, phone: v })} />
              </div>
            )}

            <Field label="Coupon code (optional)" value={couponCode} onChange={setCouponCode} />

            {error && (
              <p role="alert" className="text-sm text-rose-dark">
                {error}
              </p>
            )}
            {lineErrors.map((msg) => (
              <p key={msg} className="text-sm text-rose-dark">
                {msg}
              </p>
            ))}

            <button
              type="submit"
              disabled={stage === "processing"}
              className="inline-flex items-center justify-center rounded-full bg-ink px-6 py-3 text-sm font-medium text-ivory transition-colors hover:bg-bottle disabled:opacity-70"
            >
              {stage === "processing" ? "Preparing checkout…" : "Continue to Payment"}
            </button>
          </form>
        ) : (
          <div className="flex flex-col gap-4">
            <p className="text-sm text-stone">
              Complete your payment securely with PayPal.
            </p>
            {error && (
              <p role="alert" className="text-sm text-rose-dark">
                {error}
              </p>
            )}
            <div id="paypal-button-container" />
            {stage === "processing" && (
              <p className="text-sm text-stone">Processing your payment…</p>
            )}
            <button
              type="button"
              onClick={() => {
                setStage("details");
                buttonsRendered.current = false;
              }}
              className="w-fit text-xs text-stone hover:text-ink"
            >
              ← Back to details
            </button>
          </div>
        )}
      </div>

      <aside className="h-fit rounded-2xl border border-line p-6">
        <p className="mb-4 font-display text-lg text-ink">Order Summary</p>
        <ul className="flex flex-col gap-2 text-sm text-ink/80">
          {lines.map((l) => (
            <li key={l.productId} className="flex justify-between">
              <span>
                {l.name} × {l.quantity}
              </span>
              <span>{formatPrice(l.price * l.quantity, l.currency)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex flex-col gap-1 border-t border-line pt-4 text-sm">
          <div className="flex justify-between text-stone">
            <span>Subtotal</span>
            <span>{formatPrice(subtotal)}</span>
          </div>
          {checkoutResult && (
            <>
              {checkoutResult.discount > 0 && (
                <div className="flex justify-between text-stone">
                  <span>Discount</span>
                  <span>-{formatPrice(checkoutResult.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-stone">
                <span>Shipping</span>
                <span>
                  {checkoutResult.shipping === 0
                    ? "Free"
                    : formatPrice(checkoutResult.shipping)}
                </span>
              </div>
              <div className="mt-1 flex justify-between font-display text-base text-ink">
                <span>Total</span>
                <span>{formatPrice(checkoutResult.total, checkoutResult.currency)}</span>
              </div>
            </>
          )}
        </div>
      </aside>

      {stage === "payment" && checkoutResult && (
        <Script
          src={`https://www.paypal.com/sdk/js?client-id=${process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID}&currency=${checkoutResult.currency}`}
          onReady={renderPayPalButtons}
          onLoad={renderPayPalButtons}
        />
      )}
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <label className="flex flex-col gap-1.5 text-sm text-ink">
      {label}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        className="rounded-full border border-line px-4 py-2.5 text-sm text-ink outline-none focus:border-brass"
      />
    </label>
  );
}
