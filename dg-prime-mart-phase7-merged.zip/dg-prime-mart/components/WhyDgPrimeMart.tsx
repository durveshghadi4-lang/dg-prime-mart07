const reasons = [
  {
    title: "Considered curation",
    description: "Every product is selected, not just listed.",
  },
  {
    title: "Reviewed before it ships",
    description: "Orders are checked by our team before fulfillment.",
  },
  {
    title: "Made for everyday life",
    description: "Pieces that hold up to real routines, not just photos.",
  },
];

export function WhyDgPrimeMart() {
  return (
    <section className="border-y border-line bg-bottle text-ivory">
      <div className="mx-auto max-w-container px-4 py-14 sm:px-6 lg:px-8">
        <h2 className="font-display text-2xl sm:text-3xl">Why DG PRIME MART</h2>
        <div className="mt-8 grid gap-8 sm:grid-cols-3">
          {reasons.map((reason) => (
            <div key={reason.title}>
              <p className="font-display text-lg">{reason.title}</p>
              <p className="mt-2 text-sm text-ivory/75">
                {reason.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
