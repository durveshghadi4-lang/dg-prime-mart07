import Link from "next/link";
import { PlaceholderArt } from "./PlaceholderArt";

export function PromoBanner() {
  return (
    <section className="mx-auto max-w-container px-4 py-14 sm:px-6 lg:px-8">
      <div className="relative overflow-hidden rounded-3xl">
        <PlaceholderArt
          seed="promo-banner"
          categorySlug="lifestyle"
          className="absolute inset-0"
        />
        <div className="relative flex flex-col items-start gap-4 px-6 py-14 sm:px-12 sm:py-20">
          <p className="eyebrow text-ivory/80">Limited time</p>
          <h2 className="max-w-md font-display text-3xl leading-tight text-ivory sm:text-4xl">
            10% off your first order
          </h2>
          <Link
            href="/shop"
            className="inline-flex items-center justify-center rounded-full bg-ivory px-6 py-3 text-sm font-medium text-ink transition-colors hover:bg-parchment"
          >
            Shop Now
          </Link>
        </div>
      </div>
    </section>
  );
}
