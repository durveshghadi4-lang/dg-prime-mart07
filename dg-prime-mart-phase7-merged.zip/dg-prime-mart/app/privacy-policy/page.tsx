import type { Metadata } from "next";
import { PageHeader } from "@/components/PageHeader";

export const metadata: Metadata = { title: "Privacy Policy" };

export default function PrivacyPolicyPage() {
  return (
    <>
      <PageHeader title="Privacy Policy" />
      <div className="mx-auto max-w-2xl px-4 py-10 text-sm leading-relaxed text-ink/80 sm:px-6 lg:px-8">
        <p>
          Placeholder policy text. Replace with a real privacy policy covering
          data collection, storage and third-party processors (payments,
          analytics, supplier) before launch.
        </p>
      </div>
    </>
  );
}
