import type { MetadataRoute } from "next";
import { siteConfig } from "@/lib/config";
import { categories } from "@/lib/categories";

// TODO(backend): append real product routes once the catalog exists
// (currently only static + category routes are listed).
export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes = ["", "/shop", "/about", "/contact", "/faq"].map(
    (path) => ({
      url: `${siteConfig.url}${path}`,
      lastModified: new Date(),
    })
  );

  const categoryRoutes = categories.map((category) => ({
    url: `${siteConfig.url}/category/${category.slug}`,
    lastModified: new Date(),
  }));

  return [...staticRoutes, ...categoryRoutes];
}
