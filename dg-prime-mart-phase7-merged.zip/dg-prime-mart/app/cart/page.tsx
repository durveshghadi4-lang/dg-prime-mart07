"use client";

import Link from "next/link";
import { useCart } from "@/components/CartProvider";
import { PageHeader } from "@/components/PageHeader";
import { formatPrice, shippingConfig } from "@/lib/config";

export default function CartPage() {
  const { lines, removeFromCart, setQuantity, subtotal } = useCart();
  const remainingForFreeShipping = Math.max(
    shippingConfig.freeShippingThreshold - subtotal,
    0
  );

  return (
    <>
      <PageHeader title="Your Cart" />
      <div className="mx-auto max-w-container px-4 py-10 sm:px-6 lg:px-8">
        {lines.length === 0 ? (
          <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-line px-6 py-16 text-center">
            <p className="font-display text-xl text-ink">Your cart is empty</p>
            <p className="max-w-sm text-sm text-stone">
              Nothing added yet. Browse the shop to find something you'll love.
            </p>
            <Link
              href="/shop"
              className="mt-2 inline-flex items-center justify-center rounded-full bg-ink px-6 py-3 text-sm font-medium text-ivory hover:bg-bottle"
            >
              Shop Now
            </Link>
          </div>
        ) : (
          <div className="grid gap-10 lg:grid-cols-[1fr_360px]">
            <div className="flex flex-col divide-y divide-line">
              {lines.map((line) => (
                <div key={line.productId} className="flex items-center gap-4 py-5">
                  <div className="flex-1">
                    <Link
                      href={`/product/${line.slug}`}
                      className="font-display text-base text-ink hover:underline"
                    >
                      {line.name}
                    </Link>
                    <p className="mt-1 text-sm text-stone">
                      {formatPrice(line.price, line.currency)} each
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <label className="sr-only" htmlFor={`qty-${line.productId}`}>
                      Quantity for {line.name}
                    </label>
                    <select
                      id={`qty-${line.productId}`}
                      value={line.quantity}
                      onChange={(e) =>
                        setQuantity(line.productId, Number(e.target.value))
                      }
                      className="rounded-full border border-line px-3 py-1.5 text-sm text-ink"
                    >
                      {Array.from({ length: 10 }).map((_, i) => (
                        <option key={i + 1} value={i + 1}>
                          {i + 1}
                        </option>
                      ))}
                    </select>
                  </div>

                  <p className="w-20 text-right text-sm text-ink">
                    {formatPrice(line.price * line.quantity, line.currency)}
                  </p>

                  <button
                    type="button"
                    onClick={() => removeFromCart(line.productId)}
                    aria-label={`Remove ${line.name} from cart`}
                    className="text-xs text-stone hover:text-rose-dark"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>

            <aside className="h-fit rounded-2xl border border-line p-6">
              <div className="flex items-center justify-between text-sm">
                <span className="text-stone">Subtotal</span>
                <span className="font-display text-lg text-ink">
                  {formatPrice(subtotal)}
                </span>
              </div>
              <p className="mt-2 text-xs text-stone">
                {remainingForFreeShipping > 0
                  ? `Add ${formatPrice(remainingForFreeShipping)} more for free shipping.`
                  : "You've unlocked free shipping."}
              </p>
              <Link
                href="/checkout"
                className="mt-6 block w-full rounded-full bg-ink px-4 py-3 text-center text-sm font-medium text-ivory transition-colors hover:bg-bottle"
              >
                Proceed to Checkout
              </Link>
            </aside>
          </div>
        )}
      </div>
    </>
  );
}
