import type { Metadata } from "next";
import Link from "next/link";
import { PageHeader } from "@/components/PageHeader";
import { ProductGrid } from "@/components/ProductGrid";
import { categories } from "@/lib/categories";
import { getAllDemoProducts } from "@/lib/demo-data";

export const metadata: Metadata = { title: "Shop" };

export default function ShopPage() {
  // TODO(backend): replace with a real paginated product query.
  const products = getAllDemoProducts();

  return (
    <>
      <PageHeader
        title="Shop All"
        description="Every current category, in one place."
      />
      <div className="mx-auto max-w-container px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-8 flex flex-wrap gap-2">
          {categories.map((category) => (
            <Link
              key={category.slug}
              href={`/category/${category.slug}`}
              className="rounded-full border border-line px-4 py-2 text-sm text-ink hover:border-ink"
            >
              {category.name}
            </Link>
          ))}
        </div>
        <ProductGrid products={products} />
      </div>
    </>
  );
}
