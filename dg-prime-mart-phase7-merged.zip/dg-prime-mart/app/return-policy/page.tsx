import type { Metadata } from "next";
import { PageHeader } from "@/components/PageHeader";

export const metadata: Metadata = { title: "Return & Refund Policy" };

export default function ReturnPolicyPage() {
  return (
    <>
      <PageHeader title="Return & Refund Policy" />
      <div className="mx-auto max-w-2xl px-4 py-10 text-sm leading-relaxed text-ink/80 sm:px-6 lg:px-8">
        <p>
          Placeholder policy text. Replace with real return windows, conditions
          and refund timelines before launch.
        </p>
      </div>
    </>
  );
}
