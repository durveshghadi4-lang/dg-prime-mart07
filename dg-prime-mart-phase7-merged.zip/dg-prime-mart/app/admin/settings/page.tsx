import type { Metadata } from "next";
import { getAllSettings, SETTINGS_KEYS } from "@/lib/settings";
import { SettingsForm } from "@/components/admin/SettingsForm";

export const metadata: Metadata = { title: "Settings" };

const FIELDS: { key: string; label: string; type?: string }[] = [
  { key: SETTINGS_KEYS.storeName, label: "Store name" },
  { key: SETTINGS_KEYS.storeContactEmail, label: "Store contact email", type: "email" },
  { key: SETTINGS_KEYS.defaultCurrency, label: "Default currency" },
  { key: SETTINGS_KEYS.freeShippingThreshold, label: "Free shipping threshold", type: "number" },
  { key: SETTINGS_KEYS.standardShippingCharge, label: "Standard shipping charge", type: "number" },
  { key: SETTINGS_KEYS.lowStockThreshold, label: "Low stock threshold (units)", type: "number" },
  { key: SETTINGS_KEYS.whatsappNumber, label: "WhatsApp number (E.164, no +)" },
  { key: SETTINGS_KEYS.whatsappMessage, label: "WhatsApp welcome message" },
];

export default async function AdminSettingsPage() {
  const settings = await getAllSettings();

  return (
    <div>
      <h1 className="font-display text-2xl text-ink">Settings</h1>
      <div className="mt-3 max-w-2xl rounded-xl border border-brass/40 bg-parchment px-4 py-3 text-xs text-stone">
        Saving here updates the database, which is where a future phase
        will read these values from. Right now the live storefront still
        reads its defaults from environment variables (see{" "}
        <code>lib/config.ts</code>) — this page doesn't yet change what a
        customer sees. No secrets (PayPal keys, supplier credentials) are
        editable here.
      </div>

      <div className="mt-6 max-w-2xl">
        <SettingsForm fields={FIELDS} initialValues={settings} />
      </div>
    </div>
  );
}
