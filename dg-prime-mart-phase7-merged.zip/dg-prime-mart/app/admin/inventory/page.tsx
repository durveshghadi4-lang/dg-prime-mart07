import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getLowStockThreshold } from "@/lib/settings";

export const metadata: Metadata = { title: "Inventory" };

function statusFor(inventory: number, lowStockThreshold: number) {
  if (inventory <= 0) return { label: "Out of Stock", className: "bg-rose text-ivory" };
  if (inventory <= lowStockThreshold)
    return { label: "Low Stock", className: "bg-brass text-ivory" };
  return { label: "In Stock", className: "bg-bottle text-ivory" };
}

export default async function AdminInventoryPage() {
  const lowStockThreshold = await getLowStockThreshold();
  const products = await prisma.product.findMany({
    orderBy: { inventory: "asc" },
    select: { id: true, name: true, sku: true, inventory: true },
    take: 300,
  });

  return (
    <div>
      <h1 className="font-display text-2xl text-ink">Inventory</h1>
      <p className="mt-1 text-sm text-stone">
        Low-stock threshold: {lowStockThreshold} units — change it in{" "}
        <Link href="/admin/settings" className="underline">
          Settings
        </Link>
        .
      </p>

      {products.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-line px-6 py-16 text-center text-sm text-stone">
          No products yet.
        </div>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-ivory">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-xs text-stone">
              <tr>
                <th className="px-4 py-3">Product</th>
                <th className="px-4 py-3">SKU</th>
                <th className="px-4 py-3">Inventory</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => {
                const status = statusFor(product.inventory, lowStockThreshold);
                return (
                  <tr key={product.id} className="border-b border-line last:border-0">
                    <td className="px-4 py-3">
                      <Link href={`/admin/products/${product.id}`} className="text-ink underline">
                        {product.name}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-stone">{product.sku}</td>
                    <td className="px-4 py-3 text-stone">{product.inventory}</td>
                    <td className="px-4 py-3">
                      <span className={`rounded-full px-2.5 py-1 text-xs ${status.className}`}>
                        {status.label}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
