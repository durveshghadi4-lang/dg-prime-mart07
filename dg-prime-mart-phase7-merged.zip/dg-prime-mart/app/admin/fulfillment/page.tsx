import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/config";
import type { FulfillmentStatus } from "@prisma/client";

export const metadata: Metadata = { title: "Fulfillment" };

const GROUPS: { status: FulfillmentStatus; label: string }[] = [
  { status: "PENDING_APPROVAL", label: "Awaiting Approval" },
  { status: "APPROVED", label: "Approved" },
  { status: "SUBMITTING", label: "Submitting…" },
  { status: "SUBMITTED", label: "Submitted" },
  { status: "PROCESSING", label: "Processing" },
  { status: "SHIPPED", label: "Shipped" },
  { status: "DELIVERED", label: "Delivered" },
  { status: "CANCELLED", label: "Cancelled" },
];

export default async function AdminFulfillmentPage() {
  // PAID orders with no Fulfillment row yet haven't even reached
  // PENDING_APPROVAL formally — surface them alongside PENDING_APPROVAL so
  // nothing paid is invisible to this page.
  const [paidWithoutFulfillment, fulfillments] = await Promise.all([
    prisma.order.findMany({
      where: { status: "PAID", fulfillment: null },
      orderBy: { createdAt: "asc" },
      select: { id: true, orderNumber: true, email: true, total: true, currency: true },
    }),
    prisma.fulfillment.findMany({
      include: {
        order: { select: { orderNumber: true, email: true, total: true, currency: true } },
      },
      orderBy: { updatedAt: "desc" },
    }),
  ]);

  const grouped = GROUPS.map((g) => ({
    ...g,
    rows: fulfillments.filter((f) => f.status === g.status),
  }));

  return (
    <div>
      <h1 className="font-display text-2xl text-ink">Fulfillment</h1>
      <p className="mt-1 text-sm text-stone">
        No order here has been submitted to a real supplier — that
        integration doesn't exist yet.
      </p>

      <section className="mt-6">
        <h2 className="mb-2 font-display text-base text-ink">
          Awaiting Approval ({paidWithoutFulfillment.length + (grouped[0]?.rows.length ?? 0)})
        </h2>
        {paidWithoutFulfillment.length === 0 && grouped[0]?.rows.length === 0 ? (
          <EmptyRow text="No orders awaiting supplier approval." />
        ) : (
          <Table>
            {paidWithoutFulfillment.map((order) => (
              <Row
                key={order.id}
                href={`/admin/orders/${order.id}`}
                orderNumber={order.orderNumber}
                email={order.email}
                total={Number(order.total)}
                currency={order.currency}
              />
            ))}
            {grouped[0]?.rows.map((f) => (
              <Row
                key={f.id}
                href={`/admin/orders/${f.orderId}`}
                orderNumber={f.order.orderNumber}
                email={f.order.email}
                total={Number(f.order.total)}
                currency={f.order.currency}
              />
            ))}
          </Table>
        )}
      </section>

      {grouped.slice(1).map((group) => (
        <section key={group.status} className="mt-8">
          <h2 className="mb-2 font-display text-base text-ink">
            {group.label} ({group.rows.length})
          </h2>
          {group.rows.length === 0 ? (
            <EmptyRow text={`No orders ${group.label.toLowerCase()}.`} />
          ) : (
            <Table>
              {group.rows.map((f) => (
                <Row
                  key={f.id}
                  href={`/admin/orders/${f.orderId}`}
                  orderNumber={f.order.orderNumber}
                  email={f.order.email}
                  total={Number(f.order.total)}
                  currency={f.order.currency}
                />
              ))}
            </Table>
          )}
        </section>
      ))}
    </div>
  );
}

function Table({ children }: { children: React.ReactNode }) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-line bg-ivory">
      <table className="w-full text-left text-sm">
        <thead className="border-b border-line text-xs text-stone">
          <tr>
            <th className="px-4 py-3">Order</th>
            <th className="px-4 py-3">Customer</th>
            <th className="px-4 py-3">Total</th>
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

function Row({
  href,
  orderNumber,
  email,
  total,
  currency,
}: {
  href: string;
  orderNumber: string;
  email: string;
  total: number;
  currency: string;
}) {
  return (
    <tr className="border-b border-line last:border-0">
      <td className="px-4 py-3">
        <Link href={href} className="text-ink underline">
          {orderNumber}
        </Link>
      </td>
      <td className="px-4 py-3 text-stone">{email}</td>
      <td className="px-4 py-3 text-stone">{formatPrice(total, currency)}</td>
    </tr>
  );
}

function EmptyRow({ text }: { text: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-line px-6 py-8 text-center text-sm text-stone">
      {text}
    </div>
  );
}
