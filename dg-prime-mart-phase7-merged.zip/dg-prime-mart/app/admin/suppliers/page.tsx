import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { AddSupplierForm } from "@/components/admin/AddSupplierForm";

export const metadata: Metadata = { title: "Suppliers" };

export default async function AdminSuppliersPage() {
  const suppliers = await prisma.supplier.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { products: true } } },
  });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl text-ink">Suppliers</h1>
        <AddSupplierForm />
      </div>

      <div className="mt-3 rounded-xl border border-brass/40 bg-parchment px-4 py-2 text-xs text-stone">
        No supplier here is connected to a live API yet. Credentials are
        referenced by name only — never stored here in plaintext.
      </div>

      {suppliers.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-line px-6 py-16 text-center text-sm text-stone">
          No suppliers configured.
        </div>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-ivory">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-xs text-stone">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Provider</th>
                <th className="px-4 py-3">Mapped Products</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {suppliers.map((supplier) => (
                <tr key={supplier.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-3 text-ink">{supplier.name}</td>
                  <td className="px-4 py-3 text-stone">{supplier.provider}</td>
                  <td className="px-4 py-3 text-stone">{supplier._count.products}</td>
                  <td className="px-4 py-3 text-stone">
                    {supplier.active ? "Active" : "Inactive"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
