import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { CouponManager } from "@/components/admin/CouponManager";

export const metadata: Metadata = { title: "Coupons" };

export default async function AdminCouponsPage() {
  const coupons = await prisma.coupon.findMany({
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { redemptions: true } } },
  });

  return (
    <div>
      <h1 className="font-display text-2xl text-ink">Coupons</h1>
      <p className="mt-1 text-sm text-stone">
        DG10's code is protected from renaming here — deactivate and create
        a new coupon instead of renaming it.
      </p>
      <div className="mt-6">
        <CouponManager
          initialCoupons={coupons.map((c) => ({
            id: c.id,
            code: c.code,
            discountType: c.discountType,
            discountValue: String(c.discountValue),
            minimumOrderAmount: c.minimumOrderAmount ? String(c.minimumOrderAmount) : null,
            usageLimit: c.usageLimit,
            perCustomerLimit: c.perCustomerLimit,
            firstOrderOnly: c.firstOrderOnly,
            active: c.active,
            redemptionCount: c._count.redemptions,
          }))}
        />
      </div>
    </div>
  );
}
