import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/config";
import type { Prisma, OrderStatus } from "@prisma/client";

export const metadata: Metadata = { title: "Orders" };

const FILTERS: { label: string; value: string }[] = [
  { label: "All", value: "all" },
  { label: "Paid", value: "PAID" },
  { label: "Awaiting Supplier Approval", value: "AWAITING_SUPPLIER_APPROVAL" },
  { label: "Supplier Approved", value: "SUPPLIER_APPROVED" },
  { label: "Shipped", value: "SHIPPED" },
  { label: "Delivered", value: "DELIVERED" },
  { label: "Cancelled", value: "CANCELLED" },
  { label: "Refunded", value: "REFUNDED" },
];

export default async function AdminOrdersPage({
  searchParams,
}: {
  searchParams: { status?: string; q?: string };
}) {
  const status = searchParams.status ?? "all";
  const q = searchParams.q?.trim() ?? "";

  const where: Prisma.OrderWhereInput = {
    ...(status !== "all" ? { status: status as OrderStatus } : {}),
    ...(q
      ? {
          OR: [
            { orderNumber: { contains: q, mode: "insensitive" } },
            { email: { contains: q, mode: "insensitive" } },
          ],
        }
      : {}),
  };

  const orders = await prisma.order.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { fulfillment: true, payments: true },
  });

  return (
    <div>
      <h1 className="font-display text-2xl text-ink">Orders</h1>

      <form className="mt-4 flex flex-wrap items-center gap-3">
        <input
          type="text"
          name="q"
          defaultValue={q}
          placeholder="Search order number or email"
          className="rounded-full border border-line px-4 py-2 text-sm text-ink outline-none focus:border-brass"
        />
        <select
          name="status"
          defaultValue={status}
          className="rounded-full border border-line px-4 py-2 text-sm text-ink"
        >
          {FILTERS.map((f) => (
            <option key={f.value} value={f.value}>
              {f.label}
            </option>
          ))}
        </select>
        <button
          type="submit"
          className="rounded-full bg-ink px-5 py-2 text-sm font-medium text-ivory hover:bg-bottle"
        >
          Apply
        </button>
      </form>

      {orders.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-line px-6 py-16 text-center text-sm text-stone">
          No orders match this filter.
        </div>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-ivory">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-xs text-stone">
              <tr>
                <th className="px-4 py-3">Order</th>
                <th className="px-4 py-3">Customer</th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Payment</th>
                <th className="px-4 py-3">Total</th>
                <th className="px-4 py-3">Fulfillment</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => {
                const latestPayment = order.payments[order.payments.length - 1];
                return (
                  <tr key={order.id} className="border-b border-line last:border-0">
                    <td className="px-4 py-3">
                      <Link href={`/admin/orders/${order.id}`} className="text-ink underline">
                        {order.orderNumber}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-stone">{order.email}</td>
                    <td className="px-4 py-3 text-stone">
                      {order.createdAt.toISOString().slice(0, 10)}
                    </td>
                    <td className="px-4 py-3 text-stone">{order.status}</td>
                    <td className="px-4 py-3 text-stone">
                      {latestPayment?.status ?? "—"}
                    </td>
                    <td className="px-4 py-3 text-stone">
                      {formatPrice(Number(order.total), order.currency)}
                    </td>
                    <td className="px-4 py-3 text-stone">
                      {order.fulfillment?.status ?? "—"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
