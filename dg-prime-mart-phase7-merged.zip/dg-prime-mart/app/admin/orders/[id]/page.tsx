import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/config";
import { estimateGrossMargin } from "@/lib/margin";
import { SupplierApprovalPanel } from "@/components/admin/SupplierApprovalPanel";
import { isCjConfigured } from "@/lib/cj-dropshipping";

export const metadata: Metadata = { title: "Order Detail" };

export default async function AdminOrderDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: {
      items: { include: { product: { include: { supplier: true } } } },
      payments: true,
      fulfillment: { include: { supplier: true } },
      user: { select: { name: true, email: true } },
      coupon: { select: { code: true } },
    },
  });

  if (!order) notFound();

  const address = order.shippingAddressSnapshot as {
    firstName?: string;
    lastName?: string;
    addressLine1?: string;
    addressLine2?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
    phone?: string;
  } | null;

  // Build a per-item margin estimate where the product has supplier cost
  // data; only meaningful when every item resolves to the same supplier
  // (which is the common case — mixed-supplier orders show a per-item
  // breakdown instead of one combined number).
  const itemMargins = order.items.map((item) => {
    const margin = estimateGrossMargin({
      customerRevenue: Number(item.priceSnapshot) * item.quantity,
      supplierCost: item.product?.supplierCost
        ? Number(item.product.supplierCost)
        : null,
      supplierShippingCost: item.product?.supplierShippingCost
        ? Number(item.product.supplierShippingCost)
        : null,
      quantity: item.quantity,
    });
    return { item, margin, supplier: item.product?.supplier ?? null };
  });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl text-ink">{order.orderNumber}</h1>
        <span className="rounded-full bg-parchment px-3 py-1 text-xs font-medium text-ink">
          {order.status}
        </span>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-line bg-ivory p-5">
          <h2 className="mb-3 font-display text-base text-ink">Customer</h2>
          <p className="text-sm text-ink">{order.user?.name ?? "Guest"}</p>
          <p className="text-sm text-stone">{order.email}</p>
          {address?.phone && <p className="text-sm text-stone">{address.phone}</p>}
        </section>

        <section className="rounded-2xl border border-line bg-ivory p-5">
          <h2 className="mb-3 font-display text-base text-ink">Shipping Address</h2>
          {address ? (
            <p className="text-sm text-stone">
              {address.firstName} {address.lastName}
              <br />
              {address.addressLine1}
              {address.addressLine2 ? `, ${address.addressLine2}` : ""}
              <br />
              {address.city}, {address.state} {address.postalCode}
              <br />
              {address.country}
            </p>
          ) : (
            <p className="text-sm text-stone">No address on file.</p>
          )}
        </section>
      </div>

      <section className="mt-6 rounded-2xl border border-line bg-ivory p-5">
        <h2 className="mb-3 font-display text-base text-ink">Order Items</h2>
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line text-xs text-stone">
            <tr>
              <th className="py-2">Product</th>
              <th className="py-2">SKU</th>
              <th className="py-2">Qty</th>
              <th className="py-2">Unit Price</th>
              <th className="py-2">Line Total</th>
            </tr>
          </thead>
          <tbody>
            {order.items.map((item) => (
              <tr key={item.id} className="border-b border-line last:border-0">
                <td className="py-2 text-ink">{item.nameSnapshot}</td>
                <td className="py-2 text-stone">{item.skuSnapshot}</td>
                <td className="py-2 text-stone">{item.quantity}</td>
                <td className="py-2 text-stone">
                  {formatPrice(Number(item.priceSnapshot), order.currency)}
                </td>
                <td className="py-2 text-stone">
                  {formatPrice(Number(item.priceSnapshot) * item.quantity, order.currency)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="mt-4 flex flex-col gap-1 border-t border-line pt-4 text-sm">
          <div className="flex justify-between text-stone">
            <span>Subtotal</span>
            <span>{formatPrice(Number(order.subtotal), order.currency)}</span>
          </div>
          {Number(order.discount) > 0 && (
            <div className="flex justify-between text-stone">
              <span>Discount {order.coupon ? `(${order.coupon.code})` : ""}</span>
              <span>-{formatPrice(Number(order.discount), order.currency)}</span>
            </div>
          )}
          <div className="flex justify-between text-stone">
            <span>Shipping</span>
            <span>{formatPrice(Number(order.shipping), order.currency)}</span>
          </div>
          <div className="mt-1 flex justify-between font-display text-base text-ink">
            <span>Total</span>
            <span>{formatPrice(Number(order.total), order.currency)}</span>
          </div>
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-line bg-ivory p-5">
        <h2 className="mb-3 font-display text-base text-ink">Payment</h2>
        {order.payments.length === 0 ? (
          <p className="text-sm text-stone">No payment recorded yet.</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-xs text-stone">
              <tr>
                <th className="py-2">Provider</th>
                <th className="py-2">Status</th>
                <th className="py-2">Provider Payment ID</th>
                <th className="py-2">Recorded</th>
              </tr>
            </thead>
            <tbody>
              {order.payments.map((p) => (
                <tr key={p.id} className="border-b border-line last:border-0">
                  <td className="py-2 text-ink">{p.provider}</td>
                  <td className="py-2 text-stone">{p.status}</td>
                  <td className="py-2 text-stone">{p.providerPaymentId ?? "—"}</td>
                  <td className="py-2 text-stone">
                    {p.updatedAt.toISOString().slice(0, 16).replace("T", " ")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      {order.status === "PAID" && (
        <SupplierApprovalPanel
          orderId={order.id}
          orderNumber={order.orderNumber}
          customerEmail={order.email}
          currency={order.currency}
          total={Number(order.total)}
          existingFulfillment={
            order.fulfillment
              ? {
                  id: order.fulfillment.id,
                  status: order.fulfillment.status,
                  approvedAt: order.fulfillment.approvedAt
                    ? order.fulfillment.approvedAt.toISOString()
                    : null,
                  approvedByEmailSnapshot: order.fulfillment.approvedByEmailSnapshot,
                  supplierName: order.fulfillment.supplier?.name ?? null,
                  supplierOrderId: order.fulfillment.supplierOrderId,
                  submittedAt: order.fulfillment.submittedAt
                    ? order.fulfillment.submittedAt.toISOString()
                    : null,
                  submittedByEmailSnapshot: order.fulfillment.submittedByEmailSnapshot,
                  lastSubmissionError: order.fulfillment.lastSubmissionError,
                  trackingNumber: order.fulfillment.trackingNumber,
                  carrier: order.fulfillment.carrier,
                  lastSyncedAt: order.fulfillment.lastSyncedAt
                    ? order.fulfillment.lastSyncedAt.toISOString()
                    : null,
                }
              : null
          }
          cjConfigured={isCjConfigured()}
          items={itemMargins.map(({ item, margin, supplier }) => ({
            id: item.id,
            name: item.nameSnapshot,
            quantity: item.quantity,
            supplierId: supplier?.id ?? null,
            supplierName: supplier?.name ?? null,
            supplierProductId: item.product?.supplierProductId ?? null,
            supplierCost: item.product?.supplierCost
              ? Number(item.product.supplierCost)
              : null,
            supplierShippingCost: item.product?.supplierShippingCost
              ? Number(item.product.supplierShippingCost)
              : null,
            customerRevenue: Number(item.priceSnapshot) * item.quantity,
            estimatedGrossMargin: margin.estimatedGrossMargin,
          }))}
        />
      )}
    </div>
  );
}
