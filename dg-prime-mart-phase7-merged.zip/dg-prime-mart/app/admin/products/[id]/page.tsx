import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { ProductForm } from "@/components/admin/ProductForm";

export const metadata: Metadata = { title: "Edit Product" };

export default async function EditProductPage({
  params,
}: {
  params: { id: string };
}) {
  const [product, categories, suppliers] = await Promise.all([
    prisma.product.findUnique({
      where: { id: params.id },
      include: { images: { orderBy: { sortOrder: "asc" } }, variants: true },
    }),
    prisma.category.findMany({ orderBy: { sortOrder: "asc" } }),
    prisma.supplier.findMany({ orderBy: { name: "asc" } }),
  ]);

  if (!product) notFound();

  return (
    <div>
      <h1 className="font-display text-2xl text-ink">{product.name}</h1>
      <div className="mt-6 max-w-3xl">
        <ProductForm
          categories={categories}
          suppliers={suppliers}
          initial={{
            id: product.id,
            name: product.name,
            slug: product.slug,
            description: product.description,
            shortDescription: product.shortDescription,
            price: String(product.price),
            compareAtPrice: product.compareAtPrice ? String(product.compareAtPrice) : "",
            currency: product.currency,
            sku: product.sku,
            inventory: String(product.inventory),
            categoryId: product.categoryId,
            supplierId: product.supplierId ?? "",
            supplierProductId: product.supplierProductId ?? "",
            supplierVariantId: product.supplierVariantId ?? "",
            supplierCost: product.supplierCost ? String(product.supplierCost) : "",
            supplierShippingCost: product.supplierShippingCost
              ? String(product.supplierShippingCost)
              : "",
            isActive: product.isActive,
            isFeatured: product.isFeatured,
            isNew: product.isNew,
            seoTitle: product.seoTitle ?? "",
            seoDescription: product.seoDescription ?? "",
            images: product.images.map((img) => ({ url: img.url, alt: img.alt })),
            variants: product.variants.map((v) => ({
              name: v.name,
              sku: v.sku,
              price: String(v.price),
              inventory: String(v.inventory),
            })),
          }}
        />
      </div>
    </div>
  );
}
