import type { Metadata } from "next";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { categories } from "@/lib/categories";
import { formatPrice } from "@/lib/config";
import type { Prisma } from "@prisma/client";

export const metadata: Metadata = { title: "Products" };

export default async function AdminProductsPage({
  searchParams,
}: {
  searchParams: { q?: string; category?: string };
}) {
  const q = searchParams.q?.trim() ?? "";
  const category = searchParams.category ?? "all";

  const where: Prisma.ProductWhereInput = {
    ...(q
      ? {
          OR: [
            { name: { contains: q, mode: "insensitive" } },
            { sku: { contains: q, mode: "insensitive" } },
          ],
        }
      : {}),
    ...(category !== "all" ? { category: { slug: category } } : {}),
  };

  const products = await prisma.product.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { category: true },
    take: 200,
  });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl text-ink">Products</h1>
        <Link
          href="/admin/products/new"
          className="rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-ivory hover:bg-bottle"
        >
          New Product
        </Link>
      </div>

      <div className="mt-3 rounded-xl border border-brass/40 bg-parchment px-4 py-2 text-xs text-stone">
        This list is the real database catalog only. Storefront demo
        products (from <code>lib/demo-data.ts</code>) never appear here and
        are never converted into real rows automatically.
      </div>

      <form className="mt-4 flex flex-wrap items-center gap-3">
        <input
          type="text"
          name="q"
          defaultValue={q}
          placeholder="Search name or SKU"
          className="rounded-full border border-line px-4 py-2 text-sm text-ink outline-none focus:border-brass"
        />
        <select
          name="category"
          defaultValue={category}
          className="rounded-full border border-line px-4 py-2 text-sm text-ink"
        >
          <option value="all">All categories</option>
          {categories.map((c) => (
            <option key={c.slug} value={c.slug}>
              {c.name}
            </option>
          ))}
        </select>
        <button
          type="submit"
          className="rounded-full bg-ink px-5 py-2 text-sm font-medium text-ivory hover:bg-bottle"
        >
          Apply
        </button>
      </form>

      {products.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-line px-6 py-16 text-center text-sm text-stone">
          No products yet.
        </div>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-ivory">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-xs text-stone">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">SKU</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Price</th>
                <th className="px-4 py-3">Inventory</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <tr key={product.id} className="border-b border-line last:border-0">
                  <td className="px-4 py-3">
                    <Link href={`/admin/products/${product.id}`} className="text-ink underline">
                      {product.name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-stone">{product.sku}</td>
                  <td className="px-4 py-3 text-stone">{product.category.name}</td>
                  <td className="px-4 py-3 text-stone">
                    {formatPrice(Number(product.price), product.currency)}
                  </td>
                  <td className="px-4 py-3 text-stone">{product.inventory}</td>
                  <td className="px-4 py-3 text-stone">
                    {product.isActive ? "Active" : "Inactive"}
                    {product.isFeatured ? " · Featured" : ""}
                    {product.isNew ? " · New" : ""}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
