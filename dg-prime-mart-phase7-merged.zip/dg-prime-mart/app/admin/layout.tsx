import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { AdminShell } from "@/components/admin/AdminShell";

/**
 * Authoritative admin gate for every /admin/* page. middleware.ts already
 * redirects non-admins at the edge; this is the second, page-level check
 * that actually runs before any admin data is fetched — defense in depth,
 * not decoration. Every admin API route additionally calls
 * requireAdmin() itself (see lib/admin-auth.ts), since a layout check
 * alone would not protect direct API calls.
 */
export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();
  if (!session?.user || session.user.role !== "ADMIN") {
    redirect("/login");
  }

  return <AdminShell adminEmail={session.user.email ?? ""}>{children}</AdminShell>;
}
