import type { Metadata } from "next";
import Link from "next/link";
import { getDashboardMetrics } from "@/lib/admin-metrics";
import { formatPrice } from "@/lib/config";

export const metadata: Metadata = { title: "Admin Dashboard" };

export default async function AdminDashboardPage() {
  const metrics = await getDashboardMetrics();

  const cards = [
    { label: "Total Orders", value: metrics.totalOrders },
    { label: "Paid Orders", value: metrics.paidOrders },
    { label: "Awaiting Supplier Approval", value: metrics.awaitingApproval, href: "/admin/fulfillment" },
    { label: "Revenue", value: formatPrice(metrics.revenue) },
    { label: "Customers", value: metrics.customers },
    { label: "Products", value: metrics.products },
    {
      label: "Low Stock Products",
      value: metrics.lowStockProducts,
      href: "/admin/inventory",
      hint: `≤ ${metrics.lowStockThreshold} units`,
    },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl text-ink">Dashboard</h1>
      <p className="mt-1 text-sm text-stone">
        Live figures from the database — nothing here is estimated.
      </p>

      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {cards.map((card) =>
          card.href ? (
            <Link
              key={card.label}
              href={card.href}
              className="rounded-2xl border border-line bg-ivory p-5 hover:border-ink"
            >
              <p className="text-xs text-stone">{card.label}</p>
              <p className="mt-1 font-display text-2xl text-ink">{card.value}</p>
              {card.hint && <p className="mt-1 text-xs text-stone">{card.hint}</p>}
            </Link>
          ) : (
            <div key={card.label} className="rounded-2xl border border-line bg-ivory p-5">
              <p className="text-xs text-stone">{card.label}</p>
              <p className="mt-1 font-display text-2xl text-ink">{card.value}</p>
              {card.hint && <p className="mt-1 text-xs text-stone">{card.hint}</p>}
            </div>
          )
        )}
      </div>

      <div className="mt-10">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-lg text-ink">Recent Orders</h2>
          <Link href="/admin/orders" className="text-sm text-stone underline hover:text-ink">
            View all
          </Link>
        </div>

        {metrics.recentOrders.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-line px-6 py-12 text-center text-sm text-stone">
            No orders yet.
          </div>
        ) : (
          <div className="overflow-x-auto rounded-2xl border border-line bg-ivory">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-line text-xs text-stone">
                <tr>
                  <th className="px-4 py-3">Order</th>
                  <th className="px-4 py-3">Email</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Total</th>
                </tr>
              </thead>
              <tbody>
                {metrics.recentOrders.map((order) => (
                  <tr key={order.id} className="border-b border-line last:border-0">
                    <td className="px-4 py-3">
                      <Link href={`/admin/orders/${order.id}`} className="text-ink underline">
                        {order.orderNumber}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-stone">{order.email}</td>
                    <td className="px-4 py-3 text-stone">{order.status}</td>
                    <td className="px-4 py-3 text-stone">
                      {formatPrice(Number(order.total), order.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
