import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { formatPrice } from "@/lib/config";

export const metadata: Metadata = { title: "Customers" };

export default async function AdminCustomersPage() {
  // Never select passwordHash — admin must not be able to see it either.
  const customers = await prisma.user.findMany({
    where: { role: "CUSTOMER" },
    select: {
      id: true,
      name: true,
      email: true,
      createdAt: true,
      orders: {
        select: { total: true, status: true },
      },
    },
    orderBy: { createdAt: "desc" },
    take: 200,
  });

  return (
    <div>
      <h1 className="font-display text-2xl text-ink">Customers</h1>

      {customers.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-line px-6 py-16 text-center text-sm text-stone">
          No customers yet.
        </div>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-2xl border border-line bg-ivory">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-xs text-stone">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">Joined</th>
                <th className="px-4 py-3">Orders</th>
                <th className="px-4 py-3">Total Spent</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((customer) => {
                const paidOrders = customer.orders.filter(
                  (o) => o.status !== "PENDING_PAYMENT" && o.status !== "CANCELLED"
                );
                const totalSpent = paidOrders.reduce((sum, o) => sum + Number(o.total), 0);
                return (
                  <tr key={customer.id} className="border-b border-line last:border-0">
                    <td className="px-4 py-3 text-ink">{customer.name ?? "—"}</td>
                    <td className="px-4 py-3 text-stone">{customer.email}</td>
                    <td className="px-4 py-3 text-stone">
                      {customer.createdAt.toISOString().slice(0, 10)}
                    </td>
                    <td className="px-4 py-3 text-stone">{customer.orders.length}</td>
                    <td className="px-4 py-3 text-stone">{formatPrice(totalSpent)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
