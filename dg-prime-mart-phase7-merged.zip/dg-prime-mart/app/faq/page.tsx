import type { Metadata } from "next";
import { PageHeader } from "@/components/PageHeader";

export const metadata: Metadata = { title: "FAQ" };

const faqs = [
  {
    q: "What payment methods do you accept?",
    a: "PayPal is our primary payment method. Additional options may be added later.",
  },
  {
    q: "How long does shipping take?",
    a: "Estimated delivery windows are shown on each product page once the catalog and supplier integration are live.",
  },
  {
    q: "How do I track my order?",
    a: "Once an order ships, tracking details are available from your account's order history.",
  },
];

export default function FaqPage() {
  return (
    <>
      <PageHeader title="Frequently Asked Questions" />
      <div className="mx-auto max-w-2xl divide-y divide-line px-4 py-10 sm:px-6 lg:px-8">
        {faqs.map((item) => (
          <details key={item.q} className="group py-4">
            <summary className="cursor-pointer list-none text-base text-ink marker:content-none">
              <span className="flex items-center justify-between gap-4">
                {item.q}
                <span className="text-stone transition-transform group-open:rotate-45">
                  +
                </span>
              </span>
            </summary>
            <p className="mt-2 text-sm text-stone">{item.a}</p>
          </details>
        ))}
      </div>
    </>
  );
}
