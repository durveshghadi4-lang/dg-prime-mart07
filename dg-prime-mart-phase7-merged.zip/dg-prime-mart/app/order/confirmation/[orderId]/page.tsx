import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { OrderDetailView } from "@/components/OrderDetailView";

export const metadata: Metadata = { title: "Order Confirmation" };

interface PageProps {
  params: { orderId: string };
  searchParams: { guestToken?: string };
}

export default async function OrderConfirmationPage({
  params,
  searchParams,
}: PageProps) {
  const session = await auth();

  const order = await prisma.order.findUnique({
    where: { id: params.orderId },
    include: { items: true, fulfillment: true },
  });

  if (!order) notFound();

  // Authorization: either this is the logged-in owner, or the exact
  // unguessable guest token was supplied. Anyone else — including a
  // logged-in user who isn't the owner — gets a 404, not order details.
  const isOwner = session?.user?.id && session.user.id === order.userId;
  const hasGuestToken =
    !order.userId &&
    order.guestToken &&
    searchParams.guestToken === order.guestToken;

  if (!isOwner && !hasGuestToken) {
    notFound();
  }

  return (
    <OrderDetailView
      order={{
        orderNumber: order.orderNumber,
        status: order.status,
        email: order.email,
        subtotal: Number(order.subtotal),
        discount: Number(order.discount),
        shipping: Number(order.shipping),
        total: Number(order.total),
        currency: order.currency,
        createdAt: order.createdAt,
        shippingAddressSnapshot: order.shippingAddressSnapshot,
        fulfillment: order.fulfillment
          ? {
              status: order.fulfillment.status,
              trackingNumber: order.fulfillment.trackingNumber,
              carrier: order.fulfillment.carrier,
            }
          : null,
        items: order.items.map((i) => ({
          id: i.id,
          nameSnapshot: i.nameSnapshot,
          quantity: i.quantity,
          priceSnapshot: Number(i.priceSnapshot),
        })),
      }}
      showConfirmationChrome
    />
  );
}
