"use client";

import { useMemo, useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { ProductGrid } from "@/components/ProductGrid";
import { getAllDemoProducts } from "@/lib/demo-data";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const allProducts = getAllDemoProducts();

  // TODO(backend): replace with a real search endpoint (Postgres full-text
  // search or a hosted search provider) once the catalog exists.
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return allProducts.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.shortDescription.toLowerCase().includes(q)
    );
  }, [allProducts, query]);

  return (
    <>
      <PageHeader title="Search" />
      <div className="mx-auto max-w-container px-4 py-10 sm:px-6 lg:px-8">
        <label htmlFor="search-input" className="sr-only">
          Search products
        </label>
        <input
          id="search-input"
          type="search"
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search products…"
          className="w-full max-w-lg rounded-full border border-line px-5 py-3 text-sm text-ink outline-none focus:border-brass"
        />

        <div className="mt-8">
          {query.trim() === "" ? (
            <p className="text-sm text-stone">Start typing to search the catalog.</p>
          ) : (
            <ProductGrid
              products={results}
              emptyTitle="No matches"
              emptyMessage={`Nothing found for "${query}". Try a different term.`}
            />
          )}
        </div>
      </div>
    </>
  );
}
