"use client";

import { useCart } from "@/components/CartProvider";
import { PageHeader } from "@/components/PageHeader";
import { ProductGrid } from "@/components/ProductGrid";
import { getAllDemoProducts } from "@/lib/demo-data";

export default function WishlistPage() {
  const { wishlist } = useCart();
  // TODO(backend): replace demo lookup with a real query for the
  // authenticated user's wishlist_items once accounts exist.
  const products = getAllDemoProducts().filter((p) => wishlist.includes(p.id));

  return (
    <>
      <PageHeader title="Your Wishlist" />
      <div className="mx-auto max-w-container px-4 py-10 sm:px-6 lg:px-8">
        <ProductGrid
          products={products}
          emptyTitle="Your wishlist is empty"
          emptyMessage="Tap the heart on any product to save it here."
        />
      </div>
    </>
  );
}
