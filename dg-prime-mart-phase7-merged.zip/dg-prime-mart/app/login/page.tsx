"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { signIn } from "next-auth/react";
import { PageHeader } from "@/components/PageHeader";

export default function LoginPage() {
  return (
    <>
      <PageHeader title="Login" />
      <div className="mx-auto max-w-sm px-4 py-10 sm:px-6 lg:px-8">
        <Suspense fallback={null}>
          <LoginForm />
        </Suspense>
        <p className="mt-4 text-sm text-stone">
          New here?{" "}
          <Link href="/register" className="text-ink underline">
            Create an account
          </Link>
        </p>
      </div>
    </>
  );
}

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const callbackUrl = searchParams.get("callbackUrl") ?? "/account";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState<"idle" | "submitting" | "error">("idle");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("submitting");
    setError("");

    const result = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    if (result?.error) {
      setStatus("error");
      setError("Incorrect email or password.");
      return;
    }

    router.push(callbackUrl);
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <Field
        label="Email"
        id="email"
        type="email"
        value={email}
        onChange={setEmail}
        required
      />
      <Field
        label="Password"
        id="password"
        type="password"
        value={password}
        onChange={setPassword}
        required
      />
      {status === "error" && (
        <p role="alert" className="text-sm text-rose-dark">
          {error}
        </p>
      )}
      <button
        type="submit"
        disabled={status === "submitting"}
        className="mt-2 inline-flex items-center justify-center rounded-full bg-ink px-6 py-3 text-sm font-medium text-ivory transition-colors hover:bg-bottle disabled:cursor-not-allowed disabled:opacity-70"
      >
        {status === "submitting" ? "Logging in…" : "Log In"}
      </button>
    </form>
  );
}

function Field({
  label,
  id,
  type,
  value,
  onChange,
  required,
}: {
  label: string;
  id: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm text-ink">
        {label}
      </label>
      <input
        id={id}
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-full border border-line px-4 py-2.5 text-sm text-ink outline-none focus:border-brass"
      />
    </div>
  );
}
