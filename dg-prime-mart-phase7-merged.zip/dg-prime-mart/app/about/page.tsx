import type { Metadata } from "next";
import { PageHeader } from "@/components/PageHeader";

export const metadata: Metadata = { title: "About" };

export default function AboutPage() {
  return (
    <>
      <PageHeader title="About DG PRIME MART" />
      <div className="mx-auto max-w-2xl px-4 py-10 text-sm leading-relaxed text-ink/80 sm:px-6 lg:px-8">
        <p>
          DG PRIME MART is an independent store curating beauty, jewellery,
          home, kitchen, lifestyle and kids essentials for women who want
          everyday elegance without the excess. Placeholder copy — replace
          with the real brand story.
        </p>
      </div>
    </>
  );
}
