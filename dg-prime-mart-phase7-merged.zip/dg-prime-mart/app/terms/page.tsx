import type { Metadata } from "next";
import { PageHeader } from "@/components/PageHeader";

export const metadata: Metadata = { title: "Terms & Conditions" };

export default function TermsPage() {
  return (
    <>
      <PageHeader title="Terms & Conditions" />
      <div className="mx-auto max-w-2xl px-4 py-10 text-sm leading-relaxed text-ink/80 sm:px-6 lg:px-8">
        <p>
          Placeholder terms text. Replace with real terms of sale, acceptable
          use, and liability language reviewed by counsel before launch.
        </p>
      </div>
    </>
  );
}
