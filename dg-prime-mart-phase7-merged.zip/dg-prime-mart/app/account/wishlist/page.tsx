import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { getWishlistForUser } from "@/lib/cart-server";
import { PageHeader } from "@/components/PageHeader";

export const metadata: Metadata = { title: "Wishlist" };

export default async function AccountWishlistPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const wishlist = await getWishlistForUser(session.user.id);
  const items = wishlist?.items ?? [];

  return (
    <>
      <PageHeader
        title="Wishlist"
        description="Saved items tied to your account. Items saved from the current demo catalog are only visible on this device — see /wishlist."
      />
      <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
        {items.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-line px-6 py-16 text-center">
            <p className="font-display text-xl text-ink">
              No account-linked wishlist items yet
            </p>
            <p className="mx-auto mt-2 max-w-sm text-sm text-stone">
              This list will fill in once real products exist in the catalog.
              In the meantime, your saved items from the current demo catalog
              are shown on the{" "}
              <Link href="/wishlist" className="underline">
                device wishlist page
              </Link>
              .
            </p>
          </div>
        ) : (
          <ul className="flex flex-col gap-3">
            {items.map((item) => (
              <li key={item.id} className="rounded-2xl border border-line p-4 text-sm text-ink">
                {item.product.name}
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}
