import type { Metadata } from "next";
import { notFound, redirect } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/PageHeader";
import { OrderDetailView } from "@/components/OrderDetailView";

export const metadata: Metadata = { title: "Order Details" };

export default async function AccountOrderDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: { items: true, fulfillment: true },
  });

  // A missing order and someone else's order are both a 404 — this route
  // never confirms an order id belongs to another customer.
  if (!order || order.userId !== session.user.id) {
    notFound();
  }

  return (
    <>
      <PageHeader title={`Order ${order.orderNumber}`} />
      <OrderDetailView
        order={{
          orderNumber: order.orderNumber,
          status: order.status,
          email: order.email,
          subtotal: Number(order.subtotal),
          discount: Number(order.discount),
          shipping: Number(order.shipping),
          total: Number(order.total),
          currency: order.currency,
          createdAt: order.createdAt,
          shippingAddressSnapshot: order.shippingAddressSnapshot,
          fulfillment: order.fulfillment
            ? {
                status: order.fulfillment.status,
                trackingNumber: order.fulfillment.trackingNumber,
                carrier: order.fulfillment.carrier,
              }
            : null,
          items: order.items.map((i) => ({
            id: i.id,
            nameSnapshot: i.nameSnapshot,
            quantity: i.quantity,
            priceSnapshot: Number(i.priceSnapshot),
          })),
        }}
      />
    </>
  );
}
