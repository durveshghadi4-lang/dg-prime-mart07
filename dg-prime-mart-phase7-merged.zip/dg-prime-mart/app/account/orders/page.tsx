import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/PageHeader";
import { formatPrice } from "@/lib/config";

export const metadata: Metadata = { title: "Order History" };

export default async function OrderHistoryPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const orders = await prisma.order.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: "desc" },
    include: { items: true },
  });

  return (
    <>
      <PageHeader title="Order History" />
      <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
        {orders.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-line px-6 py-16 text-center">
            <p className="font-display text-xl text-ink">No orders yet</p>
            <p className="mt-2 text-sm text-stone">
              Your order history and tracking will appear here once you place an order.
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {orders.map((order) => (
              <Link
                key={order.id}
                href={`/account/orders/${order.id}`}
                className="block rounded-2xl border border-line p-5 hover:border-ink"
              >
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium text-ink">{order.orderNumber}</span>
                  <span className="text-stone">{order.status}</span>
                </div>
                <p className="mt-1 text-sm text-stone">
                  {order.items.length} item(s) · {formatPrice(Number(order.total), order.currency)}
                </p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
