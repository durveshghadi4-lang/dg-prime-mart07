import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/PageHeader";
import { AddressManager } from "@/components/AddressManager";

export const metadata: Metadata = { title: "Addresses" };

export default async function AddressesPage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  // Scoped to session.user.id — a user can only ever see their own addresses.
  const addresses = await prisma.address.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: "desc" },
  });

  return (
    <>
      <PageHeader title="Addresses" />
      <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
        <AddressManager initialAddresses={addresses} />
      </div>
    </>
  );
}
