import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { PageHeader } from "@/components/PageHeader";
import { LogoutButton } from "@/components/LogoutButton";

export const metadata: Metadata = { title: "My Account" };

const links = [
  { href: "/account/profile", label: "Profile" },
  { href: "/account/addresses", label: "Addresses" },
  { href: "/account/orders", label: "Order history" },
  { href: "/account/wishlist", label: "Wishlist" },
];

export default async function AccountPage() {
  // Defense in depth — middleware already enforces this, but a page should
  // never assume it was reached only via the middleware path.
  const session = await auth();
  if (!session?.user) redirect("/login");

  return (
    <>
      <PageHeader
        title="My Account"
        description={`Signed in as ${session.user.email}`}
      />
      <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-2">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-2xl border border-line px-5 py-4 text-sm text-ink hover:border-ink"
            >
              {link.label}
            </Link>
          ))}
        </div>
        <div className="mt-8">
          <LogoutButton />
        </div>
      </div>
    </>
  );
}
