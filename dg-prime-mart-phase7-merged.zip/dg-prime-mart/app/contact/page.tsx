"use client";

import { useState } from "react";
import { PageHeader } from "@/components/PageHeader";

export default function ContactPage() {
  const [status, setStatus] = useState<"idle" | "submitting" | "success">(
    "idle"
  );

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("submitting");
    // TODO(backend): send to a real endpoint (email provider or a
    // `contact_messages` table) once one is chosen.
    await new Promise((resolve) => setTimeout(resolve, 500));
    setStatus("success");
  }

  return (
    <>
      <PageHeader title="Contact Us" description="We usually reply within one business day." />
      <div className="mx-auto max-w-lg px-4 py-10 sm:px-6 lg:px-8">
        {status === "success" ? (
          <p className="text-sm text-ink">
            Thanks — your message has been received.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <Field label="Name" id="name" type="text" required />
            <Field label="Email" id="email" type="email" required />
            <div className="flex flex-col gap-1.5">
              <label htmlFor="message" className="text-sm text-ink">
                Message
              </label>
              <textarea
                id="message"
                required
                rows={5}
                className="rounded-2xl border border-line px-4 py-3 text-sm text-ink outline-none focus:border-brass"
              />
            </div>
            <button
              type="submit"
              disabled={status === "submitting"}
              className="mt-2 inline-flex items-center justify-center rounded-full bg-ink px-6 py-3 text-sm font-medium text-ivory hover:bg-bottle"
            >
              {status === "submitting" ? "Sending…" : "Send Message"}
            </button>
          </form>
        )}
      </div>
    </>
  );
}

function Field({
  label,
  id,
  type,
  required,
}: {
  label: string;
  id: string;
  type: string;
  required?: boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm text-ink">
        {label}
      </label>
      <input
        id={id}
        type={type}
        required={required}
        className="rounded-full border border-line px-4 py-2.5 text-sm text-ink outline-none focus:border-brass"
      />
    </div>
  );
}
