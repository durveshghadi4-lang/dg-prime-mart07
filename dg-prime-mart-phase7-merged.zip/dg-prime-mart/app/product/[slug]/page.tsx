import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ProductImage } from "@/components/ProductImage";
import { PriceDisplay } from "@/components/PriceDisplay";
import { ProductBadge, DemoDataBadge } from "@/components/ProductBadge";
import { AddToCartButton } from "@/components/AddToCartButton";
import { WishlistButton } from "@/components/WishlistButton";
import { getAllDemoProducts, getDemoProductBySlug } from "@/lib/demo-data";
import { shippingConfig, formatPrice } from "@/lib/config";

interface ProductPageProps {
  params: { slug: string };
}

export function generateStaticParams() {
  return getAllDemoProducts().map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: ProductPageProps): Metadata {
  const product = getDemoProductBySlug(params.slug);
  if (!product) return { title: "Product" };
  return {
    title: product.name,
    description: product.shortDescription,
    openGraph: {
      title: product.name,
      description: product.shortDescription,
    },
  };
}

export default function ProductPage({ params }: ProductPageProps) {
  // TODO(backend): replace with a real product lookup by slug.
  const product = getDemoProductBySlug(params.slug);
  if (!product) notFound();

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    description: product.description,
    offers: {
      "@type": "Offer",
      price: product.price,
      priceCurrency: product.currency,
      availability: product.inStock
        ? "https://schema.org/InStock"
        : "https://schema.org/OutOfStock",
    },
  };

  return (
    <div className="mx-auto max-w-container px-4 py-10 sm:px-6 lg:px-8">
      {/* eslint-disable-next-line react/no-danger */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />
      <div className="grid gap-10 lg:grid-cols-2">
        <div className="relative">
          <ProductImage
            src={product.images[0]}
            alt={product.name}
            categorySlug={product.categorySlug}
            seed={product.slug}
            className="aspect-square w-full rounded-3xl"
          />
          <div className="absolute left-4 top-4 flex flex-wrap gap-1.5">
            {product.isDemoData && <DemoDataBadge />}
            {product.badges.map((badge) => (
              <ProductBadge key={badge} kind={badge} />
            ))}
          </div>
        </div>

        <div className="max-w-md">
          <h1 className="font-display text-3xl text-ink">{product.name}</h1>
          <p className="mt-2 text-sm text-stone">{product.shortDescription}</p>

          <div className="mt-6">
            <PriceDisplay
              price={product.price}
              compareAtPrice={product.compareAtPrice}
              currency={product.currency}
              size="lg"
            />
          </div>

          <p className="mt-2 text-xs text-stone">
            Free shipping on orders above{" "}
            {formatPrice(
              shippingConfig.freeShippingThreshold,
              shippingConfig.freeShippingCurrency
            )}
            .
          </p>

          <div className="mt-6 flex items-center gap-3">
            <AddToCartButton product={product} />
            <WishlistButton productId={product.id} productName={product.name} />
          </div>

          <p className="mt-8 text-sm leading-relaxed text-ink/80">
            {product.description}
          </p>
        </div>
      </div>
    </div>
  );
}
