import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-container flex-col items-center gap-4 px-4 py-24 text-center sm:px-6 lg:px-8">
      <p className="font-display text-3xl text-ink">Page not found</p>
      <p className="max-w-sm text-sm text-stone">
        The page you're looking for doesn't exist or has moved.
      </p>
      <Link
        href="/"
        className="mt-2 inline-flex items-center justify-center rounded-full bg-ink px-6 py-3 text-sm font-medium text-ivory hover:bg-bottle"
      >
        Back to Home
      </Link>
    </div>
  );
}
