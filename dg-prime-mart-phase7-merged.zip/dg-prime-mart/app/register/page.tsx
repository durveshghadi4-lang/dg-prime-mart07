"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { signIn } from "next-auth/react";
import { PageHeader } from "@/components/PageHeader";

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [status, setStatus] = useState<"idle" | "submitting" | "error">("idle");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("submitting");
    setError("");

    const response = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    });

    const data = await response.json();

    if (!response.ok) {
      setStatus("error");
      setError(data.error ?? "Something went wrong. Please try again.");
      return;
    }

    const signInResult = await signIn("credentials", {
      email,
      password,
      redirect: false,
    });

    if (signInResult?.error) {
      // Account was created but auto-login failed for some reason — send
      // them to log in manually rather than leaving the button spinning.
      router.push("/login");
      return;
    }

    router.push("/account");
    router.refresh();
  }

  return (
    <>
      <PageHeader title="Create Account" />
      <div className="mx-auto max-w-sm px-4 py-10 sm:px-6 lg:px-8">
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <Field label="Full name" id="name" type="text" value={name} onChange={setName} required />
          <Field label="Email" id="email" type="email" value={email} onChange={setEmail} required />
          <Field
            label="Password"
            id="password"
            type="password"
            value={password}
            onChange={setPassword}
            required
          />
          <p className="text-xs text-stone">
            At least 8 characters, including a number.
          </p>
          {status === "error" && (
            <p role="alert" className="text-sm text-rose-dark">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={status === "submitting"}
            className="mt-2 inline-flex items-center justify-center rounded-full bg-ink px-6 py-3 text-sm font-medium text-ivory transition-colors hover:bg-bottle disabled:cursor-not-allowed disabled:opacity-70"
          >
            {status === "submitting" ? "Creating account…" : "Create Account"}
          </button>
        </form>
        <p className="mt-4 text-sm text-stone">
          Already have an account?{" "}
          <Link href="/login" className="text-ink underline">
            Log in
          </Link>
        </p>
      </div>
    </>
  );
}

function Field({
  label,
  id,
  type,
  value,
  onChange,
  required,
}: {
  label: string;
  id: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm text-ink">
        {label}
      </label>
      <input
        id={id}
        type={type}
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-full border border-line px-4 py-2.5 text-sm text-ink outline-none focus:border-brass"
      />
    </div>
  );
}
