import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PageHeader } from "@/components/PageHeader";
import { ProductGrid } from "@/components/ProductGrid";
import { categories, getCategoryBySlug } from "@/lib/categories";
import { getDemoProductsByCategory } from "@/lib/demo-data";

interface CategoryPageProps {
  params: { slug: string };
}

export function generateStaticParams() {
  return categories.map((c) => ({ slug: c.slug }));
}

export function generateMetadata({ params }: CategoryPageProps): Metadata {
  const category = getCategoryBySlug(params.slug);
  return { title: category?.name ?? "Category" };
}

export default function CategoryPage({ params }: CategoryPageProps) {
  const category = getCategoryBySlug(params.slug);
  if (!category) notFound();

  // TODO(backend): replace with a real query scoped to this category.
  const products = getDemoProductsByCategory(category.slug);

  return (
    <>
      <PageHeader title={category.name} description={category.description} />
      <div className="mx-auto max-w-container px-4 py-10 sm:px-6 lg:px-8">
        <ProductGrid
          products={products}
          emptyTitle={`No products in ${category.name} yet`}
          emptyMessage="We're sourcing products for this category. Check back soon."
        />
      </div>
    </>
  );
}
