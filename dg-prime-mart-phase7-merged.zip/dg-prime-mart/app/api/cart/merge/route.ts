import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/auth";
import { mergeCartForUser } from "@/lib/cart-server";

const mergeSchema = z.object({
  lines: z.array(
    z.object({
      productId: z.string().min(1),
      quantity: z.number().int().min(1).max(99),
    })
  ),
});

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const body = await request.json().catch(() => null);
  const parsed = mergeSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const result = await mergeCartForUser(session.user.id, parsed.data.lines);

  // `skipped` is expected and not an error while the catalog is demo-data
  // only — every current product id will be skipped until real products
  // exist. The client keeps skipped lines in local state regardless.
  return NextResponse.json(result);
}
