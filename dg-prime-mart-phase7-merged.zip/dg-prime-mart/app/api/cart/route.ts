import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { getCartForUser } from "@/lib/cart-server";

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const cart = await getCartForUser(session.user.id);
  return NextResponse.json({ cart });
}
