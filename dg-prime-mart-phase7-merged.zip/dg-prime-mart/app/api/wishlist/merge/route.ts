import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/auth";
import { mergeWishlistForUser } from "@/lib/cart-server";

const mergeSchema = z.object({
  productIds: z.array(z.string().min(1)),
});

export async function POST(request: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const body = await request.json().catch(() => null);
  const parsed = mergeSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 });
  }

  const result = await mergeWishlistForUser(session.user.id, parsed.data.productIds);
  return NextResponse.json(result);
}
