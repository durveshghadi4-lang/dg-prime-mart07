import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { getWishlistForUser } from "@/lib/cart-server";

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const wishlist = await getWishlistForUser(session.user.id);
  return NextResponse.json({ wishlist });
}
