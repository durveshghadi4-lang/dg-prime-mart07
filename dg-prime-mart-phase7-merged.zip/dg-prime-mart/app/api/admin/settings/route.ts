import { NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin, UnauthorizedError, ForbiddenError } from "@/lib/admin-auth";
import { writeAuditLog } from "@/lib/audit";
import { getAllSettings, updateSetting, SETTINGS_KEYS } from "@/lib/settings";

const validKeys = Object.values(SETTINGS_KEYS) as [string, ...string[]];

const updateSchema = z.object({
  key: z.enum(validKeys),
  value: z.string(),
});

export async function GET() {
  try {
    await requireAdmin();
  } catch (err) {
    if (err instanceof UnauthorizedError)
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    if (err instanceof ForbiddenError)
      return NextResponse.json({ error: "Admin access required." }, { status: 403 });
    throw err;
  }

  const settings = await getAllSettings();
  return NextResponse.json({ settings });
}

export async function PATCH(request: Request) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof UnauthorizedError)
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    if (err instanceof ForbiddenError)
      return NextResponse.json({ error: "Admin access required." }, { status: 403 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid setting." }, { status: 400 });
  }

  await updateSetting(parsed.data.key as never, parsed.data.value);

  await writeAuditLog({
    adminId: admin.id,
    action: "settings.update",
    entityType: "Setting",
    entityId: parsed.data.key,
    metadata: { value: parsed.data.value },
  });

  return NextResponse.json({ success: true });
}
