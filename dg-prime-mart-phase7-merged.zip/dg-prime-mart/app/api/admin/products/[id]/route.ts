import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, UnauthorizedError, ForbiddenError } from "@/lib/admin-auth";
import { writeAuditLog } from "@/lib/audit";
import { productSchema } from "@/lib/admin-validation";

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof UnauthorizedError)
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    if (err instanceof ForbiddenError)
      return NextResponse.json({ error: "Admin access required." }, { status: 403 });
    throw err;
  }

  const existing = await prisma.product.findUnique({ where: { id: params.id } });
  if (!existing) {
    return NextResponse.json({ error: "Product not found." }, { status: 404 });
  }

  const body = await request.json().catch(() => null);
  const parsed = productSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Invalid product data." },
      { status: 400 }
    );
  }
  const data = parsed.data;

  if (data.slug !== existing.slug) {
    const slugTaken = await prisma.product.findUnique({ where: { slug: data.slug } });
    if (slugTaken) {
      return NextResponse.json({ error: "A product with this slug already exists." }, { status: 400 });
    }
  }
  if (data.sku !== existing.sku) {
    const skuTaken = await prisma.product.findUnique({ where: { sku: data.sku } });
    if (skuTaken) {
      return NextResponse.json({ error: "A product with this SKU already exists." }, { status: 400 });
    }
  }

  await prisma.$transaction(async (tx) => {
    await tx.product.update({
      where: { id: params.id },
      data: {
        name: data.name,
        slug: data.slug,
        description: data.description,
        shortDescription: data.shortDescription,
        price: data.price,
        compareAtPrice: data.compareAtPrice ?? null,
        currency: data.currency,
        sku: data.sku,
        inventory: data.inventory,
        categoryId: data.categoryId,
        supplierId: data.supplierId ?? null,
        supplierProductId: data.supplierProductId || null,
        supplierVariantId: data.supplierVariantId || null,
        supplierCost: data.supplierCost ?? null,
        supplierShippingCost: data.supplierShippingCost ?? null,
        isActive: data.isActive,
        isFeatured: data.isFeatured,
        isNew: data.isNew,
        seoTitle: data.seoTitle || null,
        seoDescription: data.seoDescription || null,
      },
    });

    // Simplest correct approach for a small admin form: replace the full
    // image/variant sets rather than diffing. Fine at this scale; a
    // higher-traffic admin UI would diff instead to preserve ids.
    await tx.productImage.deleteMany({ where: { productId: params.id } });
    if (data.images.length > 0) {
      await tx.productImage.createMany({
        data: data.images.map((img, i) => ({
          productId: params.id,
          url: img.url,
          alt: img.alt,
          sortOrder: i,
        })),
      });
    }

    // Variants: only replace if the SKU set actually changed, since
    // variants carry their own cart/order references (deleting a variant
    // referenced by an existing CartItem/OrderItem would violate the FK).
    // Simplification: block deleting variants that are in use, add new
    // ones, update matching-SKU ones.
    const existingVariants = await tx.productVariant.findMany({
      where: { productId: params.id },
    });
    for (const variant of data.variants) {
      const match = existingVariants.find((v) => v.sku === variant.sku);
      if (match) {
        await tx.productVariant.update({
          where: { id: match.id },
          data: { name: variant.name, price: variant.price, inventory: variant.inventory },
        });
      } else {
        await tx.productVariant.create({
          data: {
            productId: params.id,
            name: variant.name,
            sku: variant.sku,
            price: variant.price,
            inventory: variant.inventory,
            options: {},
          },
        });
      }
    }
  });

  await writeAuditLog({
    adminId: admin.id,
    action: "product.update",
    entityType: "Product",
    entityId: params.id,
    metadata: { name: data.name, sku: data.sku },
  });

  return NextResponse.json({ id: params.id });
}
