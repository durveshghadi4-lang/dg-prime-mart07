import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, UnauthorizedError, ForbiddenError } from "@/lib/admin-auth";
import { writeAuditLog } from "@/lib/audit";
import { productSchema } from "@/lib/admin-validation";

export async function POST(request: Request) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof UnauthorizedError)
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    if (err instanceof ForbiddenError)
      return NextResponse.json({ error: "Admin access required." }, { status: 403 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = productSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Invalid product data." },
      { status: 400 }
    );
  }
  const data = parsed.data;

  const existingSlug = await prisma.product.findUnique({ where: { slug: data.slug } });
  if (existingSlug) {
    return NextResponse.json({ error: "A product with this slug already exists." }, { status: 400 });
  }
  const existingSku = await prisma.product.findUnique({ where: { sku: data.sku } });
  if (existingSku) {
    return NextResponse.json({ error: "A product with this SKU already exists." }, { status: 400 });
  }

  const product = await prisma.product.create({
    data: {
      name: data.name,
      slug: data.slug,
      description: data.description,
      shortDescription: data.shortDescription,
      price: data.price,
      compareAtPrice: data.compareAtPrice ?? undefined,
      currency: data.currency,
      sku: data.sku,
      inventory: data.inventory,
      categoryId: data.categoryId,
      supplierId: data.supplierId ?? undefined,
      supplierProductId: data.supplierProductId || undefined,
      supplierVariantId: data.supplierVariantId || undefined,
      supplierCost: data.supplierCost ?? undefined,
      supplierShippingCost: data.supplierShippingCost ?? undefined,
      isActive: data.isActive,
      isFeatured: data.isFeatured,
      isNew: data.isNew,
      seoTitle: data.seoTitle || undefined,
      seoDescription: data.seoDescription || undefined,
      images: {
        create: data.images.map((img, i) => ({ url: img.url, alt: img.alt, sortOrder: i })),
      },
      variants: {
        create: data.variants.map((v) => ({
          name: v.name,
          sku: v.sku,
          price: v.price,
          inventory: v.inventory,
          options: {},
        })),
      },
    },
  });

  await writeAuditLog({
    adminId: admin.id,
    action: "product.create",
    entityType: "Product",
    entityId: product.id,
    metadata: { name: product.name, sku: product.sku },
  });

  return NextResponse.json({ id: product.id }, { status: 201 });
}
