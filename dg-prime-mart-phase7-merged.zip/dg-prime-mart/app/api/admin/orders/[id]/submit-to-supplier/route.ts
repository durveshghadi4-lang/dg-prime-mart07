import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, UnauthorizedError, ForbiddenError } from "@/lib/admin-auth";
import { submitFulfillmentToSupplier } from "@/lib/fulfillment-server";

/**
 * The ONLY route that can trigger a real CJ Dropshipping API call.
 * Requires ADMIN. Operates on a Fulfillment (not an Order) because
 * submission is only ever valid for a Fulfillment already APPROVED by a
 * prior, separate, explicit admin action — this route does not approve
 * anything itself.
 */
export async function POST(
  _request: Request,
  { params }: { params: { id: string } }
) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof UnauthorizedError)
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    if (err instanceof ForbiddenError)
      return NextResponse.json({ error: "Admin access required." }, { status: 403 });
    throw err;
  }

  // params.id here is the Order id (matches the existing
  // /api/admin/orders/[id]/... route family) — resolve to its Fulfillment.
  const order = await prisma.order.findUnique({
    where: { id: params.id },
    select: { fulfillment: { select: { id: true } } },
  });

  if (!order?.fulfillment) {
    return NextResponse.json(
      { error: "This order has no fulfillment record yet — approve it first." },
      { status: 404 }
    );
  }

  const result = await submitFulfillmentToSupplier(order.fulfillment.id, {
    id: admin.id,
    email: admin.email ?? "",
  });

  switch (result.status) {
    case "not_found":
      return NextResponse.json({ error: "Fulfillment not found." }, { status: 404 });
    case "not_approved":
      return NextResponse.json(
        {
          error: `This order must be approved before it can be submitted to a supplier (current status: ${result.currentStatus}).`,
        },
        { status: 400 }
      );
    case "submission_in_progress":
      return NextResponse.json(
        { error: "A submission for this order is already in progress. Please wait and refresh." },
        { status: 409 }
      );
    case "not_configured":
      return NextResponse.json(
        { error: "CJ Dropshipping is not configured (CJ_API_EMAIL / CJ_API_KEY missing)." },
        { status: 503 }
      );
    case "invalid_payload":
      return NextResponse.json({ error: result.error }, { status: 400 });
    case "supplier_error":
      return NextResponse.json(
        { error: `CJ Dropshipping rejected this order: ${result.error}` },
        { status: 502 }
      );
    case "already_submitted":
      return NextResponse.json({
        supplierOrderId: result.supplierOrderId,
        fulfillmentStatus: result.fulfillmentStatus,
        alreadySubmitted: true,
      });
    case "submitted":
      return NextResponse.json({
        supplierOrderId: result.supplierOrderId,
        fulfillmentStatus: "SUBMITTED",
        alreadySubmitted: false,
      });
  }
}
