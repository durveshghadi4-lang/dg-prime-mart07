import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, UnauthorizedError, ForbiddenError } from "@/lib/admin-auth";
import { syncFulfillmentStatus } from "@/lib/fulfillment-sync";

/**
 * Manual "Refresh Status" action for an admin viewing an order. Resolves
 * the Order id (matching the existing /api/admin/orders/[id]/... route
 * family) to its Fulfillment, then delegates entirely to
 * syncFulfillmentStatus — this route adds no CJ-facing logic of its own.
 */
export async function POST(
  _request: Request,
  { params }: { params: { id: string } }
) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof UnauthorizedError)
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    if (err instanceof ForbiddenError)
      return NextResponse.json({ error: "Admin access required." }, { status: 403 });
    throw err;
  }

  const order = await prisma.order.findUnique({
    where: { id: params.id },
    select: { fulfillment: { select: { id: true } } },
  });

  if (!order?.fulfillment) {
    return NextResponse.json({ error: "This order has no fulfillment record." }, { status: 404 });
  }

  const result = await syncFulfillmentStatus(order.fulfillment.id, {
    id: admin.id,
    email: admin.email ?? "",
  });

  switch (result.status) {
    case "not_found":
      return NextResponse.json({ error: "Fulfillment not found." }, { status: 404 });
    case "not_configured":
      return NextResponse.json(
        { error: "CJ Dropshipping is not configured." },
        { status: 503 }
      );
    case "provider_error":
      return NextResponse.json(
        { error: "Could not reach CJ Dropshipping. Please try again shortly." },
        { status: 502 }
      );
    case "not_submitted":
      return NextResponse.json(
        {
          error: `Nothing to sync — this order's fulfillment status is ${result.currentStatus}.`,
        },
        { status: 400 }
      );
    case "unrecognized_cj_status":
      return NextResponse.json({
        message: `CJ returned a status ("${result.cjStatus}") this app doesn't recognize yet — check lib/fulfillment-sync.ts's mapping. No change was made.`,
      });
    case "no_change":
      return NextResponse.json({ message: "No change.", fulfillmentStatus: result.fulfillmentStatus });
    case "updated":
      return NextResponse.json({
        message: "Updated.",
        fulfillmentStatus: result.fulfillmentStatus,
      });
  }
}
