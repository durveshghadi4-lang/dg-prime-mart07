import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, UnauthorizedError, ForbiddenError } from "@/lib/admin-auth";
import { writeAuditLog } from "@/lib/audit";

/**
 * The ONLY code path in this entire codebase that may create/advance a
 * Fulfillment row. It requires an authenticated ADMIN session (never a
 * role claimed by the client) and only operates on orders already PAID.
 *
 * Explicitly does NOT call any supplier API — CJ Dropshipping or otherwise.
 * This records an internal approval only. Live submission is a future
 * phase; nothing here is wired to make that call, by design.
 *
 * Idempotent: if a Fulfillment row already exists for this order and is
 * past PENDING_APPROVAL, the existing state is returned unchanged rather
 * than being re-approved or duplicated — safe against double-clicks,
 * retries, or two admin tabs.
 */
export async function POST(
  _request: Request,
  { params }: { params: { id: string } }
) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof UnauthorizedError) {
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    }
    if (err instanceof ForbiddenError) {
      return NextResponse.json({ error: "Admin access required." }, { status: 403 });
    }
    throw err;
  }

  const order = await prisma.order.findUnique({
    where: { id: params.id },
    include: {
      items: { include: { product: true } },
      fulfillment: true,
    },
  });

  if (!order) {
    return NextResponse.json({ error: "Order not found." }, { status: 404 });
  }

  if (order.status !== "PAID") {
    return NextResponse.json(
      { error: "Only paid orders can be approved for fulfillment." },
      { status: 400 }
    );
  }

  // Idempotency: already past the initial state — return as-is, do not
  // re-approve, do not create a second row.
  if (order.fulfillment && order.fulfillment.status !== "PENDING_APPROVAL") {
    return NextResponse.json({
      fulfillmentId: order.fulfillment.id,
      status: order.fulfillment.status,
      alreadyApproved: true,
    });
  }

  // All order items should share one supplier in the common case; use the
  // first item's mapped supplier/cost as the fulfillment-level snapshot.
  // (A genuinely mixed-supplier order is a real future scenario — Phase 4
  // takes the pragmatic single-fulfillment-record approach and documents
  // this as a known simplification.)
  const firstMappedItem = order.items.find((i) => i.product?.supplierId);
  const supplierId = firstMappedItem?.product?.supplierId ?? null;
  const supplierCost = firstMappedItem?.product?.supplierCost ?? null;
  const supplierShippingCost =
    firstMappedItem?.product?.supplierShippingCost ?? null;

  const fulfillment = await prisma.$transaction(async (tx) => {
    // Re-check inside the transaction to close the race window between the
    // read above and this write (two admin tabs clicking simultaneously).
    const fresh = order.fulfillment
      ? await tx.fulfillment.findUnique({ where: { id: order.fulfillment.id } })
      : null;

    if (fresh && fresh.status !== "PENDING_APPROVAL") {
      return fresh;
    }

    const result = fresh
      ? await tx.fulfillment.update({
          where: { id: fresh.id },
          data: {
            status: "APPROVED",
            approvedById: admin.id,
            approvedAt: new Date(),
            approvedByEmailSnapshot: admin.email,
            supplierId: supplierId ?? undefined,
            supplierCostSnapshot: supplierCost ?? undefined,
            supplierShippingCostSnapshot: supplierShippingCost ?? undefined,
          },
        })
      : await tx.fulfillment.create({
          data: {
            orderId: order.id,
            status: "APPROVED",
            approvedById: admin.id,
            approvedAt: new Date(),
            approvedByEmailSnapshot: admin.email,
            supplierId: supplierId ?? undefined,
            supplierCostSnapshot: supplierCost ?? undefined,
            supplierShippingCostSnapshot: supplierShippingCost ?? undefined,
          },
        });

    return result;
  });

  await writeAuditLog({
    adminId: admin.id,
    action: "fulfillment.approve",
    entityType: "Order",
    entityId: order.id,
    metadata: {
      orderNumber: order.orderNumber,
      fulfillmentId: fulfillment.id,
      supplierId,
    },
  });

  return NextResponse.json({
    fulfillmentId: fulfillment.id,
    status: fulfillment.status,
    alreadyApproved: false,
  });
}
