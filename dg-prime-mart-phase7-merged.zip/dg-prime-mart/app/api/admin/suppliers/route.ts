import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, UnauthorizedError, ForbiddenError } from "@/lib/admin-auth";
import { writeAuditLog } from "@/lib/audit";
import { supplierSchema } from "@/lib/admin-validation";

export async function POST(request: Request) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof UnauthorizedError)
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    if (err instanceof ForbiddenError)
      return NextResponse.json({ error: "Admin access required." }, { status: 403 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = supplierSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Invalid supplier data." },
      { status: 400 }
    );
  }

  // credentialsRef is a POINTER (e.g. a secrets-manager key name), never a
  // real secret — enforced by convention here and by the schema comment in
  // prisma/schema.prisma. This route never accepts or stores an actual API
  // key/secret value.
  const supplier = await prisma.supplier.create({
    data: {
      name: parsed.data.name,
      provider: parsed.data.provider,
      credentialsRef: parsed.data.credentialsRef || undefined,
      active: parsed.data.active,
    },
  });

  await writeAuditLog({
    adminId: admin.id,
    action: "supplier.create",
    entityType: "Supplier",
    entityId: supplier.id,
    metadata: { name: supplier.name, provider: supplier.provider },
  });

  return NextResponse.json({ id: supplier.id }, { status: 201 });
}
