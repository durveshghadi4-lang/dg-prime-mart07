import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin, UnauthorizedError, ForbiddenError } from "@/lib/admin-auth";
import { writeAuditLog } from "@/lib/audit";

const patchSchema = z.object({
  discountValue: z.number().min(0).optional(),
  minimumOrderAmount: z.number().min(0).nullable().optional(),
  usageLimit: z.number().int().min(1).nullable().optional(),
  perCustomerLimit: z.number().int().min(1).nullable().optional(),
  firstOrderOnly: z.boolean().optional(),
  active: z.boolean().optional(),
  startsAt: z.string().nullable().optional(),
  endsAt: z.string().nullable().optional(),
});

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof UnauthorizedError)
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    if (err instanceof ForbiddenError)
      return NextResponse.json({ error: "Admin access required." }, { status: 403 });
    throw err;
  }

  const existing = await prisma.coupon.findUnique({ where: { id: params.id } });
  if (!existing) {
    return NextResponse.json({ error: "Coupon not found." }, { status: 404 });
  }

  const body = await request.json().catch(() => null);
  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid coupon data." }, { status: 400 });
  }
  const data = parsed.data;

  // The coupon's `code` is intentionally not editable here — changing it
  // would silently invalidate every reference to it people may have
  // (marketing copy, the Phase 1 DG10 popup). Deactivate and create a new
  // one instead if a different code is genuinely needed.
  await prisma.coupon.update({
    where: { id: params.id },
    data: {
      discountValue: data.discountValue,
      minimumOrderAmount: data.minimumOrderAmount,
      usageLimit: data.usageLimit,
      perCustomerLimit: data.perCustomerLimit,
      firstOrderOnly: data.firstOrderOnly,
      active: data.active,
      startsAt: data.startsAt ? new Date(data.startsAt) : data.startsAt === null ? null : undefined,
      endsAt: data.endsAt ? new Date(data.endsAt) : data.endsAt === null ? null : undefined,
    },
  });

  await writeAuditLog({
    adminId: admin.id,
    action: "coupon.update",
    entityType: "Coupon",
    entityId: params.id,
    metadata: { code: existing.code, changes: data },
  });

  return NextResponse.json({ success: true });
}
