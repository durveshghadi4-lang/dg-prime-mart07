import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, UnauthorizedError, ForbiddenError } from "@/lib/admin-auth";
import { writeAuditLog } from "@/lib/audit";
import { couponSchema } from "@/lib/admin-validation";

export async function POST(request: Request) {
  let admin;
  try {
    admin = await requireAdmin();
  } catch (err) {
    if (err instanceof UnauthorizedError)
      return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
    if (err instanceof ForbiddenError)
      return NextResponse.json({ error: "Admin access required." }, { status: 403 });
    throw err;
  }

  const body = await request.json().catch(() => null);
  const parsed = couponSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Invalid coupon data." },
      { status: 400 }
    );
  }
  const data = parsed.data;
  const code = data.code.trim().toUpperCase();

  const existing = await prisma.coupon.findUnique({ where: { code } });
  if (existing) {
    return NextResponse.json({ error: "A coupon with this code already exists." }, { status: 400 });
  }

  const coupon = await prisma.coupon.create({
    data: {
      code,
      discountType: data.discountType,
      discountValue: data.discountValue,
      minimumOrderAmount: data.minimumOrderAmount ?? undefined,
      usageLimit: data.usageLimit ?? undefined,
      perCustomerLimit: data.perCustomerLimit ?? undefined,
      firstOrderOnly: data.firstOrderOnly,
      active: data.active,
      startsAt: data.startsAt ? new Date(data.startsAt) : undefined,
      endsAt: data.endsAt ? new Date(data.endsAt) : undefined,
    },
  });

  await writeAuditLog({
    adminId: admin.id,
    action: "coupon.create",
    entityType: "Coupon",
    entityId: coupon.id,
    metadata: { code: coupon.code },
  });

  return NextResponse.json({ id: coupon.id }, { status: 201 });
}
