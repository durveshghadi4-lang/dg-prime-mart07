import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { addressSchema } from "@/lib/validation";
import { calculateCheckout, createPendingOrder } from "@/lib/checkout-server";

const requestSchema = z.object({
  guestEmail: z.string().email().optional(),
  lines: z
    .array(
      z.object({
        productId: z.string().min(1),
        quantity: z.number().int().min(1).max(99),
      })
    )
    .min(1),
  couponCode: z.string().optional(),
  shippingAddress: addressSchema,
  billingAddress: addressSchema.optional(),
});

export async function POST(request: Request) {
  const session = await auth();
  const userId = session?.user?.id ?? null;

  const body = await request.json().catch(() => null);
  const parsed = requestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Invalid checkout request." },
      { status: 400 }
    );
  }

  const email = userId ? session!.user.email! : parsed.data.guestEmail;
  if (!email) {
    return NextResponse.json(
      { error: "An email address is required to check out." },
      { status: 400 }
    );
  }

  // For a logged-in customer, the database cart is the source of truth
  // (per the brief: "Read cart from the database/server-side source").
  // Guests have no server-side cart yet (Phase 1's cart is local-only), so
  // their claimed line items are accepted here — but note every one of
  // them is re-priced and re-validated against real Product rows in
  // calculateCheckout below; nothing about price or availability is ever
  // trusted from the request.
  let lines = parsed.data.lines;
  if (userId) {
    const dbCart = await prisma.cart.findUnique({
      where: { userId },
      include: { items: true },
    });
    if (dbCart && dbCart.items.length > 0) {
      lines = dbCart.items.map((item) => ({
        productId: item.productId,
        quantity: item.quantity,
      }));
    }
  }

  const calculation = await calculateCheckout({
    lines,
    couponCode: parsed.data.couponCode,
    userId,
    email,
  });

  // Never silently create a partial order when one or more requested cart
  // lines became unavailable or invalid during server-side recalculation.
  // The customer must see the issue and retry with a clean cart.
  if (calculation.lines.length === 0 || calculation.lineErrors.length > 0) {
    return NextResponse.json(
      {
        error:
          calculation.lineErrors[0] ??
          "Your cart contains an item that is no longer purchasable. Please review your cart and try again.",
        lineErrors: calculation.lineErrors,
      },
      { status: 400 }
    );
  }

  try {
    const result = await createPendingOrder({
      calculation,
      userId,
      email,
      shippingAddress: parsed.data.shippingAddress,
      billingAddress: parsed.data.billingAddress ?? parsed.data.shippingAddress,
    });

    return NextResponse.json({
      ...result,
      lineErrors: calculation.lineErrors,
      couponError: calculation.couponError,
      subtotal: calculation.subtotal,
      discount: calculation.discount,
      shipping: calculation.shipping,
    });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : "Could not start checkout.";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
