import { NextResponse } from "next/server";
import { z } from "zod";
import { capturePaymentAndFinalizeOrder } from "@/lib/checkout-server";

const requestSchema = z.object({
  paypalOrderId: z.string().min(1),
});

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = requestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  try {
    const result = await capturePaymentAndFinalizeOrder(parsed.data.paypalOrderId);

    if (result.status === "not_found") {
      return NextResponse.json({ error: "Order not found." }, { status: 404 });
    }

    if (result.status === "not_completed") {
      return NextResponse.json(
        { error: "Payment was not completed. Please try again." },
        { status: 402 }
      );
    }

    if (result.status === "provider_error") {
      return NextResponse.json(
        { error: "PayPal could not be reached. Please try again in a moment." },
        { status: 502 }
      );
    }

    // "already_captured" and "captured" return the same shape — the browser
    // can't tell (and doesn't need to) whether this call or an earlier one
    // (or the webhook) is what actually finalized the order.
    return NextResponse.json({
      orderId: result.orderId,
      orderNumber: result.orderNumber,
      guestToken: result.guestToken,
      status: "PAID",
    });
  } catch {
    // QA FIX (Phase 6, P2): this route previously had no top-level guard,
    // relying entirely on capturePaymentAndFinalizeOrder never throwing —
    // which it could, before the provider_error handling added above, and
    // still theoretically could from an unexpected DB error. Never let an
    // unexpected failure here surface as a raw unhandled 500.
    return NextResponse.json(
      { error: "Could not process this payment right now. Please try again." },
      { status: 500 }
    );
  }
}
