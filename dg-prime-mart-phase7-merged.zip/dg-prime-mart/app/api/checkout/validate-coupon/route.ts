import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/auth";
import { validateCoupon } from "@/lib/coupon-server";

const requestSchema = z.object({
  code: z.string().min(1),
  subtotal: z.number().min(0),
  email: z.string().email(),
});

export async function POST(request: Request) {
  const session = await auth();
  const body = await request.json().catch(() => null);
  const parsed = requestSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  const result = await validateCoupon({
    code: parsed.data.code,
    subtotal: parsed.data.subtotal,
    userId: session?.user?.id ?? null,
    email: parsed.data.email,
  });

  // Preview only — this does NOT record a redemption. Redemption is only
  // ever recorded inside capturePaymentAndFinalizeOrder, after a real
  // completed payment.
  return NextResponse.json(result);
}
