import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";

export async function DELETE(
  _request: Request,
  { params }: { params: { id: string } }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const address = await prisma.address.findUnique({
    where: { id: params.id },
  });

  // Return 404 rather than 403 for someone else's address — don't confirm
  // whether the record exists to a user who doesn't own it.
  if (!address || address.userId !== session.user.id) {
    return NextResponse.json({ error: "Address not found" }, { status: 404 });
  }

  await prisma.address.delete({ where: { id: params.id } });

  return NextResponse.json({ success: true });
}
