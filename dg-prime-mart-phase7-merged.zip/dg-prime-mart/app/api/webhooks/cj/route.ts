import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { syncFulfillmentStatus } from "@/lib/fulfillment-sync";

/**
 * ⚠️ HONESTY NOTE: unlike lib/paypal.ts's verifyWebhookSignature (built
 * against PayPal's well-documented, verifiable webhook signature scheme),
 * CJ Dropshipping does not have a comparably well-documented, universally
 * available webhook signature verification mechanism as of this writing.
 * This route therefore authenticates webhook calls via a simple shared
 * secret (`CJ_WEBHOOK_SECRET`) that YOU choose and configure on both
 * sides — not a signature CJ itself generates and this code verifies. If
 * CJ's dashboard offers a real signing-secret / signature-header scheme
 * when you set this up, use that instead and replace this check
 * accordingly; do not treat this shared-secret approach as equivalent
 * security to PayPal's.
 *
 * Regardless of transport auth, this endpoint changes nothing on its own
 * — it only ever calls the same syncFulfillmentStatus() used by the
 * admin's manual "Refresh Status" button, which itself only ever moves a
 * Fulfillment forward from SUBMITTED/PROCESSING/SHIPPED, never creates,
 * approves, or (re-)submits anything.
 */
export async function POST(request: Request) {
  const configuredSecret = process.env.CJ_WEBHOOK_SECRET;
  if (!configuredSecret) {
    return NextResponse.json({ error: "CJ webhook is not configured." }, { status: 503 });
  }

  const providedSecret = request.headers.get("x-cj-webhook-secret");
  if (providedSecret !== configuredSecret) {
    return NextResponse.json({ error: "Invalid webhook credentials." }, { status: 401 });
  }

  const body = await request.json().catch(() => null);
  const cjOrderId: string | undefined = body?.orderId ?? body?.data?.orderId;

  if (!cjOrderId) {
    return NextResponse.json({ error: "Missing order id in webhook payload." }, { status: 400 });
  }

  const fulfillment = await prisma.fulfillment.findUnique({
    where: { supplierOrderId: cjOrderId },
    select: { id: true },
  });

  if (!fulfillment) {
    // Not necessarily an error — could be a webhook for an order this
    // deployment doesn't know about (wrong account, stale config). Accept
    // with 200 so CJ doesn't retry indefinitely, but don't pretend we did
    // anything.
    return NextResponse.json({ received: true, matched: false });
  }

  // No `actor` passed — this is a webhook-originated sync, not an admin
  // action, so (per lib/fulfillment-sync.ts) it intentionally does not
  // write an AdminAuditLog entry. lastSyncSnapshot on the Fulfillment row
  // still records what was received.
  const result = await syncFulfillmentStatus(fulfillment.id);

  return NextResponse.json({ received: true, matched: true, result: result.status });
}
