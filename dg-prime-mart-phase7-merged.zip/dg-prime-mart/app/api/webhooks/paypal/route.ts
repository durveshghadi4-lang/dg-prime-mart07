import { NextResponse } from "next/server";
import { verifyWebhookSignature } from "@/lib/paypal";
import { capturePaymentAndFinalizeOrder } from "@/lib/checkout-server";

/**
 * PayPal webhook receiver. Configure this URL (https://<your-domain>/api/webhooks/paypal)
 * in the PayPal developer dashboard for the events listed below, and set
 * PAYPAL_WEBHOOK_ID from that webhook's configuration page.
 *
 * This exists so a completed payment is still finalized even if the
 * customer's browser never makes it back to the capture call (closed tab,
 * network drop, etc.) — the browser-driven capture in
 * /api/checkout/capture and this webhook both funnel into the same
 * `capturePaymentAndFinalizeOrder`, which is idempotent, so whichever
 * fires first wins and the other is a safe no-op.
 *
 * Relevant event types: PAYMENT.CAPTURE.COMPLETED, CHECKOUT.ORDER.APPROVED.
 */
export async function POST(request: Request) {
  const rawBody = await request.text();
  let event: unknown;
  try {
    event = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  const headers = {
    transmissionId: request.headers.get("paypal-transmission-id") ?? "",
    transmissionTime: request.headers.get("paypal-transmission-time") ?? "",
    certUrl: request.headers.get("paypal-cert-url") ?? "",
    authAlgo: request.headers.get("paypal-auth-algo") ?? "",
    transmissionSig: request.headers.get("paypal-transmission-sig") ?? "",
  };

  const verified = await verifyWebhookSignature({
    headers,
    webhookEvent: event,
  });

  if (!verified) {
    // Covers both "signature genuinely invalid" and "PAYPAL_WEBHOOK_ID not
    // configured yet" — either way, we must not act on an unverified event.
    return NextResponse.json(
      { error: "Webhook signature could not be verified." },
      { status: 401 }
    );
  }

  const typedEvent = event as {
    event_type?: string;
    resource?: { id?: string; supplementary_data?: { related_ids?: { order_id?: string } } };
  };

  const paypalOrderId =
    typedEvent.resource?.supplementary_data?.related_ids?.order_id ??
    // For CHECKOUT.ORDER.* events the resource itself IS the order.
    (typedEvent.event_type?.startsWith("CHECKOUT.ORDER.")
      ? typedEvent.resource?.id
      : undefined);

  if (
    (typedEvent.event_type === "PAYMENT.CAPTURE.COMPLETED" ||
      typedEvent.event_type === "CHECKOUT.ORDER.APPROVED") &&
    paypalOrderId
  ) {
    await capturePaymentAndFinalizeOrder(paypalOrderId);
  }

  // Always 200 once verified and handled (or intentionally ignored) so
  // PayPal doesn't endlessly retry an event we don't act on.
  return NextResponse.json({ received: true });
}
