import type { Metadata } from "next";
import { Hero } from "@/components/Hero";
import { CategoryGrid } from "@/components/CategoryGrid";
import { ProductGrid } from "@/components/ProductGrid";
import { WhyDgPrimeMart } from "@/components/WhyDgPrimeMart";
import { PromoBanner } from "@/components/PromoBanner";
import { Newsletter } from "@/components/Newsletter";
import {
  getFeaturedDemoProducts,
  getNewArrivalDemoProducts,
  getBestSellerDemoProducts,
} from "@/lib/demo-data";

export const metadata: Metadata = {
  title: "Home",
};

export default function HomePage() {
  // TODO(backend): replace these demo-data calls with real Prisma queries
  // (e.g. `getFeaturedProducts()`, `getNewArrivals()`) once the catalog is
  // populated. Component props/shapes are already database-ready.
  const featured = getFeaturedDemoProducts();
  const newArrivals = getNewArrivalDemoProducts();
  const bestSellers = getBestSellerDemoProducts();

  return (
    <>
      <Hero />
      <CategoryGrid />

      <ProductSection title="Featured Products" products={featured} />
      <ProductSection title="New Arrivals" products={newArrivals} />
      <ProductSection title="Best Sellers" products={bestSellers} />

      <WhyDgPrimeMart />
      <PromoBanner />

      <section className="bg-ink px-4 py-14 text-center text-ivory sm:px-6 lg:px-8">
        <h2 className="font-display text-2xl sm:text-3xl">Join the list</h2>
        <p className="mx-auto mt-2 max-w-sm text-sm text-ivory/70">
          New arrivals and offers, occasionally, never spammy.
        </p>
        <div className="mx-auto mt-6 max-w-sm">
          <Newsletter variant="section" />
        </div>
      </section>
    </>
  );
}

function ProductSection({
  title,
  products,
}: {
  title: string;
  products: ReturnType<typeof getFeaturedDemoProducts>;
}) {
  return (
    <section className="mx-auto max-w-container px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 flex items-end justify-between">
        <h2 className="font-display text-2xl text-ink sm:text-3xl">{title}</h2>
      </div>
      <ProductGrid
        products={products}
        emptyTitle="Nothing here yet"
        emptyMessage="This collection is being curated. Check back soon."
      />
    </section>
  );
}
