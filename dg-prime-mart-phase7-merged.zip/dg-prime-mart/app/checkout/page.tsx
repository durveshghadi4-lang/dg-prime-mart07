import type { Metadata } from "next";
import { PageHeader } from "@/components/PageHeader";
import { CheckoutForm } from "@/components/CheckoutForm";

export const metadata: Metadata = { title: "Checkout" };

export default function CheckoutPage() {
  return (
    <>
      <PageHeader
        title="Checkout"
        description="Secure payment via PayPal."
      />
      <div className="mx-auto max-w-container px-4 py-10 sm:px-6 lg:px-8">
        <CheckoutForm />
      </div>
    </>
  );
}
