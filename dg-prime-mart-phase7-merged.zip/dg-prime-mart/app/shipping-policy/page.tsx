import type { Metadata } from "next";
import { PageHeader } from "@/components/PageHeader";

export const metadata: Metadata = { title: "Shipping Policy" };

export default function ShippingPolicyPage() {
  return (
    <>
      <PageHeader title="Shipping Policy" />
      <div className="mx-auto max-w-2xl px-4 py-10 text-sm leading-relaxed text-ink/80 sm:px-6 lg:px-8">
        <p>
          Placeholder policy text. Replace with real shipping timelines, carriers
          and regions once supplier and fulfillment integrations are finalized.
        </p>
      </div>
    </>
  );
}
