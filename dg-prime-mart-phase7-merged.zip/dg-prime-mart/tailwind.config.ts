import type { Config } from "tailwindcss";

// DG PRIME MART design tokens — "botanical luxury" direction.
// Ivory base, deep bottle-green for structure/nav, dusty rose as the warm
// accent, aged brass for CTAs and highlights. Deliberately avoids the
// cream+terracotta and near-black+neon defaults.
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ivory: "#FBF8F3",
        parchment: "#F3EDE3",
        bottle: {
          DEFAULT: "#26362E",
          light: "#3B4F42",
          dark: "#182219",
        },
        rose: {
          DEFAULT: "#C98B90",
          light: "#E3BCBF",
          dark: "#A96066",
        },
        brass: {
          DEFAULT: "#A8854F",
          light: "#C7A876",
          dark: "#8A6C3C",
        },
        ink: "#241F1C",
        stone: "#8A8078",
        line: "#E4DCCE",
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "Georgia", "serif"],
        sans: ["var(--font-manrope)", "system-ui", "sans-serif"],
      },
      maxWidth: {
        container: "1360px",
      },
      boxShadow: {
        card: "0 1px 2px rgba(36,31,28,0.06), 0 8px 24px -12px rgba(36,31,28,0.12)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pop-in": {
          "0%": { opacity: "0", transform: "scale(0.96) translateY(8px)" },
          "100%": { opacity: "1", transform: "scale(1) translateY(0)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.6s cubic-bezier(0.16,1,0.3,1) both",
        "pop-in": "pop-in 0.35s cubic-bezier(0.16,1,0.3,1) both",
      },
    },
  },
  plugins: [],
};

export default config;
